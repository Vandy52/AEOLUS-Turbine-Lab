// ==========================================================
// 74HC595 Load Bank Output Tester — Keyboard Advance
// ==========================================================
// HOW TO USE:
// 1. Open Serial Monitor
// 2. Set baud rate to 115200
// 3. Type any key and press Enter
// 4. Arduino advances to next switching state
//
// This bypasses the physical switches and directly tests:
// - 74HC595 shift register
// - MOSFET gate control
// - LED load banks
//
// There are 64 total states because:
// 6 banks → 2^6 = 64 combinations
// ==========================================================


// ==========================================================
// 74HC595 OUTPUT SHIFT REGISTER PINS
// ==========================================================

const int HC595_CLOCK_PIN = 10;   // Arduino D10 → SRCLK
const int HC595_LATCH_PIN = A0;   // Arduino D14 → RCLK
const int HC595_DATA_PIN  = 11;   // Arduino D11 → SER


// ==========================================================
// GLOBAL VARIABLES
// ==========================================================

// Current logical load-bank state.
// 0  = all OFF
// 63 = all ON
byte currentState = 0;


// ==========================================================
// SETUP
// ==========================================================

void setup()
{
  Serial.begin(115200);

  pinMode(HC595_CLOCK_PIN, OUTPUT);
  pinMode(HC595_LATCH_PIN, OUTPUT);
  pinMode(HC595_DATA_PIN, OUTPUT);

  // Start with all load banks OFF
  writeOutputs(convertStateTo595(currentState));

  Serial.println("===========================================");
  Serial.println("74HC595 LOAD BANK OUTPUT TEST");
  Serial.println("===========================================");
  Serial.println("NORMAL MODE:");
  Serial.println("Type any non-binary key + Enter to advance state.");
  Serial.println();
  Serial.println("MANUAL BINARY MODE:");
  Serial.println("Type exactly 6 bits + Enter to jump to that state.");
  Serial.println("Example: 000001 = Bank 1 ON");
  Serial.println("Example: 111111 = All banks ON");
  Serial.println("===========================================");
  Serial.println();

  printStateInfo();
}


// ==========================================================
// MAIN LOOP
// ==========================================================

void loop()
{
  if (Serial.available() > 0)
  {
    String input = Serial.readStringUntil('\n');
    input.trim();

    // ------------------------------------------------------
    // MANUAL BINARY TEST MODE
    // ------------------------------------------------------
    // If the user types exactly 6 binary digits,
    // directly test that load-bank combination.
    //
    // Example:
    // 000001 → Bank 1 ON
    // 101010 → Banks 2,4,6 ON
    // ------------------------------------------------------

    bool binaryInput = true;

    if (input.length() == 6)
    {
      for (int i = 0; i < 6; i++)
      {
        if (input[i] != '0' && input[i] != '1') {
          binaryInput = false;
          break;
        }
      }

      if (binaryInput)
      {
        byte manualState = 0;

        for (int i = 0; i < 6; i++)
        {
          if (input[i] == '1') {
            bitSet(manualState, 5 - i);
          }
        }

        currentState = manualState;

        writeOutputs(convertStateTo595(currentState));
        printStateInfo();

        return;
      }
    }

    // ------------------------------------------------------
    // NORMAL STATE ADVANCE MODE
    // ------------------------------------------------------
    // Any non-binary keyboard input advances to next state.
    // ------------------------------------------------------

    currentState++;

    if (currentState > 63) {
      currentState = 0;
    }

    writeOutputs(convertStateTo595(currentState));
    printStateInfo();
  }
}


// ==========================================================
// convertStateTo595()
// ==========================================================
// Converts logical bank states into physical 74HC595 outputs.
//
// Logical Bank Mapping:
// Bank 1 → QB
// Bank 2 → QC
// Bank 3 → QD
// Bank 4 → QE
// Bank 5 → QF
// Bank 6 → QG
//
// QB-QG correspond to bits 1-6 in the output byte.
// ==========================================================

byte convertStateTo595(byte state)
{
  byte out = 0;

  for (int bank = 0; bank < 6; bank++)
  {
    if (bitRead(state, bank))
    {
      bitSet(out, bank + 1);
      //bitSet(out, bank);
    }
  }

  return out;
}


// ==========================================================
// writeOutputs()
// ==========================================================
// Sends output byte to the 74HC595 shift register.
// ==========================================================

void writeOutputs(byte state)
{
  digitalWrite(HC595_LATCH_PIN, LOW);

  shiftOut(HC595_DATA_PIN,
           HC595_CLOCK_PIN,
           MSBFIRST,
           state);

  digitalWrite(HC595_LATCH_PIN, HIGH);
}


// ==========================================================
// printStateInfo()
// ==========================================================
// Prints:
// - Current state number
// - Binary representation
// - Which banks should be ON
// - What the NEXT state will do
// ==========================================================

void printStateInfo()
{
  Serial.println("===========================================");

  // --------------------------------------------------------
  // Current state number
  // --------------------------------------------------------

  Serial.print("CURRENT STATE: ");
  Serial.print(currentState);
  Serial.print(" / 63");

  // --------------------------------------------------------
  // Binary representation
  // --------------------------------------------------------

  Serial.print("    Binary: ");

  for (int bank = 5; bank >= 0; bank--)
  {
    Serial.print(bitRead(currentState, bank));
  }

  Serial.println();

  // --------------------------------------------------------
  // Expected ON banks
  // --------------------------------------------------------

  Serial.print("EXPECTED ACTIVE BANKS: ");

  bool anyOn = false;

  for (int bank = 0; bank < 6; bank++)
  {
    if (bitRead(currentState, bank))
    {
      Serial.print("Bank ");
      Serial.print(bank + 1);
      Serial.print("  ");
      anyOn = true;
    }
  }

  if (!anyOn) {
    Serial.print("ALL OFF");
  }

  Serial.println();

  // --------------------------------------------------------
  // Describe next state
  // --------------------------------------------------------

  byte nextState = currentState + 1;

  if (nextState > 63) {
    nextState = 0;
  }

  Serial.print("NEXT STATE: ");
  Serial.print(nextState);
  Serial.print("    Binary: ");

  for (int bank = 5; bank >= 0; bank--)
  {
    Serial.print(bitRead(nextState, bank));
  }

  Serial.println();

  Serial.print("NEXT EXPECTED BANKS: ");

  anyOn = false;

  for (int bank = 0; bank < 6; bank++)
  {
    if (bitRead(nextState, bank))
    {
      Serial.print("Bank ");
      Serial.print(bank + 1);
      Serial.print("  ");
      anyOn = true;
    }
  }

  if (!anyOn) {
    Serial.print("ALL OFF");
  }

  Serial.println();
  Serial.println("===========================================");
  Serial.println();
}