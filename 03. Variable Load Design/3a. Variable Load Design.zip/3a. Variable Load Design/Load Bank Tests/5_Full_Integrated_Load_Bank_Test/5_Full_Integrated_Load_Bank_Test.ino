// ==========================================================
// Full Integrated Load Bank Test
// ==========================================================

// Order of operations:
// 1) Set bench power supply voltage/current
// 2) Turn ON desired physical switches
// 3) Upload/start code
// 4) Enter voltage
// 5) Enter max current
// 6) Code computes Pgen
// 7) Smart logic decides which banks stay active


// Purpose:
//
// Verifies complete physical load bank operation:
//
// Switches → 74HC165 → Arduino → Smart Grid Logic
// → 74HC595 → MOSFETs → Load Banks
//                     ↑
//                 INA219 (Pgen)
//
// External Supply:
// Acts as generator substitute
//
// Arduino USB:
// Powers control electronics
// ==========================================================

#include <Wire.h>
#include <Adafruit_INA219.h>

// -----------------------------
// 74HC165 (SWITCH INPUTS)
// -----------------------------
#define HC165_LOAD_PIN   A1    // D15 → SH/*LD
#define HC165_CLOCK_PIN  A2    // D16 → CLK
#define HC165_DATA_PIN   A3    // D17 ← QH


// -----------------------------
// 74HC595 (MOSFET OUTPUTS)
// -----------------------------
#define HC595_CLOCK_PIN 10     // D10 → SRCLK
#define HC595_LATCH_PIN A0     // D14 → RCLK
#define HC595_DATA_PIN 11      // D11 → SER


// -----------------------------
// INA219 (POWER SENSOR)
// -----------------------------
#define INA219_SDA 18          // D18 (A4)
#define INA219_SCL 19          // D19 (A5)

Adafruit_INA219 ina219;


// ==========================================================
// SETTINGS
// ==========================================================

// NEED TO UPDATE:
// Measured power requirement for one bank

float BANK_POWER_W = 0.36;


// Optional error band
// Measurement uncertainty band
float pgenSafetyMargin_W = 0.25;

// Fraction of available power allowed to be used
// Lower value = more shedding = brighter remaining bulbs
float pmaxSafetyFactor = 0.80;


// ==========================================================
// GLOBAL VARIABLES
// ==========================================================

byte requestedBanks = 0;
byte activeBanks    = 0;

float Pref = 0;
float Pgen = 0;


// ==========================================================
// SETUP
// ==========================================================

void setup()
{
Serial.begin(115200);
delay(1000);

    // ---------- 74HC165 ----------
    pinMode(HC165_LOAD_PIN, OUTPUT);
    pinMode(HC165_CLOCK_PIN, OUTPUT);
    pinMode(HC165_DATA_PIN, INPUT);

    digitalWrite(HC165_LOAD_PIN, HIGH);
    digitalWrite(HC165_CLOCK_PIN, LOW);

    // ---------- 74HC595 ----------
    pinMode(HC595_CLOCK_PIN, OUTPUT);
    pinMode(HC595_LATCH_PIN, OUTPUT);
    pinMode(HC595_DATA_PIN, OUTPUT);

    // Force all outputs OFF initially
    writeOutputs(0);
    
    // ---------- INA219 ----------
    //Make sure the INA219 is getting power at this point or you won't see teh UI!
    if(!ina219.begin())
    {
        Serial.println("ERROR: INA219 not detected");

        while(true)
        {
        }
    }


    Serial.println();
    Serial.println("======================================");
    Serial.println("FULL INTEGRATED LOAD BANK TEST");
    Serial.println("======================================");
    Serial.println();
}


// ==========================================================
// MAIN LOOP
// ==========================================================

void loop()
{
    // Enter available source power
    acquirePgen();

    // Read switch positions afterward
    requestedBanks = readSwitches();

    // Execute smart grid logic
    runSmartGrid();

    Serial.println();
    Serial.println("Adjust physical switches for next test (Make sure the ON switches match the active load banks)");
    Serial.println("Press any key to continue");

        while(Serial.available())
        {
            Serial.read();
        }

        while(!Serial.available())
        {
        }

        while(Serial.available())
        {
            Serial.read();
        }
}



// ==========================================================
// READ SWITCHES (74HC165)
// ==========================================================

byte readSwitches()
{
    byte raw = 0;

    digitalWrite(HC165_LOAD_PIN, LOW);
    delayMicroseconds(5);

    digitalWrite(HC165_LOAD_PIN, HIGH);
    delayMicroseconds(5);

    for(int i=0;i<8;i++)
    {
        raw <<= 1;

        if(digitalRead(HC165_DATA_PIN))
        {
            raw |= 1;
        }

        digitalWrite(HC165_CLOCK_PIN, HIGH);
        delayMicroseconds(5);

        digitalWrite(HC165_CLOCK_PIN, LOW);
        delayMicroseconds(5);
    }

    byte switches = 0;

    // Explicit mapping:
    // A→Switch1
    // B→Switch2
    // C→Switch3
    // D→Switch4
    // E→Switch5
    // F→Switch6

    if(bitRead(raw,0)) bitSet(switches,0);
    if(bitRead(raw,1)) bitSet(switches,1);
    if(bitRead(raw,2)) bitSet(switches,2);
    if(bitRead(raw,3)) bitSet(switches,3);
    if(bitRead(raw,4)) bitSet(switches,4);
    if(bitRead(raw,5)) bitSet(switches,5);

    return switches;
}



// ==========================================================
// ACQUIRE PGEN
// ==========================================================

void acquirePgen()
{
    float supplyVoltage = 0;
    float supplyCurrent = 0;

    // Clear old characters
    while(Serial.available())
    {
        Serial.read();
    }

    // -----------------------------
    // Voltage input
    // -----------------------------
    Serial.println();
    Serial.println("Enter available supply voltage (V):");
    Serial.println("Example: 9");

    while(!Serial.available())
    {
    }

    supplyVoltage = Serial.parseFloat();

    while(Serial.available())
    {
        Serial.read();
    }

    Serial.print("Entered Voltage: ");
    Serial.print(supplyVoltage);
    Serial.println(" V");


    // -----------------------------
    // Current input
    // -----------------------------
    Serial.println();
    Serial.println("Enter maximum supply current (A):");
    Serial.println("Example: 1.5");

    while(!Serial.available())
    {
    }

    supplyCurrent = Serial.parseFloat();

    while(Serial.available())
    {
        Serial.read();
    }

    Serial.print("Entered Current: ");
    Serial.print(supplyCurrent);
    Serial.println(" A");


    // -----------------------------
    // Compute available power
    // -----------------------------
    //Pgen = supplyVoltage * supplyCurrent;

    float rawPower = supplyVoltage * supplyCurrent;
    Pgen = rawPower * pmaxSafetyFactor;

    Serial.println();
    Serial.println("================================");

    // Serial.print("Computed Available Power: ");
    // Serial.print(Pgen);
    // Serial.println(" W");
    Serial.print("Raw Available Power: ");
    Serial.print(rawPower);
    Serial.println(" W");

    Serial.println();

    Serial.print("Usable Power: ");
    Serial.print(Pgen);
    Serial.println(" W");

    Serial.println("================================");
    Serial.println();
}



// ==========================================================
// SMART GRID LOGIC
// ==========================================================

void runSmartGrid()
{
    activeBanks=requestedBanks;

    Pref=
    computePref(activeBanks);

    Serial.println();

    Serial.print("Requested Banks: ");
    printBanks(requestedBanks);

    Serial.print("Requested Pref: ");
    Serial.print(Pref);
    Serial.println(" W");


bool shedOccurred = false;

while((Pref > (Pgen + pgenSafetyMargin_W)) &&
      (activeBanks != 0))
{
    if(!shedOccurred)
    {
        Serial.println();
        Serial.println("============");

        shedOccurred = true;
    }

    activeBanks =
    shedHighestBank(activeBanks);

    Pref =
    computePref(activeBanks);
}

if(shedOccurred)
{
    Serial.println("============");
    Serial.println();
}

    writeOutputs(
    convertStateTo595(activeBanks));

    Serial.println();

    Serial.print("Active Banks: ");
    printBanks(activeBanks);

    Serial.print("Final Pref: ");
    Serial.print(Pref);
    Serial.println(" W");

    Serial.print("Available Pgen: ");
    Serial.print(Pgen);
    Serial.println(" W");
}



// ==========================================================
// COMPUTE PREF
// ==========================================================

float computePref(byte state)
{
    float total = 0;

    for(int i=0;i<6;i++)
    {
        if(bitRead(state,i))
        {
            total += BANK_POWER_W;
        }
    }

    return total;
}



// ==========================================================
// SHED HIGHEST BANK
// ==========================================================

byte shedHighestBank(byte state)
{
    for(int i=5;i>=0;i--)
    {
        if(bitRead(state,i))
        {
            bitClear(state,i);

            Serial.print("Shedding Bank ");
            Serial.println(i+1);

            break;
        }
    }

    return state;
}



// ==========================================================
// CONVERT TO 74HC595
// ==========================================================

byte convertStateTo595(byte state)
{
    byte out=0;

    for(int bank=0;bank<6;bank++)
    {
        if(bitRead(state,bank))
        {
            bitSet(out,bank+1);
        }
    }

    return out;
}



// ==========================================================
// WRITE OUTPUTS
// ==========================================================

void printBanks(byte state)
{
    bool anyOn = false;

    for(int i=0;i<6;i++)
    {
        if(bitRead(state,i))
        {
            Serial.print("Bank ");
            Serial.print(i+1);
            Serial.print("  ");

            anyOn = true;
        }
    }

    if(!anyOn)
    {
        Serial.print("NONE");
    }

    Serial.println();
}


void writeOutputs(byte state)
{
    digitalWrite(HC595_LATCH_PIN,LOW);

    shiftOut(
      HC595_DATA_PIN,
      HC595_CLOCK_PIN,
      MSBFIRST,
      state);

    digitalWrite(HC595_LATCH_PIN,HIGH);
}