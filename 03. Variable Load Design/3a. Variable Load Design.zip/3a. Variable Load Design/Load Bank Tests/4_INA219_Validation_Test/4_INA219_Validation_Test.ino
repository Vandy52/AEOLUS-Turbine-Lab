// // ==========================================================
// // INA219 Validation Test
// // ==========================================================
// // Setup:
// // Bench Supply (+) → INA219 VIN+
// // INA219 VIN−     → 100 Ω, 2 W resistor
// // Resistor other side → Bench Supply (−)
// //
// // INA219 VCC → Arduino 5V
// // INA219 GND → Arduino GND
// // INA219 SDA → Arduino A4 / D18
// // INA219 SCL → Arduino A5 / D19
// // ==========================================================

// #include <Wire.h>
// #include <Adafruit_INA219.h>

// // -----------------------------
// // INA219 (I2C POWER SENSOR)
// // -----------------------------
// #define INA219_SDA 18   // D18 (A4) → SDA
// #define INA219_SCL 19   // D19 (A5) → SCL

// Adafruit_INA219 ina219;

// void setup()
// {
//   Serial.begin(115200);

//   Serial.println("INA219 VALIDATION TEST");

//   if (!ina219.begin())
//   {
//     Serial.println("ERROR: INA219 not detected");
//     while (true);
//   }

//   Serial.println("INA219 detected");
// }

// void loop()
// {
//   float busVoltage   = ina219.getBusVoltage_V();
//   float shuntVoltage = ina219.getShuntVoltage_mV() / 1000.0;
//   float loadVoltage  = busVoltage + shuntVoltage;
//   float current      = ina219.getCurrent_mA() / 1000.0;
//   float power        = loadVoltage * current;

//   Serial.println("==========================");

//   Serial.print("Load Voltage: ");
//   Serial.print(loadVoltage, 3);
//   Serial.println(" V");

//   Serial.print("Current: ");
//   Serial.print(current, 3);
//   Serial.println(" A");

//   Serial.print("Power: ");
//   Serial.print(power, 3);
//   Serial.println(" W");

//   Serial.println("==========================");
//   Serial.println();

//   delay(1000);
// }


// ==========================================================
// INA219 + SINGLE LOAD BANK TEST
// ==========================================================
// Purpose:
//
// Forces Bank 1 ON and continuously measures:
//
// Voltage
// Current
// Power
//
// Expected:
//
// Only Bank 1 illuminates
// ==========================================================

#include <Wire.h>
#include <Adafruit_INA219.h>

// -----------------------------
// 74HC595 (MOSFET OUTPUTS)
// -----------------------------
#define HC595_CLOCK_PIN 10
#define HC595_LATCH_PIN A0
#define HC595_DATA_PIN 11


// -----------------------------
// INA219
// -----------------------------
#define INA219_SDA 18
#define INA219_SCL 19

Adafruit_INA219 ina219;


// ==========================================================
// SETUP
// ==========================================================

void setup()
{
    Serial.begin(115200);

    // ---------- 74HC595 ----------

    pinMode(HC595_CLOCK_PIN,OUTPUT);
    pinMode(HC595_LATCH_PIN,OUTPUT);
    pinMode(HC595_DATA_PIN,OUTPUT);

    // ---------- INA219 ----------

    if(!ina219.begin())
    {
        Serial.println("INA219 ERROR");

        while(true)
        {
        }
    }

    Serial.println();
    Serial.println("============================");
    Serial.println("BANK 1 POWER TEST");
    Serial.println("============================");

    // Force Bank 1 ON
    //
    // QB→Bank1

    writeOutputs(B00000010);
}



// ==========================================================
// LOOP
// ==========================================================

void loop()
{
    float V=
    ina219.getBusVoltage_V();

    float I=
    ina219.getCurrent_mA()/1000.0;

    float P=
    V*I;

    Serial.println("------------------------");

    Serial.print("Voltage: ");
    Serial.print(V,3);
    Serial.println(" V");

    Serial.print("Current: ");
    Serial.print(I,3);
    Serial.println(" A");

    Serial.print("Power: ");
    Serial.print(P,3);
    Serial.println(" W");

    Serial.println("------------------------");
    Serial.println();

    delay(1000);
}



// ==========================================================
// WRITE OUTPUTS
// ==========================================================

void writeOutputs(byte state)
{
    digitalWrite(
      HC595_LATCH_PIN,
      LOW);

    shiftOut(
      HC595_DATA_PIN,
      HC595_CLOCK_PIN,
      MSBFIRST,
      state);

    digitalWrite(
      HC595_LATCH_PIN,
      HIGH);
}


        // // ==========================================================
        // // Test: INA219 + Forced Bank 1 Power Test
        // // ==========================================================
        // //
        // // Purpose:
        // // Verifies:
        // //
        // // Arduino
        // //    ↓
        // // 74HC595
        // //    ↓
        // // MOSFET Bank 1
        // //    ↓
        // // Load Bank 1
        // //    ↓
        // // INA219
        // //
        // // Expected:
        // //
        // // - Bank 1 illuminates immediately
        // // - INA219 continuously reports:
        // //
        // //      Voltage
        // //      Current
        // //      Power
        // //
        // // ==========================================================

        // #include <Wire.h>
        // #include <Adafruit_INA219.h>

        // // -----------------------------
        // // 74HC595 (MOSFET OUTPUTS)
        // // -----------------------------
        // #define HC595_CLOCK_PIN 10
        // #define HC595_LATCH_PIN A0
        // #define HC595_DATA_PIN 11


        // // -----------------------------
        // // INA219
        // // -----------------------------
        // #define INA219_SDA 18
        // #define INA219_SCL 19

        // Adafruit_INA219 ina219;


        // // ==========================================================
        // // SETUP
        // // ==========================================================

        // void setup()
        // {
        //     Serial.begin(115200);

        //     // ----- 74HC595 -----

        //     pinMode(HC595_CLOCK_PIN,OUTPUT);
        //     pinMode(HC595_LATCH_PIN,OUTPUT);
        //     pinMode(HC595_DATA_PIN,OUTPUT);

        //     // Force all OFF first
        //     writeOutputs(0);

        //     // ----- INA219 -----

        //     if(!ina219.begin())
        //     {
        //         Serial.println("ERROR: INA219 not detected");

        //         while(true)
        //         {
        //         }
        //     }

        //     Serial.println();
        //     Serial.println("===================================");
        //     Serial.println("INA219 + FORCED BANK 1 TEST");
        //     Serial.println("===================================");
        //     Serial.println();
        //     Serial.println("Expected:");
        //     Serial.println("- Bank 1 ON");
        //     Serial.println("- Continuous power readings");
        //     Serial.println();

        //     // ---------------------------------
        //     // Force Bank 1 ON
        //     //
        //     // QB -> Bank1
        //     // ---------------------------------

        //     byte outputState = 0;

        //     bitSet(outputState,1);

        //     writeOutputs(outputState);

        //     Serial.println("Bank 1 forced ON");
        //     Serial.println();
        // }



        // // ==========================================================
        // // MAIN LOOP
        // // ==========================================================

        // void loop()
        // {
        //     float V =
        //     ina219.getBusVoltage_V();

        //     float I =
        //     ina219.getCurrent_mA()/1000.0;

        //     float P =
        //     V*I;

        //     Serial.println("---------------------");

        //     Serial.print("Voltage: ");
        //     Serial.print(V,3);
        //     Serial.println(" V");

        //     Serial.print("Current: ");
        //     Serial.print(I,3);
        //     Serial.println(" A");

        //     Serial.print("Power: ");
        //     Serial.print(P,3);
        //     Serial.println(" W");

        //     Serial.println();

        //     delay(1000);
        // }



        // // ==========================================================
        // // WRITE OUTPUTS
        // // ==========================================================

        // void writeOutputs(byte state)
        // {
        //     digitalWrite(
        //     HC595_LATCH_PIN,
        //     LOW);

        //     shiftOut(
        //     HC595_DATA_PIN,
        //     HC595_CLOCK_PIN,
        //     MSBFIRST,
        //     state);

        //     digitalWrite(
        //     HC595_LATCH_PIN,
        //     HIGH);
        // }