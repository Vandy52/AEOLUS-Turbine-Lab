// ==========================================================
// Test: INA219 + Forced Bank 1 Power Test
// ==========================================================
//
// Use to help troubleshoot the 4_INA219_Validation_Test.ino code
//
// Purpose:
// Verifies:
//
// Arduino
//    ↓
// 74HC595
//    ↓
// MOSFET Bank 1
//    ↓
// Load Bank 1
//    ↓
// INA219
//
// Expected:
//
// - Bank 1 illuminates immediately
// - INA219 continuously reports:
//
//      Voltage
//      Current
//      Power
//
// ==========================================================

#include <Wire.h>
#include <Adafruit_INA219.h>

// -----------------------------
// 74HC595 (MOSFET OUTPUTS)
// -----------------------------
#define HC595_CLOCK_PIN 10
#define HC595_LATCH_PIN A0
#define HC595_DATA_PIN 11


// -----------------------------
// INA219
// -----------------------------
#define INA219_SDA 18
#define INA219_SCL 19

Adafruit_INA219 ina219;


// ==========================================================
// SETUP
// ==========================================================

void setup()
{
    Serial.begin(115200);

    // ----- 74HC595 -----

    pinMode(HC595_CLOCK_PIN,OUTPUT);
    pinMode(HC595_LATCH_PIN,OUTPUT);
    pinMode(HC595_DATA_PIN,OUTPUT);

    // Force all OFF first
    writeOutputs(0);

    // ----- INA219 -----

    if(!ina219.begin())
    {
        Serial.println("ERROR: INA219 not detected");

        while(true)
        {
        }
    }

    Serial.println();
    Serial.println("===================================");
    Serial.println("INA219 + FORCED BANK 1 TEST");
    Serial.println("===================================");
    Serial.println();
    Serial.println("Expected:");
    Serial.println("- Bank 1 ON");
    Serial.println("- Continuous power readings");
    Serial.println();

    // ---------------------------------
    // Force Bank 1 ON
    //
    // QB -> Bank1
    // ---------------------------------

    byte outputState = 0;

    bitSet(outputState,1);

    writeOutputs(outputState);

    Serial.println("Bank 1 forced ON");
    Serial.println();
}



// ==========================================================
// MAIN LOOP
// ==========================================================

void loop()
{
    float V =
    ina219.getBusVoltage_V();

    float I =
    ina219.getCurrent_mA()/1000.0;

    float P =
    V*I;

    Serial.println("---------------------");

    Serial.print("Voltage: ");
    Serial.print(V,3);
    Serial.println(" V");

    Serial.print("Current: ");
    Serial.print(I,3);
    Serial.println(" A");

    Serial.print("Power: ");
    Serial.print(P,3);
    Serial.println(" W");

    Serial.println();

    delay(1000);
}



// ==========================================================
// WRITE OUTPUTS
// ==========================================================

void writeOutputs(byte state)
{
    digitalWrite(
      HC595_LATCH_PIN,
      LOW);

    shiftOut(
      HC595_DATA_PIN,
      HC595_CLOCK_PIN,
      MSBFIRST,
      state);

    digitalWrite(
      HC595_LATCH_PIN,
      HIGH);
}