// ==========================================================
// Switch + Load Bank Integration Test
// ==========================================================
// Purpose:
//
// Switches → 74HC165 → Arduino → 74HC595
// → MOSFETs → Load Banks
//
// Flip physical switches and verify corresponding
// load banks illuminate.
// ==========================================================


// -----------------------------
// 74HC165 (SWITCH INPUTS)
// -----------------------------
#define HC165_LOAD_PIN   A1
#define HC165_CLOCK_PIN  A2
#define HC165_DATA_PIN   A3


// -----------------------------
// 74HC595 (MOSFET OUTPUTS)
// -----------------------------
#define HC595_CLOCK_PIN 10
#define HC595_LATCH_PIN A0
#define HC595_DATA_PIN 11


byte lastSwitchState = 255;


// ==========================================================
// SETUP
// ==========================================================

void setup()
{
  Serial.begin(115200);

  // ---------- 74HC165 ----------
  pinMode(HC165_LOAD_PIN, OUTPUT);
  pinMode(HC165_CLOCK_PIN, OUTPUT);
  pinMode(HC165_DATA_PIN, INPUT);

  digitalWrite(HC165_LOAD_PIN, HIGH);
  digitalWrite(HC165_CLOCK_PIN, LOW);

  // ---------- 74HC595 ----------
  pinMode(HC595_CLOCK_PIN, OUTPUT);
  pinMode(HC595_LATCH_PIN, OUTPUT);
  pinMode(HC595_DATA_PIN, OUTPUT);

  // Force all MOSFET outputs OFF initially
  writeOutputs(0);

  Serial.println();
  Serial.println("======================================");
  Serial.println("SWITCH + LOAD BANK INTEGRATION TEST");
  Serial.println("======================================");
  Serial.println();

  Serial.println("Switch State | Active Banks");
  Serial.println("--------------------------------");
}


// ==========================================================
// MAIN LOOP
// ==========================================================

void loop()
{
  byte switchState = readSwitches();

  if (switchState != lastSwitchState)
  {
    lastSwitchState = switchState;

    // Drive MOSFETs immediately
    writeOutputs(
      convertStateTo595(switchState)
    );

    printSwitchState(switchState);
  }

  delay(100);
}


// ==========================================================
// READ SWITCHES
// ==========================================================

byte readSwitches()
{
  byte raw = 0;

  digitalWrite(HC165_LOAD_PIN, LOW);
  delayMicroseconds(5);

  digitalWrite(HC165_LOAD_PIN, HIGH);
  delayMicroseconds(5);

  for(int i=0;i<8;i++)
  {
    raw <<= 1;

    if(digitalRead(HC165_DATA_PIN))
    {
      raw |= 1;
    }

    digitalWrite(HC165_CLOCK_PIN, HIGH);
    delayMicroseconds(5);

    digitalWrite(HC165_CLOCK_PIN, LOW);
    delayMicroseconds(5);
  }


  byte switches = 0;

  // Explicit A→1, B→2, C→3...

  if(bitRead(raw,0)) bitSet(switches,0);
  if(bitRead(raw,1)) bitSet(switches,1);
  if(bitRead(raw,2)) bitSet(switches,2);
  if(bitRead(raw,3)) bitSet(switches,3);
  if(bitRead(raw,4)) bitSet(switches,4);
  if(bitRead(raw,5)) bitSet(switches,5);

  return switches;
}


// ==========================================================
// CONVERT TO 74HC595
// ==========================================================

byte convertStateTo595(byte state)
{
  byte out = 0;

  for(int bank=0; bank<6; bank++)
  {
    if(bitRead(state,bank))
    {
      // Shift by +1 because QA is unused
      // and QB starts Bank 1
      bitSet(out,bank+1);
    }
  }

  return out;
}


// ==========================================================
// WRITE OUTPUTS
// ==========================================================

void writeOutputs(byte state)
{
  digitalWrite(
    HC595_LATCH_PIN,
    LOW);

  shiftOut(
    HC595_DATA_PIN,
    HC595_CLOCK_PIN,
    MSBFIRST,
    state);

  digitalWrite(
    HC595_LATCH_PIN,
    HIGH);
}


// ==========================================================
// PRINT STATE
// ==========================================================

void printSwitchState(byte state)
{
  Serial.print("     ");

  for(int i=0;i<6;i++)
  {
    Serial.print(bitRead(state,i));
    Serial.print(" ");
  }

  Serial.print("      | ");

  bool anyOn=false;

  for(int i=0;i<6;i++)
  {
    if(bitRead(state,i))
    {
      Serial.print("Bank ");
      Serial.print(i+1);
      Serial.print(" ");

      anyOn=true;
    }
  }

  if(!anyOn)
  {
    Serial.print("NONE");
  }

  Serial.println();
}