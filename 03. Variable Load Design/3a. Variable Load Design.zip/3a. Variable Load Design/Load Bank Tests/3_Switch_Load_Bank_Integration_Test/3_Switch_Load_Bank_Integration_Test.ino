// ==========================================================
// Switch + Load Bank Integration Test
// ==========================================================
// Purpose:
//
// Tests complete signal path:
//
// Switches
//   ↓
// 74HC165
//   ↓
// Arduino
//   ↓
// 74HC595
//   ↓
// MOSFETs
//   ↓
// Load Banks
//
// Expected:
//
// Switch 1 → Bank 1 ON
// Switch 2 → Bank 2 ON
// ...
// Switches 1,3,6 → Banks 1,3,6 ON
// ==========================================================


// -----------------------------
// 74HC165 (SWITCH INPUTS)
// -----------------------------
#define HC165_LOAD_PIN   A1
#define HC165_CLOCK_PIN  A2
#define HC165_DATA_PIN   A3


// -----------------------------
// 74HC595 (MOSFET OUTPUTS)
// -----------------------------
#define HC595_CLOCK_PIN 10
#define HC595_LATCH_PIN A0
#define HC595_DATA_PIN 11


byte previousState = 255;


// ==========================================================
// SETUP
// ==========================================================

void setup()
{
    Serial.begin(115200);

    // ----- 74HC165 -----

    pinMode(HC165_LOAD_PIN,OUTPUT);
    pinMode(HC165_CLOCK_PIN,OUTPUT);
    pinMode(HC165_DATA_PIN,INPUT);

    digitalWrite(HC165_LOAD_PIN,HIGH);
    digitalWrite(HC165_CLOCK_PIN,LOW);


    // ----- 74HC595 -----

    pinMode(HC595_CLOCK_PIN,OUTPUT);
    pinMode(HC595_LATCH_PIN,OUTPUT);
    pinMode(HC595_DATA_PIN,OUTPUT);

    // Force all outputs OFF at startup

    writeOutputs(B00000000);

    Serial.println();
    Serial.println("===================================");
    Serial.println("SWITCH + LOAD BANK TEST");
    Serial.println("===================================");
    Serial.println();
}


// ==========================================================
// MAIN LOOP
// ==========================================================

void loop()
{
    byte state = readSwitches();

    if(state != previousState)
    {
        previousState = state;

        byte output =
        convertTo595(state);

        writeOutputs(output);

        printState(state);
    }

    delay(100);
}


// ==========================================================
// READ SWITCHES
// ==========================================================

byte readSwitches()
{
    byte raw = 0;

    digitalWrite(
    HC165_LOAD_PIN,
    LOW);

    delayMicroseconds(5);

    digitalWrite(
    HC165_LOAD_PIN,
    HIGH);

    for(int i=0;i<8;i++)
    {
        raw <<= 1;

        if(
        digitalRead(
        HC165_DATA_PIN))
        {
            raw |= 1;
        }

        digitalWrite(
        HC165_CLOCK_PIN,
        HIGH);

        delayMicroseconds(5);

        digitalWrite(
        HC165_CLOCK_PIN,
        LOW);

        delayMicroseconds(5);
    }

    byte state=0;

    // A→Switch1
    // B→Switch2
    // etc.

    for(int i=0;i<6;i++)
    {
        if(bitRead(raw,i))
        {
            bitSet(state,i);
        }
    }

    return state;
}



// ==========================================================
// CONVERT TO 74HC595
// ==========================================================

byte convertTo595(byte state)
{
    byte out=0;

    for(int bank=0;bank<6;bank++)
    {
        if(bitRead(state,bank))
        {
            // Shift one position because
            // QA unused
            // QB-QG used

            bitSet(out,bank+1);
        }
    }

    return out;
}



// ==========================================================
// WRITE OUTPUTS
// ==========================================================

void writeOutputs(byte state)
{
    digitalWrite(
    HC595_LATCH_PIN,
    LOW);

    shiftOut(
        HC595_DATA_PIN,
        HC595_CLOCK_PIN,
        MSBFIRST,
        state);

    digitalWrite(
        HC595_LATCH_PIN,
        HIGH);
}



// ==========================================================
// PRINT RESULTS
// ==========================================================

void printState(byte state)
{
    Serial.println();

    Serial.print(
    "Switches: ");

    for(int i=5;i>=0;i--)
    {
        Serial.print(
        bitRead(
        state,
        i));
    }

    Serial.println();

    Serial.print(
    "Active Banks: ");

    bool any=false;

    for(int i=0;i<6;i++)
    {
        if(bitRead(state,i))
        {
            Serial.print(
            i+1);

            Serial.print(" ");

            any=true;
        }
    }

    if(!any)
    {
        Serial.print(
        "NONE");
    }

    Serial.println();
}