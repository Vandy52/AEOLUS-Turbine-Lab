// ============================================================
// AEOLUS LOAD BANK SCHEDULER
//
// Outputs to Simulink:
//   Pref
//   counterSignal      (0 -> 10 -> 0)
//   counter5Signal     (0 -> 5 -> 0 every 20 sec)
//   simulinkValuePlusOne
//
// Receives from Simulink:
//   simulinkValue
//
// ============================================================

const float PREF_PER_BANK_W = 4.05f;
const unsigned long LOOP_DT_MS = 20;

unsigned long lastLoopMs = 0;
unsigned long lastCounterUpdate = 0;

int activeBanks = 0;
float Pref = 0.0f;

// Counter #1 : 0 -> 10 -> 0
float counterSignal = 0.0f;
float counterStep = 0.1f;

// Counter #2 : 0 -> 5 -> 0 every 20 sec
float counter5Signal = 0.0f;
int counter5Step = 1;

// Received value from Simulink
float simulinkValue = 0.0f;
float simulinkValuePlusOne = 0.0f;

// ============================================================
void setup()
{
    Serial.begin(115200);
}

// ============================================================
void loop()
{
    unsigned long t = millis();

    // ========================================================
    // RECEIVE FLOAT FROM SIMULINK
    //
    // Simulink sends:
    //    'S' + float + 'E'
    //
    // Total = 6 bytes
    // ========================================================

    if (Serial.available() >= 6)
    {
        if (Serial.read() == 'S')
        {
            Serial.readBytes((char*)&simulinkValue,
                             sizeof(float));

            if (Serial.read() == 'E')
            {
                simulinkValuePlusOne = simulinkValue + 1.0f;
            }
        }
    }

    // ========================================================
    // LOAD BANK SCHEDULE
    // ========================================================

    unsigned long cycleTime = t % 50000UL;

    if (cycleTime < 10000UL)
    {
        activeBanks = 0;
    }
    else if (cycleTime < 20000UL)
    {
        activeBanks = 1;
    }
    else if (cycleTime < 30000UL)
    {
        activeBanks = 3;
    }
    else if (cycleTime < 40000UL)
    {
        activeBanks = 6;
    }
    else
    {
        activeBanks = 2;
    }

    // ========================================================
    // MAIN 20 ms LOOP
    // ========================================================

    if (millis() - lastLoopMs >= LOOP_DT_MS)
    {
        lastLoopMs = millis();

        Pref = activeBanks * PREF_PER_BANK_W;

        // ====================================================
        // COUNTER #1 : 0 -> 10 -> 0
        // ====================================================

        counterSignal += counterStep;

        if (counterSignal >= 10.0f)
        {
            counterSignal = 10.0f;
            counterStep = -0.1f;
        }
        else if (counterSignal <= 0.0f)
        {
            counterSignal = 0.0f;
            counterStep = 0.1f;
        }

        // ====================================================
        // COUNTER #2 : 0 -> 5 -> 0
        // One count every 2 seconds
        // Total cycle = 20 seconds
        // ====================================================

        if (millis() - lastCounterUpdate >= 2000)
        {
            lastCounterUpdate = millis();

            counter5Signal += counter5Step;

            if (counter5Signal >= 5)
            {
                counter5Signal = 5;
                counter5Step = -1;
            }
            else if (counter5Signal <= 0)
            {
                counter5Signal = 0;
                counter5Step = 1;
            }
        }

        // ====================================================
        // TRANSMIT TO SIMULINK
        //
        // Sends:
        //   Pref
        //   counterSignal
        //   counter5Signal
        //   simulinkValuePlusOne
        //
        // Total = 16 bytes
        // ====================================================

        Serial.write('S');

        Serial.write((uint8_t*)&Pref,
                     sizeof(Pref));

        Serial.write((uint8_t*)&counterSignal,
                     sizeof(counterSignal));

        Serial.write((uint8_t*)&counter5Signal,
                     sizeof(counter5Signal));

        Serial.write((uint8_t*)&simulinkValuePlusOne,
                     sizeof(simulinkValuePlusOne));

        Serial.write('E');
    }
}