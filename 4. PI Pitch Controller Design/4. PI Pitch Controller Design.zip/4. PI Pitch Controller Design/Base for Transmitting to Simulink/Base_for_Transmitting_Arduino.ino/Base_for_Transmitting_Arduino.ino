// ============================================================
// AEOLUS LOAD BANK SCHEDULER & TRIANGLE COUNTER PRACTICE
//
// Arduino generates Pref and counterSignal, then streams both to Simulink
//
// Load Schedule (50-second cycle):
//   0-10 sec  : 0 banks
//  10-20 sec  : 1 bank
//  20-30 sec  : 3 banks
//  30-40 sec  : 6 banks
//  40-50 sec  : 2 banks
//
// Counter Signal Behavior:
//  Counts up from 0 to 10, then down from 10 to 0 continuously.
//  Using a 4-second period (2 seconds up, 2 seconds down).
// ============================================================

const float PREF_PER_BANK_W = 4.05f;
const unsigned long LOOP_DT_MS = 20;

unsigned long lastLoopMs = 0;
int activeBanks = 0;
float Pref = 0.0f;

// Practice Counter Variables
float counterSignal = 0.0f;
float counterStep = 0.1f; // Amount to change each loop iteration

// ============================================================
void setup() {
  Serial.begin(115200);
}

// ============================================================
void loop() {
  unsigned long t = millis();
  
  // Repeat schedule every 50 seconds
  unsigned long cycleTime = t % 50000UL;
  
  if (cycleTime < 10000UL) {
    activeBanks = 0;
  } else if (cycleTime < 20000UL) {
    activeBanks = 1;
  } else if (cycleTime < 30000UL) {
    activeBanks = 3;
  } else if (cycleTime < 40000UL) {
    activeBanks = 6;
  } else {
    activeBanks = 2;
  }
  
  // Timed loop running every 20 milliseconds
  if (millis() - lastLoopMs >= LOOP_DT_MS) {
    lastLoopMs = millis();
    Pref = activeBanks * PREF_PER_BANK_W;
    
    // --- PRACTICE COUNTER LOGIC (0 -> 10 -> 0) ---
    counterSignal += counterStep;
    
    // Turn around at the upper bound (10.0) or lower bound (0.0)
    if (counterSignal >= 10.0f) {
      counterSignal = 10.0f;
      counterStep = -0.1f; // Reverse direction to count down
    } else if (counterSignal <= 0.0f) {
      counterSignal = 0.0f;
      counterStep = 0.1f;  // Reverse direction to count up
    }
    // ----------------------------------------------

    // 1. Send the Header token 'S' expected by Simulink
    Serial.write('S'); 
    
    // 2. Send the 4 raw binary bytes of Pref (First output port)
    Serial.write((uint8_t*)&Pref, sizeof(Pref)); 
    
    // 3. Send the 4 raw binary bytes of counterSignal (Second output port)
    Serial.write((uint8_t*)&counterSignal, sizeof(counterSignal));
    
    // 4. Send the End token 'E' expected by Simulink
    Serial.write('E'); 
  }
}
