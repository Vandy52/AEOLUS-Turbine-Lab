// ============================================================
// AEOLUS LOAD BANK SCHEDULER (SCALED FOR ACTUATOR LIMITS)
//
// Arduino generates Pref and sends it to Simulink
//
// Scaled Load Schedule (Max 3 banks = 12.15W to avoid saturation):
//   0-10 sec  : 0 banks (0.00W)
//  10-20 sec  : 1 bank  (4.05W)
//  20-30 sec  : 3 banks (12.15W)
//  30-40 sec  : 2 banks (8.10W)
//  40-50 sec  : 1 bank  (4.05W)
//  50+ sec    : repeat
//
// Double check that under the "Solver Selection", "Solver" is set to "ode4 (Runge-Kutta)" (use ctr + E to get to "Solver Selection")
//
// ============================================================

const float PREF_PER_BANK_W = 4.05f;
const unsigned long LOOP_DT_MS = 20;

unsigned long lastLoopMs = 0;
int activeBanks = 0;
float Pref = 0.0f;

// ============================================================
void setup() {
  Serial.begin(115200);
}

// ============================================================
void loop() {
  unsigned long t = millis();
  
  // Repeat every 50 seconds
  unsigned long cycleTime = t % 50000UL;
  
  if (cycleTime < 10000UL) {
    activeBanks = 0; // 0.00W
  } else if (cycleTime < 20000UL) {
    activeBanks = 1; // 4.05W
  } else if (cycleTime < 30000UL) {
    activeBanks = 3; // 12.15W (Peak power remains well below 16W)
  } else if (cycleTime < 40000UL) {
    activeBanks = 2; // 8.10W
  } else {
    activeBanks = 1; // 4.05W
  }
  
  if (millis() - lastLoopMs >= LOOP_DT_MS) {
    lastLoopMs = millis();
    Pref = activeBanks * PREF_PER_BANK_W;
    
    // 1. Send the Header token 'S' expected by Simulink
    Serial.write('S'); 
    
    // 2. Send the 4 raw binary bytes of the float variable
    Serial.write((uint8_t*)&Pref, sizeof(Pref)); 
    
    // 3. Send the End token 'E' expected by Simulink
    Serial.write('E'); 
  }
}