//Target Pitch Angle
#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

// ============================================================
// PIN DEFINITIONS
// ============================================================

#define TLV0_PWR 12
#define TLV1_PWR 10

#define M1_SLEEP 7
#define M1_EN1   6
#define M1_EN0   5

// ============================================================
// SENSOR OBJECTS & CALIBRATION BOUNDS
// ============================================================

TLx493D_A1B6 mag_collective(Wire, TLx493D_IIC_ADDR_A0_e);

// Sensor bounds set via Serial input during setup
float coll_deg_min = 0.0f;
float coll_deg_max = 0.0f;

float coll_motor_drivetime_ms = 120.0f; 
const float PITCH_MIN_DEG = 0.0f;

// ============================================================
// HELPER FUNCTIONS & SENSOR LOGIC
// ============================================================

float get_pitch_max_deg()
{
    return fabs(coll_deg_max - coll_deg_min);
}

float get_raw_angle_deg(TLx493D_A1B6 &MagSensor)
{
    double xmag = 0.0, ymag = 0.0, zmag = 0.0;
    MagSensor.getMagneticField(&xmag, &ymag, &zmag);

    float rad = atan2((float)ymag, (float)xmag);
    float deg = rad * (180.0f / 3.14159265f);
    if (deg < 0.0f) deg += 360.0f;
    return deg;
}

float get_collective_percent(float current_sensor_deg)
{
    float deg_delta = coll_deg_max - coll_deg_min;
    if (fabs(deg_delta) < 0.01f) return 0.0f;

    float raw_percent = (current_sensor_deg - coll_deg_min) / deg_delta;
    return constrain(raw_percent, 0.0f, 1.0f);
}

float get_current_pitch_deg()
{
    float raw_deg = get_raw_angle_deg(mag_collective);
    float col_pct = get_collective_percent(raw_deg);
    float pitch_max = get_pitch_max_deg();
    return PITCH_MIN_DEG + col_pct * (pitch_max - PITCH_MIN_DEG);
}

void drive_motor(int pin_en0, int pin_en1, int pin_sleep, bool reverse, int time_ms)
{
    digitalWrite(pin_sleep, HIGH);

    if (reverse)
    {
        digitalWrite(pin_en0, HIGH);
        digitalWrite(pin_en1, LOW);
    }
    else
    {
        digitalWrite(pin_en0, LOW);
        digitalWrite(pin_en1, HIGH);
    }

    delay(time_ms);

    digitalWrite(pin_sleep, LOW);
    digitalWrite(pin_en0, LOW);
    digitalWrite(pin_en1, LOW);
}

// ============================================================
// COMMAND PITCH TO TARGET
// ============================================================

void commandPitchToTarget(float targetPitchDeg)
{
    float pitch_max = get_pitch_max_deg();
    targetPitchDeg = constrain(targetPitchDeg, PITCH_MIN_DEG, pitch_max);

    float target_pct = (targetPitchDeg - PITCH_MIN_DEG) / (pitch_max - PITCH_MIN_DEG);
    target_pct = constrain(target_pct, 0.0f, 1.0f);

    const float TOLERANCE_PCT = 0.02f; // ~2% position window

    Serial.print(F("Moving to target pitch: "));
    Serial.print(targetPitchDeg, 1);
    Serial.println(F(" deg..."));

    while (true)
    {
        float current_sensor_deg = get_raw_angle_deg(mag_collective);
        float current_pct        = get_collective_percent(current_sensor_deg);

        float error_pct = target_pct - current_pct;

        if (fabs(error_pct) <= TOLERANCE_PCT)
        {
            break;
        }

        bool reverse_drive = false;
        if (coll_deg_max > coll_deg_min)
        {
            reverse_drive = (error_pct < 0.0f); 
        }
        else
        {
            reverse_drive = (error_pct > 0.0f);
        }

        if (error_pct > 0.0f && current_pct >= 1.0f)
        {
            Serial.println(F("[HALT] Reached 100% Upper Limit!"));
            break;
        }
        if (error_pct < 0.0f && current_pct <= 0.0f)
        {
            Serial.println(F("[HALT] Reached 0% Lower Limit!"));
            break;
        }

        drive_motor(M1_EN0, M1_EN1, M1_SLEEP, reverse_drive, coll_motor_drivetime_ms);
        delay(30);
    }

    Serial.print(F("--> Target reached! Current Pitch: "));
    Serial.print(get_current_pitch_deg(), 2);
    Serial.println(F(" deg\n"));
}

float readFloatFromSerial()
{
    while (Serial.available() == 0)
    {
        delay(10);
    }
    float val = Serial.parseFloat();
    while (Serial.available() > 0) Serial.read(); // Clear buffer
    return val;
}

// ============================================================
// SETUP
// ============================================================

void setup()
{
    Serial.begin(250000);
    while (!Serial) delay(10);

    // Motor Control Pins
    pinMode(M1_EN0, OUTPUT);
    pinMode(M1_EN1, OUTPUT);
    pinMode(M1_SLEEP, OUTPUT);

    digitalWrite(M1_EN0, LOW);
    digitalWrite(M1_EN1, LOW);
    digitalWrite(M1_SLEEP, LOW);

    // Power management for TLV Sensor
    pinMode(SDA, OUTPUT);
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(500);

    digitalWrite(SDA, LOW);
    delay(50);
    digitalWrite(TLV0_PWR, HIGH);
    delay(250);

    pinMode(SDA, INPUT);
    delay(50);
    digitalWrite(TLV1_PWR, HIGH);
    delay(250);

    Wire.begin();
    Wire.setClock(100000);

    if (!mag_collective.begin())
    {
        Serial.println(F("CRITICAL ERROR: TLV1 Sensor failed to initialize!"));
        while (true) delay(100);
    }

    Serial.println(F("=================================================="));
    Serial.println(F("          MANUAL PITCH BOUND SETUP                "));
    Serial.println(F("=================================================="));
    
    Serial.print(F("Current Raw Magnetic Angle: "));
    Serial.print(get_raw_angle_deg(mag_collective), 2);
    Serial.println(F(" deg\n"));

    // Prompt for bounds
    Serial.println(F("1. Enter MIN pitch sensor angle (0 deg pitch):"));
    coll_deg_min = readFloatFromSerial();
    Serial.print(F("--> MIN bound set to: "));
    Serial.println(coll_deg_min, 2);

    Serial.println(F("\n2. Enter MAX pitch sensor angle (MAX deg pitch):"));
    coll_deg_max = readFloatFromSerial();
    Serial.print(F("--> MAX bound set to: "));
    Serial.println(coll_deg_max, 2);

    float total_range = get_pitch_max_deg();
    Serial.println(F("\n=================================================="));
    Serial.print(F("Calibrated pitch range: 0.00 to "));
    Serial.print(total_range, 2);
    Serial.println(F(" degrees."));
    Serial.println(F("=================================================="));
    Serial.println(F("Ready! Type a target pitch angle and press Enter:"));
    Serial.println(F("==================================================\n"));
}

// ============================================================
// LOOP: LISTEN FOR SERIAL COMMANDS
// ============================================================

void loop()
{
    if (Serial.available() > 0)
    {
        float requestedPitch = Serial.parseFloat();

        while (Serial.available() > 0) Serial.read();

        commandPitchToTarget(requestedPitch);
        
        Serial.println(F("Enter next target angle:"));
    }

    delay(20);
}