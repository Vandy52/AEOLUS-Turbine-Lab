// Pitch Toggle Both Ways

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

#define TLV0_PWR 12
#define TLV1_PWR 10

#define M1_SLEEP 7
#define M1_EN1   6
#define M1_EN0   5

char current_direction = '0';
unsigned long lastPrintMs = 0;

TLx493D_A1B6 mag_collective(Wire, TLx493D_IIC_ADDR_A0_e);

// Calculates true linear angle using atan2(Y, X)
// Calculates true linear angle mapped to 0° - 360°
float readLinearAngleDeg(float &outY, float &outX) {
    double x = 0.0, y = 0.0, z = 0.0;
    mag_collective.getMagneticField(&x, &y, &z);
    
    outX = (float)x;
    outY = (float)y;
    
    // Normalized angle calculation (0° to 360° format)
    float rad = atan2(outY, outX);
    float deg = rad * (180.0f / 3.14159265f);
    if (deg < 0) deg += 360.0f; // Eliminates negative angles for simple mapping
    
    return deg;
}

void setup() {
    Serial.begin(250000);
    delay(500);

    pinMode(M1_EN0, OUTPUT);
    pinMode(M1_EN1, OUTPUT);
    pinMode(M1_SLEEP, OUTPUT);

    pinMode(SDA, OUTPUT);
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(M1_EN0, LOW);
    digitalWrite(M1_EN1, LOW);
    digitalWrite(M1_SLEEP, LOW);

    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(500);

    digitalWrite(SDA, LOW);
    delay(50);
    digitalWrite(TLV0_PWR, HIGH);
    delay(250);

    pinMode(SDA, INPUT);
    delay(50);
    digitalWrite(TLV1_PWR, HIGH);
    delay(250);

    Wire.begin();
    Wire.setClock(100000);

    if (!mag_collective.begin()) {
        Serial.println(F("CRITICAL ERROR: TLV1 collective sensor failed!"));
        while (true) delay(100);
    }

    while(Serial.available() > 0) Serial.read();

    Serial.println(F("\n=================================================="));
    Serial.println(F("     2D ANGULAR PITCH DIAGNOSTIC CONTROL          "));
    Serial.println(F("=================================================="));
    Serial.println(F("Commands:"));
    Serial.println(F("  '1' + Enter -> Pitch Forward"));
    Serial.println(F("  '2' + Enter -> Pitch Reverse"));
    Serial.println(F("  ENTER       -> STOP"));
    Serial.println(F("==================================================\n"));
}

void loop() {
    if (Serial.available() > 0) {
        char incomingChar = Serial.read();

        if (incomingChar == '\n' || incomingChar == '\r') {
            if (current_direction != '0') {
                digitalWrite(M1_SLEEP, LOW);
                digitalWrite(M1_EN0, LOW);
                digitalWrite(M1_EN1, LOW);
                current_direction = '0';
                Serial.println(F(">> [STOP] Halting pitch motor."));
            }
            return; 
        }

        if (incomingChar == ' ') return;

        if (incomingChar == '1') {
            Serial.println(F(">> [RUN] Pitch Forward..."));
            digitalWrite(M1_SLEEP, HIGH);
            digitalWrite(M1_EN0, LOW);
            digitalWrite(M1_EN1, HIGH);
            current_direction = '1';
            delay(5);
            while(Serial.available() > 0) Serial.read();
            
        } else if (incomingChar == '2') {
            Serial.println(F(">> [RUN] Pitch Reverse..."));
            digitalWrite(M1_SLEEP, HIGH);
            digitalWrite(M1_EN0, HIGH);
            digitalWrite(M1_EN1, LOW);
            current_direction = '2';
            delay(5);
            while(Serial.available() > 0) Serial.read();
        }
    }

    if (current_direction != '0' && millis() - lastPrintMs >= 200) {
        lastPrintMs = millis();
        
        float yVal = 0.0f, xVal = 0.0f;
        float currentAngle = readLinearAngleDeg(yVal, xVal);
        
        Serial.print(F("Status: "));
        if (current_direction == '1') Serial.print(F("FWD"));
        else Serial.print(F("REV"));
        
        Serial.print(F(" | Y: ")); Serial.print(yVal, 2); Serial.print(F(" mT"));
        Serial.print(F(" | X: ")); Serial.print(xVal, 2); Serial.print(F(" mT"));
        Serial.print(F(" | Calculated Angle: ")); Serial.print(currentAngle, 2); Serial.println(F(" deg"));
    }
}