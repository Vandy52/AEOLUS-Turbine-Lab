// Yaw Toggle Both Ways

#include <Arduino.h>

// MOTOR DRIVER CONTROL (YAW SYSTEM)
#define M0_SLEEP 4  
#define M0_EN1 3    
#define M0_EN0 2    

char current_direction = '0'; // '0'=Stop, '1'=CW, '2'=CCW

void setup() {
  Serial.begin(250000);
  delay(500); // Hardware stabilization delay

  pinMode(M0_EN0, OUTPUT);
  pinMode(M0_EN1, OUTPUT);
  pinMode(M0_SLEEP, OUTPUT);

  // Force safe hardware state immediately using raw pin commands
  digitalWrite(M0_EN0, LOW);
  digitalWrite(M0_EN1, LOW);
  digitalWrite(M0_SLEEP, LOW);

  Serial.println(F("\n=================================================="));
  Serial.println(F("     FLAT YAW MOTOR DIAGNOSTIC CONTROL            "));
  Serial.println(F("=================================================="));
  Serial.println(F("Commands:"));
  Serial.println(F("  Type '1' + Enter -> Run Clockwise (CW)"));
  Serial.println(F("  Type '2' + Enter -> Run Counter-Clockwise (CCW)"));
  Serial.println(F("  Press ENTER (blank text) -> EMERGENCY STOP"));
  Serial.println(F("==================================================\n"));
}

void loop() {
  if (Serial.available() > 0) {
    char incomingChar = Serial.read();

    // Catch isolated Enter key signals to stop
    if (incomingChar == '\n' || incomingChar == '\r') {
      if (current_direction != '0') {
        digitalWrite(M0_EN0, LOW);
        digitalWrite(M0_EN1, LOW);
        digitalWrite(M0_SLEEP, LOW);
        current_direction = '0';
        Serial.println(F(">> [STOP] Enter detected! Halting yaw motor."));
      }
      return; 
    }

    if (incomingChar == ' ') return;

    if (incomingChar == '1') {
      Serial.println(F(">> [RUN] Clockwise (CW)... Press ENTER in empty box to stop."));
      
      // Raw pin execution matching your master code configuration
      digitalWrite(M0_SLEEP, HIGH);
      digitalWrite(M0_EN0, LOW);
      digitalWrite(M0_EN1, HIGH);
      current_direction = '1';
      
      delay(5);
      while(Serial.available() > 0) Serial.read(); // Clear trailing line endings
      
    } else if (incomingChar == '2') {
      Serial.println(F(">> [RUN] Counter-Clockwise (CCW)... Press ENTER in empty box to stop."));
      
      // Raw pin execution matching your master code configuration
      digitalWrite(M0_SLEEP, HIGH);
      digitalWrite(M0_EN0, HIGH);
      digitalWrite(M0_EN1, LOW);
      current_direction = '2';
      
      delay(5);
      while(Serial.available() > 0) Serial.read(); // Clear trailing line endings
      
    } else {
      Serial.print(F("Unknown input [")); Serial.print(incomingChar); Serial.println(F("]. Use '1', '2', or a blank ENTER."));
    }
  }
}