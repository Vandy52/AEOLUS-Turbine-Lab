// ==================================================================================
// ISOLATED PITCH MOTOR BOUNDS & LIVE TELEMETRY TEST (2D ANGULAR TRACKING)
// ==================================================================================
// PURPOSE:
// Tests the pitch mechanism with real-time 2D vector angle feedback.
// Prompts for coll_deg_min and coll_deg_max, reads starting position,
// and drives pitch to MIN (0°), MAX (dynamically calculated sweep range), 
// and back to START while displaying raw vector readings, calculated magnet angle, 
// percent (%), and pitch angle (deg).
//
// This is a good code to use to watch and make sure that the pitch commands
// won't break the mechanical contrants
// 
// ==================================================================================

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

// ============================================================
// PIN DEFINITIONS (PITCH MOTOR & TLV SENSOR ONLY)
// ============================================================

#define TLV0_PWR 12
#define TLV1_PWR 10

#define M1_SLEEP 7
#define M1_EN1   6
#define M1_EN0   5

// ============================================================
// SENSOR OBJECT & VARIABLES
// ============================================================

TLx493D_A1B6 mag_collective(Wire, TLx493D_IIC_ADDR_A0_e);

// Default angular bounds in 0° to 360° format (Safety band)
float coll_deg_min = 130.0f; // Sensor angle mapped to 0.0° pitch
float coll_deg_max = 210.0f; // Sensor angle mapped to MAX pitch

float coll_motor_drivetime_ms = 120.0f; // Pulses motor in 120ms increments

const float PITCH_MIN_DEG = 0.0f;

// Helper function to dynamically derive MAX pitch from active bounds
float get_pitch_max_deg()
{
    return fabs(coll_deg_max - coll_deg_min);
}

// ============================================================
// FUNCTION DECLARATIONS
// ============================================================

float getFloatingInput();
void waitForUser();
float get_raw_angle_deg(TLx493D_A1B6 &MagSensor, float &outY, float &outX);
float get_collective_percent(float current_sensor_deg);
float get_current_pitch_deg(float current_sensor_deg);
void drive_motor(int pin_en0, int pin_en1, int pin_sleep, bool reverse, int time_ms);
void commandPitchToTarget(float targetPitchDeg);

// ============================================================
// ROBUST SERIAL INPUT READER
// ============================================================

float getFloatingInput()
{
    while (Serial.available() > 0) Serial.read();

    String inputString = "";

    while (true)
    {
        if (Serial.available() > 0)
        {
            char c = Serial.read();

            if (c == '\n' || c == '\r')
            {
                inputString.trim();
                if (inputString.length() > 0)
                {
                    return inputString.toFloat();
                }
            }
            else
            {
                inputString += c;
            }
        }
        delay(10);
    }
}

void waitForUser()
{
    Serial.println(F(">>> Type 'Y' and press Send to continue..."));

    while (true)
    {
        if (Serial.available() > 0)
        {
            char ch = Serial.read();

            if (ch == 'Y' || ch == 'y')
            {
                delay(10);
                while (Serial.available() > 0) Serial.read();
                break;
            }
        }
        delay(20);
    }
}

// ============================================================
// 2D ANGULAR TRACKING CALCULATIONS
// ============================================================

// Reads X and Y magnetic fields and calculates a 0° to 360° angle
float get_raw_angle_deg(TLx493D_A1B6 &MagSensor, float &outY, float &outX)
{
    double xmag = 0.0, ymag = 0.0, zmag = 0.0;
    MagSensor.getMagneticField(&xmag, &ymag, &zmag);
    outX = (float)xmag;
    outY = (float)ymag;

    float rad = atan2(outY, outX);
    float deg = rad * (180.0f / 3.14159265f);
    if (deg < 0.0f) deg += 360.0f; // Mapped smoothly to 0 - 360 degrees
    return deg;
}

// Converts measured sensor angle into a 0.0 - 1.0 position percentage
float get_collective_percent(float current_sensor_deg)
{
    float deg_delta = coll_deg_max - coll_deg_min;
    if (fabs(deg_delta) < 0.01f) return 0.0f;

    float raw_percent = (current_sensor_deg - coll_deg_min) / deg_delta;
    return constrain(raw_percent, 0.0f, 1.0f);
}

// Converts sensor angle directly into mapped pitch degrees dynamically (0° to pitch_max)
float get_current_pitch_deg(float current_sensor_deg)
{
    float col_pct = get_collective_percent(current_sensor_deg);
    float pitch_max = get_pitch_max_deg();
    return PITCH_MIN_DEG + col_pct * (pitch_max - PITCH_MIN_DEG);
}

// ============================================================
// MOTOR DRIVER & TARGET MOVEMENT WITH LIVE TELEMETRY
// ============================================================

void drive_motor(int pin_en0, int pin_en1, int pin_sleep, bool reverse, int time_ms)
{
    digitalWrite(pin_sleep, HIGH);

    if (reverse)
    {
        digitalWrite(pin_en0, HIGH);
        digitalWrite(pin_en1, LOW);
    }
    else
    {
        digitalWrite(pin_en0, LOW);
        digitalWrite(pin_en1, HIGH);
    }

    delay(time_ms);

    digitalWrite(pin_sleep, LOW);
    digitalWrite(pin_en0, LOW);
    digitalWrite(pin_en1, LOW);
}

void commandPitchToTarget(float targetPitchDeg)
{
    float pitch_max = get_pitch_max_deg();

    // Map requested pitch angle to target percentage
    float target_pct = (targetPitchDeg - PITCH_MIN_DEG) / (pitch_max - PITCH_MIN_DEG);
    target_pct = constrain(target_pct, 0.0f, 1.0f);

    // Tolerance window (~1.5 degrees or ~3% window)
    const float TOLERANCE_PCT = 0.03f;

    int pulseCount = 0;

    Serial.println(F("\n--- MOTOR MOVEMENT STARTED ---"));
    Serial.print(F("Target Pitch: ")); Serial.print(targetPitchDeg, 1);
    Serial.print(F(" deg | Target Pct: ")); Serial.print(target_pct * 100.0f, 1); Serial.println(F("%"));

    // Runs continuously until target is reached or a safety limit is hit
    while (true)
    {
        float outY = 0.0f, outX = 0.0f;
        float current_sensor_deg = get_raw_angle_deg(mag_collective, outY, outX);
        float current_pct        = get_collective_percent(current_sensor_deg);
        float current_pitch_deg  = get_current_pitch_deg(current_sensor_deg);

        // Display real-time telemetry while travelling
        Serial.print(F("[Step ")); Serial.print(pulseCount); Serial.print(F("] "));
        Serial.print(F("Sensor Angle: ")); Serial.print(current_sensor_deg, 1); Serial.print(F(" deg | "));
        Serial.print(F("Pct: "));         Serial.print(current_pct * 100.0f, 1); Serial.print(F("% | "));
        Serial.print(F("Pitch: "));       Serial.print(current_pitch_deg, 1); Serial.println(F(" deg"));

        float error_pct = target_pct - current_pct;

        // Stopped within target tolerance window
        if (fabs(error_pct) <= TOLERANCE_PCT)
        {
            Serial.println(F(">>> TARGET REACHED SUCCESSFULLY <<<"));
            break; 
        }

        // Determine drive direction based on angle progression direction
        bool reverse_drive = false;
        if (coll_deg_max > coll_deg_min)
        {
            reverse_drive = (error_pct < 0.0f); 
        }
        else
        {
            reverse_drive = (error_pct > 0.0f);
        }

        // Bound safety check: Don't push past 0% or 100%
        if (error_pct > 0.0f && current_pct >= 1.0f)
        {
            Serial.println(F("[SAFETY HALT] Reached 100% Upper Limit!"));
            break;
        }
        if (error_pct < 0.0f && current_pct <= 0.0f)
        {
            Serial.println(F("[SAFETY HALT] Reached 0% Lower Limit!"));
            break;
        }

        // Pulse the motor
        drive_motor(M1_EN0, M1_EN1, M1_SLEEP, reverse_drive, coll_motor_drivetime_ms);
        pulseCount++;

        delay(30); // Short settle time between motor pulses
    }
}

// ============================================================
// SETUP & TEST EXECUTION
// ============================================================

void setup()
{
    Serial.begin(250000);
    while (!Serial) delay(10);

    // Motor Pins
    pinMode(M1_EN0, OUTPUT);
    pinMode(M1_EN1, OUTPUT);
    pinMode(M1_SLEEP, OUTPUT);

    digitalWrite(M1_EN0, LOW);
    digitalWrite(M1_EN1, LOW);
    digitalWrite(M1_SLEEP, LOW);

    // Power sequence for TLV magnetic sensor
    pinMode(SDA, OUTPUT);
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(500);

    digitalWrite(SDA, LOW);
    delay(50);
    digitalWrite(TLV0_PWR, HIGH);
    delay(250);

    pinMode(SDA, INPUT);
    delay(50);
    digitalWrite(TLV1_PWR, HIGH);
    delay(250);

    Wire.begin();
    Wire.setClock(100000);

    if (!mag_collective.begin())
    {
        Serial.println(F("CRITICAL ERROR: TLV1 Collective Sensor failed to initialize!"));
        while (true) delay(100);
    }

    Serial.println(F("=================================================="));
    Serial.println(F("   REAL-TIME TELEMETRY PITCH MOTOR SWEEP TEST     "));
    Serial.println(F("=================================================="));

    // Prompt user for angular bounds
    Serial.println(F("\nEnter coll_deg_min (Sensor Angle in deg at 0 pitch):"));
    coll_deg_min = getFloatingInput();
    Serial.print(F("-> Received coll_deg_min = ")); Serial.println(coll_deg_min, 2);

    Serial.println(F("\nEnter coll_deg_max (Sensor Angle in deg at MAX pitch):"));
    coll_deg_max = getFloatingInput();
    Serial.print(F("-> Received coll_deg_max = ")); Serial.println(coll_deg_max, 2);

    // Bound Validation Check
    if (fabs(coll_deg_max - coll_deg_min) < 1.0f)
    {
        Serial.println(F("\n[WARNING] Bounds too close! Reverting to defaults (130.0, 210.0)."));
        coll_deg_min = 130.0f;
        coll_deg_max = 210.0f;
    }

    float pitch_max = get_pitch_max_deg();

    Serial.println();
    Serial.print(F("-> ACTIVE coll_deg_min (0.0 deg pitch)  = ")); Serial.print(coll_deg_min, 2); Serial.println(F(" deg"));
    Serial.print(F("-> ACTIVE coll_deg_max (")); Serial.print(pitch_max, 1); Serial.print(F(" deg pitch) = ")); Serial.print(coll_deg_max, 2); Serial.println(F(" deg"));

    // Take initial reading
    delay(100);
    float dummyY = 0.0f, dummyX = 0.0f;
    float start_sensor_deg = get_raw_angle_deg(mag_collective, dummyY, dummyX);
    float start_pct        = get_collective_percent(start_sensor_deg);
    float start_pitch_deg  = get_current_pitch_deg(start_sensor_deg);

    Serial.println(F("\n--------------------------------------------------"));
    Serial.print(F("INITIAL POSITION: Sensor ")); Serial.print(start_sensor_deg, 2); Serial.print(F(" deg | "));
    Serial.print(start_pct * 100.0f, 1); Serial.print(F("% | Pitch "));
    Serial.print(start_pitch_deg, 2); Serial.println(F(" deg"));
    Serial.println(F("--------------------------------------------------"));

    Serial.println(F("\nPress 'Y' to start end-to-end test sequence..."));
    waitForUser();

    // STEP 1: Current position -> PITCH_MIN (0.0°)
    Serial.println(F("\n=================================================="));
    Serial.println(F("[STEP 1/3] Driving to PITCH_MIN (0.0 deg)..."));
    Serial.println(F("=================================================="));
    commandPitchToTarget(PITCH_MIN_DEG);
    delay(1000);

    // STEP 2: PITCH_MIN (0.0°) -> PITCH_MAX (e.g. 80.0°)
    Serial.println(F("\n=================================================="));
    Serial.print(F("[STEP 2/3] Driving to PITCH_MAX ("));
    Serial.print(pitch_max, 1); Serial.println(F(" deg)..."));
    Serial.println(F("=================================================="));
    commandPitchToTarget(pitch_max);
    delay(1000);

    // STEP 3: Return to original starting pitch angle
    Serial.println(F("\n=================================================="));
    Serial.print(F("[STEP 3/3] Returning to starting position ("));
    Serial.print(start_pitch_deg, 1); Serial.println(F(" deg pitch)..."));
    Serial.println(F("=================================================="));
    commandPitchToTarget(start_pitch_deg);
    delay(1000);

    Serial.println(F("\n=================================================="));
    Serial.println(F("         PITCH TEST SEQUENCE COMPLETE             "));
    Serial.println(F("=================================================="));
}

void loop()
{
    // Idle after test completion
}