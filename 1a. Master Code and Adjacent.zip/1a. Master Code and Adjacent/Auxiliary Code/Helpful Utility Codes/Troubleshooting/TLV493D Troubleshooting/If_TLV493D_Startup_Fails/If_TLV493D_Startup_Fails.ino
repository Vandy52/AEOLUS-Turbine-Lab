// Code in library:
//
// 5 V -> 3.3V fix                                                 // Lines 17 - 69
// U3 SDA-HIGH ADDRESS SCANNER                                     // Lines 71 - 108
// U2 SDA-HIGH ADDRESS SCANNER                                     // Lines 110 - 144
// Power cycling test for TLV0/TLV1                                // Lines 146 - 216
// BOTH TLV ADDRESS SCANNER - Original Designer Boot Sequence      // Lines 218 - 280
// TLV1 tiny latch-probe test                                      // Lines 282 - 308
// TLV POWER ISOLATION TEST                                        // Lines 311 - 424
// TLV1 HARDWARE TEST                                              // Lines 426 - 486
// TLV0 HARDWARE TEST                                              // Lines 489 - 570
// TLV0 ADDRESS SCANNER                                            // Lines 572 - 635
// TLV1 ADDRESS SCANNER                                            // Lines 627 - 713
// TLV1 FULL ADDRESS SCANNER                                       // Lines 716 - 795
 

// 5 V -> 3.3V fix

#include <Arduino.h>

#define TLV0_PWR 12
#define TLV1_PWR 10

void waitEnter() {
  while (Serial.available()) Serial.read();
  Serial.println("Press ENTER after measuring...");
  while (!Serial.available()) {}
  while (Serial.available()) Serial.read();
}

void setup() {
  Serial.begin(250000);
  delay(1500);

  pinMode(TLV0_PWR, OUTPUT);
  pinMode(TLV1_PWR, OUTPUT);
  pinMode(SDA, INPUT);
  pinMode(SCL, INPUT);

  Serial.println("\n=== TLV POWER / BUS VOLTAGE PROBE TEST ===");

  digitalWrite(TLV0_PWR, LOW);
  digitalWrite(TLV1_PWR, LOW);
  Serial.println("STATE 1: TLV0 OFF, TLV1 OFF");
  Serial.println("Measure TLV0 VDD, TLV1 VDD, SDA, SCL");
  waitEnter();

  digitalWrite(TLV0_PWR, HIGH);
  digitalWrite(TLV1_PWR, LOW);
  Serial.println("STATE 2: TLV0 ON, TLV1 OFF");
  Serial.println("Measure TLV0 VDD, TLV1 VDD, SDA, SCL");
  waitEnter();

  digitalWrite(TLV0_PWR, LOW);
  digitalWrite(TLV1_PWR, HIGH);
  Serial.println("STATE 3: TLV0 OFF, TLV1 ON");
  Serial.println("Measure TLV0 VDD, TLV1 VDD, SDA, SCL");
  waitEnter();

  digitalWrite(TLV0_PWR, HIGH);
  digitalWrite(TLV1_PWR, HIGH);
  Serial.println("STATE 4: TLV0 ON, TLV1 ON");
  Serial.println("Measure TLV0 VDD, TLV1 VDD, SDA, SCL");
  waitEnter();

  Serial.println("Test complete.");
}

void loop() {}

// // U3 SDA-HIGH ADDRESS SCANNER
// #include <Arduino.h>
// #include <Wire.h>

// #define TLV1_PWR 10

// void setup() {
//   Serial.begin(250000);
//   delay(1500);

//   Serial.println("\n=== U3 SDA-HIGH ADDRESS SCANNER ===");

//   pinMode(TLV1_PWR, OUTPUT);

//   // Release SDA so pullup makes it HIGH
//   pinMode(SDA, INPUT);

//   // Power cycle U3
//   digitalWrite(TLV1_PWR, LOW);
//   delay(500);

//   digitalWrite(TLV1_PWR, HIGH);
//   delay(250);

//   Wire.begin();
//   Wire.setClock(100000);

//   for (byte addr = 1; addr < 127; addr++) {
//     Wire.beginTransmission(addr);
//     if (Wire.endTransmission() == 0) {
//       Serial.print("Found 0x");
//       if (addr < 16) Serial.print("0");
//       Serial.println(addr, HEX);
//     }
//   }
// }

// void loop() {}

// // U2 SDA-HIGH ADDRESS SCANNER
// #include <Arduino.h>
// #include <Wire.h>

// #define TLV0_PWR 12

// void setup() {
//   Serial.begin(250000);
//   delay(1500);

//   Serial.println("\n=== U2 SDA-HIGH ADDRESS SCANNER ===");

//   pinMode(TLV0_PWR, OUTPUT);
//   pinMode(SDA, INPUT);        // release SDA, pullup makes it HIGH 

//   digitalWrite(TLV0_PWR, LOW);
//   delay(500);

//   digitalWrite(TLV0_PWR, HIGH);
//   delay(250);

//   Wire.begin();
//   Wire.setClock(100000);

//   for (byte addr = 1; addr < 127; addr++) {
//     Wire.beginTransmission(addr);
//     if (Wire.endTransmission() == 0) {
//       Serial.print("Found 0x");
//       if (addr < 16) Serial.print("0");
//       Serial.println(addr, HEX);
//     }
//   }
// }

// void loop() {}

// // Power cycling test for TLV0/TLV1

// #include <Arduino.h>

// //#define TLV0_PWR 12   // U2 VDD connected here
// #define TLV1_PWR 10

// void waitForEnter()
// {
//     while (Serial.available()) Serial.read();

//     Serial.println("Press ENTER to continue...");

//     while (!Serial.available())
//     {
//     }

//     while (Serial.available()) Serial.read();
// }

// void setup()
// {
//     Serial.begin(250000);
//     delay(1500);

//     //Serial.println("\n=== U2 VDD POWER TEST ===");
//     Serial.println("\n=== U3 VDD POWER TEST ===");

//     //pinMode(TLV0_PWR, OUTPUT);
//     pinMode(TLV1_PWR, OUTPUT);


//     // OFF
//     //digitalWrite(TLV0_PWR, LOW);
//     digitalWrite(TLV1_PWR, LOW);

//     //Serial.println("U2 OFF");
//     Serial.println("U3 OFF");
//     //Serial.println("Measure U2 pin 4 (VDD) to GND.");
//     Serial.println("Measure U3 pin 4 (VDD) to GND.");
//     Serial.println("Expected: ~0V");
//     waitForEnter();

//     // ON
//     //digitalWrite(TLV0_PWR, HIGH);
//     digitalWrite(TLV1_PWR, HIGH);

//     //Serial.println("U2 ON");
//     Serial.println("U3 ON");
//     //Serial.println("Measure U2 pin 4 (VDD) to GND.");
//     Serial.println("Measure U3 pin 4 (VDD) to GND.");
//     Serial.println("Expected: ~5V");
//     waitForEnter();

//     // OFF again
//     //digitalWrite(TLV0_PWR, LOW);
//     digitalWrite(TLV1_PWR, LOW);

//     //Serial.println("U2 OFF AGAIN");
//     Serial.println("U3 OFF AGAIN");
//     //Serial.println("Measure U2 pin 4 (VDD) to GND.");
//     Serial.println("Measure U3 pin 4 (VDD) to GND.");
//     Serial.println("Expected: ~0V");
//     waitForEnter();

//     Serial.println("Test complete.");
// }

// void loop()
// {
// }

// // BOTH TLV ADDRESS SCANNER - Original Designer Boot Sequence

// #include <Arduino.h>
// #include <Wire.h>

// #define TLV0_PWR 12
// #define TLV1_PWR 10

// void setup() {
//   Serial.begin(250000);
//   delay(1500);

//   Serial.println("\n=== BOTH TLV ADDRESS SCANNER ===");

//   pinMode(SDA, OUTPUT);
//   pinMode(TLV0_PWR, OUTPUT);
//   pinMode(TLV1_PWR, OUTPUT);

//   digitalWrite(TLV0_PWR, LOW);
//   digitalWrite(TLV1_PWR, LOW);
//   digitalWrite(SDA, LOW);
//   delay(500);

//   // Original designer sequence
//   digitalWrite(SDA, LOW);
//   delay(20);
//   digitalWrite(TLV0_PWR, HIGH);
//   delay(20);

//   digitalWrite(SDA, HIGH);
//   delay(20);
//   digitalWrite(TLV1_PWR, HIGH);
//   delay(20);

//   Wire.begin();
//   Wire.setClock(100000);

//   Serial.println("Scanning all I2C addresses...");

//   bool found = false;

//   for (byte addr = 1; addr < 127; addr++) {
//     Wire.beginTransmission(addr);
//     byte error = Wire.endTransmission();

//     if (error == 0) {
//       found = true;
//       Serial.print("Found device: DEC ");
//       Serial.print(addr);
//       Serial.print("  HEX 0x");
//       if (addr < 16) Serial.print("0");
//       Serial.println(addr, HEX);
//     }
//   }

//   if (!found) {
//     Serial.println("No devices found.");
//   }

//   Serial.println("Scan complete.");
// }

// void loop() {}

// // TLV1 tiny latch-probe test

// #include <Arduino.h>

// #define TLV0_PWR 12
// #define TLV1_PWR 10

// void setup() {
//   Serial.begin(250000);
//   delay(1500);

//   pinMode(TLV0_PWR, OUTPUT);
//   pinMode(TLV1_PWR, OUTPUT);

//   digitalWrite(TLV0_PWR, LOW);
//   digitalWrite(TLV1_PWR, LOW);

//   pinMode(SDA, INPUT); // release SDA, pullup should raise it

//   Serial.println("Measure U3 SDA/ADDR to GND now. Should be ~3.3V.");
//   delay(15000);

//   Serial.println("Powering TLV1 now.");
//   digitalWrite(TLV1_PWR, HIGH);
// }

// void loop() {}


// // TLV POWER ISOLATION TEST
// #include <Arduino.h>

// #define TLV0_PWR 12
// #define TLV1_PWR 10

// void waitForEnter()
// {
//     while (Serial.available())
//         Serial.read(); // Flush buffer

//     Serial.println();
//     Serial.println("Press ENTER to continue...");

//     while (!Serial.available())
//     {
//         // Wait for user input
//     }

//     while (Serial.available())
//         Serial.read(); // Clear received characters
// }

// void setup()
// {
//     Serial.begin(250000);

//     while (!Serial)
//     {
//         ; // Wait for Serial connection
//     }

//     pinMode(TLV0_PWR, OUTPUT);
//     pinMode(TLV1_PWR, OUTPUT);

//     //
//     // Initial OFF state
//     //
//     digitalWrite(TLV0_PWR, LOW);
//     digitalWrite(TLV1_PWR, LOW);

//     Serial.println();
//     Serial.println("================================");
//     Serial.println(" TLV POWER ISOLATION TEST");
//     Serial.println("================================");

//     Serial.println();
//     Serial.println("STATE 0: BOTH OFF");
//     Serial.println("Measure:");
//     Serial.println("  U2 VDD -> GND");
//     Serial.println("  U3 VDD -> GND");

//     waitForEnter();

//     //
//     // TEST A
//     //
//     digitalWrite(TLV0_PWR, HIGH);
//     digitalWrite(TLV1_PWR, LOW);

//     Serial.println();
//     Serial.println("STATE 1: TLV0 ON, TLV1 OFF");
//     Serial.println("D12 = HIGH");
//     Serial.println("D10 = LOW");
//     Serial.println("Measure:");
//     Serial.println("  U2 VDD -> GND");
//     Serial.println("  U3 VDD -> GND");

//     waitForEnter();

//     //
//     // BOTH OFF AGAIN
//     //
//     digitalWrite(TLV0_PWR, LOW);
//     digitalWrite(TLV1_PWR, LOW);

//     Serial.println();
//     Serial.println("STATE 2: BOTH OFF");
//     Serial.println("Measure:");
//     Serial.println("  U2 VDD -> GND");
//     Serial.println("  U3 VDD -> GND");

//     waitForEnter();

//     //
//     // TEST B
//     //
//     digitalWrite(TLV0_PWR, LOW);
//     digitalWrite(TLV1_PWR, HIGH);

//     Serial.println();
//     Serial.println("STATE 3: TLV0 OFF, TLV1 ON");
//     Serial.println("D12 = LOW");
//     Serial.println("D10 = HIGH");
//     Serial.println("Measure:");
//     Serial.println("  U2 VDD -> GND");
//     Serial.println("  U3 VDD -> GND");

//     waitForEnter();

//     //
//     // FINAL OFF
//     //
//     digitalWrite(TLV0_PWR, LOW);
//     digitalWrite(TLV1_PWR, LOW);

//     Serial.println();
//     Serial.println("STATE 4: COMPLETE");
//     Serial.println("Both outputs LOW");
// }

// void loop()
// {
// }

// // TLV1 HARDWARE TEST

// #include <Arduino.h>
// #include <Wire.h>
// #include <TLx493D_inc.hpp>

// using namespace ifx::tlx493d;

// #define TLV0_PWR 12
// #define TLV1_PWR 10

// //TLx493D_A1B6 mag_tlv1(Wire, TLx493D_IIC_ADDR_A0_e);
// TLx493D_A1B6 mag_tlv1(Wire, TLx493D_IIC_ADDR_A4_e);

// void setup() {
//   Serial.begin(250000);
//   delay(1500);

//   Serial.println(F("\n=== TLV1 HARDWARE TEST ==="));

//   pinMode(SDA, OUTPUT);
//   pinMode(TLV0_PWR, OUTPUT);
//   pinMode(TLV1_PWR, OUTPUT);

//   digitalWrite(TLV0_PWR, LOW);
//   digitalWrite(TLV1_PWR, LOW);
//   digitalWrite(SDA, LOW);
//   delay(500);

//   digitalWrite(TLV0_PWR, LOW);
//   digitalWrite(SDA, HIGH);
//   delay(50);
//   digitalWrite(TLV1_PWR, HIGH);
//   delay(250);

//   Wire.begin();
//   Wire.setClock(100000);

//   Serial.println(F("Attempting TLV1 begin()"));

//   if (!mag_tlv1.begin()) {
//     Serial.println(F("FAILED: TLV1 did not ACK"));
//     while (1);
//   }

//   Serial.println(F("SUCCESS: TLV1 detected"));
// }

// void loop() {
//   double x, y, z;
//   mag_tlv1.getMagneticField(&x, &y, &z);

//   Serial.print("X=");
//   Serial.print(x);
//   Serial.print(" Y=");
//   Serial.print(y);
//   Serial.print(" Z=");
//   Serial.println(z);

//   delay(500);
// }


// // TLV0 HARDWARE TEST

// #include <Arduino.h>
// #include <Wire.h>
// #include <TLx493D_inc.hpp>

// using namespace ifx::tlx493d;

// #define TLV0_PWR 12
// #define TLV1_PWR 10

// TLx493D_A1B6 mag_tlv0(Wire, TLx493D_IIC_ADDR_A0_e);
// //TLx493D_A1B6 mag_tlv0(Wire, TLx493D_IIC_ADDR_A4_e);

// void setup()
// {
//     Serial.begin(250000);
//     delay(1500);

//     Serial.println(F("\n=== TLV0 HARDWARE TEST ==="));

//     pinMode(SDA, OUTPUT);
//     pinMode(TLV0_PWR, OUTPUT);
//     pinMode(TLV1_PWR, OUTPUT);

//     digitalWrite(TLV0_PWR, LOW);
//     digitalWrite(TLV1_PWR, LOW);

//     delay(500);

//     //
//     // Address latch sequence
//     //

//     digitalWrite(TLV1_PWR, LOW);   // Keep TLV1 OFF
//     digitalWrite(SDA, LOW);        // Latch TLV0 as A0
//     delay(50);

//     digitalWrite(TLV0_PWR, HIGH);  // Power only TLV0
//     delay(250);

//     //
//     // Start hardware I2C
//     //

//     Wire.begin();
//     Wire.setClock(100000);

//     Serial.println(F("Attempting TLV0 begin()"));

//     Serial.print("A4 = ");
//     Serial.println(analogRead(A4));

//     Serial.print("A5 = ");
//     Serial.println(analogRead(A5));

//     if (!mag_tlv0.begin())
//     {
//         Serial.println(F("FAILED: TLV0 did not ACK"));
//         while (1);
//     }

//     Serial.println(F("SUCCESS: TLV0 detected"));
// }

// void loop()
// {
//     double x, y, z;

//     mag_tlv0.getMagneticField(&x, &y, &z);

//     Serial.print("X=");
//     Serial.print(x);

//     Serial.print(" Y=");
//     Serial.print(y);

//     Serial.print(" Z=");
//     Serial.println(z);

//     delay(500);
// }

// // TLV0 ADDRESS SCANNER
// #include <Arduino.h>
// #include <Wire.h>

// #define TLV0_PWR 12
// #define TLV1_PWR 10

// void setup() {
//   Serial.begin(250000);
//   delay(1500);

//   Serial.println("\n=== TLV0 ADDRESS SCANNER ===");

//   pinMode(SDA, OUTPUT);
//   pinMode(TLV0_PWR, OUTPUT);
//   pinMode(TLV1_PWR, OUTPUT);

//   // Power everything down first
//   digitalWrite(TLV0_PWR, LOW);
//   digitalWrite(TLV1_PWR, LOW);
//   digitalWrite(SDA, LOW);
//   delay(500);

//   // Keep TLV1 OFF
//   digitalWrite(TLV1_PWR, LOW);

//   // Latch TLV0 as A0 (0x5E)
//   digitalWrite(SDA, LOW);
//   delay(50);

//   // Power only TLV0
//   digitalWrite(TLV0_PWR, HIGH);
//   delay(250);

//   Wire.begin();
//   Wire.setClock(100000);

//   Serial.println("Scanning...");

//   for (byte addr = 1; addr < 127; addr++) {
//     Wire.beginTransmission(addr);
//     byte error = Wire.endTransmission();

//     if (error == 0) {
//       Serial.print("Found device at 0x");
//       if (addr < 16) Serial.print("0");
//       Serial.println(addr, HEX);
//     }
//   }

//   Serial.println("Scan complete.");
// }

// void loop() {}

// // TLV1 ADDRESS SCANNER

// #include <Arduino.h>
// #include <Wire.h>

// #define TLV0_PWR 12
// #define TLV1_PWR 10

// void setup()
// {
//     Serial.begin(250000);
//     delay(1500);

//     Serial.println("\n=== TLV1 ADDRESS SCANNER ===");

//     pinMode(SDA, OUTPUT);
//     pinMode(TLV0_PWR, OUTPUT);
//     pinMode(TLV1_PWR, OUTPUT);

//     // Power everything down first
//     digitalWrite(TLV0_PWR, LOW);
//     digitalWrite(TLV1_PWR, LOW);
//     digitalWrite(SDA, LOW);

//     delay(500);

//     //
//     // TLV1 ONLY
//     //

//     // digitalWrite(TLV0_PWR, LOW);   // Keep TLV0 OFF                 //here

//     // digitalWrite(SDA, HIGH);       // Force A1 latch condition
//     // delay(50);

//     // digitalWrite(TLV1_PWR, HIGH);  // Power TLV1 only
//     // delay(250);                                                     //here

//     // Release SDA and let the 3.3V pullup set the level

//     pinMode(SDA, INPUT);
//     delay(50);

//     // Power TLV1 while SDA is floating HIGH via pullup

//     digitalWrite(TLV1_PWR, HIGH);
//     delay(250);

//     //
//     // Start I2C
//     //

//     Wire.begin();
//     Wire.setClock(100000);

//     Serial.println("Scanning...");

//     bool foundDevice = false;

//     for (byte addr = 1; addr < 127; addr++)
//     {
//         Wire.beginTransmission(addr);
//         byte error = Wire.endTransmission();

//         if (error == 0)
//         {
//             foundDevice = true;

//             Serial.print("Found device at 0x");
//             if (addr < 16)
//                 Serial.print("0");

//             Serial.println(addr, HEX);
//         }
//     }

//     if (!foundDevice)
//     {
//         Serial.println("No I2C devices found.");
//     }

//     Serial.println("Scan complete.");
// }

// void loop()
// {
// }


// // TLV1 FULL ADDRESS SCANNER

// #include <Arduino.h>
// #include <Wire.h>

// #define TLV0_PWR 12
// #define TLV1_PWR 10

// void setup() {
//   Serial.begin(250000);
//   delay(1500);

//   Serial.println("\n=== TLV1 FULL ADDRESS SCANNER ===");

//   pinMode(SDA, OUTPUT);
//   pinMode(TLV0_PWR, OUTPUT);
//   pinMode(TLV1_PWR, OUTPUT);

//   digitalWrite(TLV0_PWR, LOW);
//   digitalWrite(TLV1_PWR, LOW);
//   digitalWrite(SDA, LOW);
//   delay(500);

//   // Power only U3/TLV1
//   digitalWrite(TLV0_PWR, LOW);

//   //
//   // ORIGINAL TEST (SDA HIGH DURING POWER-UP)
//   //
//   // pinMode(SDA, INPUT);   // release SDA, let 3.3V pullup hold it high
//   // delay(100);

//   //
//   // NEW TEST (SDA LOW DURING POWER-UP)
//   //
//   digitalWrite(SDA, LOW);
//   delay(100);

//   //
//   // ORIGINAL
//   //
//   // digitalWrite(TLV1_PWR, HIGH);

//   //
//   // SAME POWER-UP STEP
//   //
//   digitalWrite(TLV1_PWR, HIGH);
//   delay(250);

//   Wire.begin();
//   Wire.setClock(100000);

//   Serial.println("Scanning all I2C addresses...");

//   bool found = false;

//   for (byte addr = 1; addr < 127; addr++) {
//     Wire.beginTransmission(addr);
//     byte error = Wire.endTransmission();

//     if (error == 0) {
//       found = true;

//       Serial.print("Found device: DEC ");
//       Serial.print(addr);

//       Serial.print("  HEX 0x");
//       if (addr < 16) Serial.print("0");
//       Serial.println(addr, HEX);
//     }
//   }

//   if (!found) {
//     Serial.println("No devices found.");
//   }

//   Serial.println("Scan complete.");
// }

// void loop() {}

