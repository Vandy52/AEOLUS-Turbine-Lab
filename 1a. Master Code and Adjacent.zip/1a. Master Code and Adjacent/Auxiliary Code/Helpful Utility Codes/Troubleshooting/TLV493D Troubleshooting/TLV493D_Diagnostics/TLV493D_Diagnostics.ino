// TLV493D Diagnostics
//
// Purpose:
// Diagnose TLV493D wiring, I2C communication, address latching,
// and basic sensor response for BOTH TLV493D sensors.
//
// TLV0:
//   Wind vane sensor
//   SDA held LOW during power-up
//   Expected address: A4 / 0x1F
//
// TLV1:
//   Collective pitch sensor
//   SDA released HIGH during power-up
//   Expected address: A0 / 0x5E

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

// ============================================================
// PIN DEFINITIONS
// ============================================================

#define TLV0_PWR 12
#define TLV1_PWR 10

#define SDA_PIN SDA
#define SCL_PIN SCL

// ============================================================
// EXPECTED TLV493D I2C ADDRESSES
// ============================================================

const uint8_t TLV0_EXPECTED_ADDR = 0x1F;   // TLV0 -> A4
const uint8_t TLV1_EXPECTED_ADDR = 0x5E;   // TLV1 -> A0

// ============================================================
// SENSOR OBJECTS
// ============================================================

TLx493D_A1B6 mag_tlv0(Wire, TLx493D_IIC_ADDR_A4_e);
TLx493D_A1B6 mag_tlv1(Wire, TLx493D_IIC_ADDR_A0_e);

// ============================================================
// DIAGNOSTIC RESULT FLAGS
// ============================================================

bool sdaIdlePass = false;
bool sclIdlePass = false;

bool tlv0AckPass = false;
bool tlv1AckPass = false;

bool tlv0BeginPass = false;
bool tlv1BeginPass = false;

bool tlv0ReadPass = false;
bool tlv1ReadPass = false;

// ============================================================
// BASIC SERIAL HELPERS
// ============================================================

void printDivider()
{
    Serial.println(F("--------------------------------------------------"));
}

void printPass(const __FlashStringHelper *msg)
{
    Serial.print(F("[PASS] "));
    Serial.println(msg);
}

void printFail(const __FlashStringHelper *msg)
{
    Serial.print(F("[FAIL] "));
    Serial.println(msg);
}

void printWarn(const __FlashStringHelper *msg)
{
    Serial.print(F("[WARN] "));
    Serial.println(msg);
}

void waitForEnter()
{
    Serial.println(F("Press ENTER to continue..."));

    while (Serial.available() > 0)
    {
        Serial.read();
    }

    while (Serial.available() == 0)
    {
        delay(10);
    }

    while (Serial.available() > 0)
    {
        Serial.read();
    }
}

// ============================================================
// FAILURE EXPLANATION HELPERS
// ============================================================

void explainBusLineFailure()
{
    Serial.println(F("Possible causes:"));
    Serial.println(F(" - SDA or SCL shorted to GND"));
    Serial.println(F(" - Missing pull-up resistor"));
    Serial.println(F(" - TLV493D solder bridge"));
    Serial.println(F(" - Incorrect sensor orientation"));
    Serial.println(F(" - Damaged TLV493D or Arduino pin"));
}

void explainNoAckFailure(uint8_t addr)
{
    Serial.print(F("No ACK received at I2C address 0x"));
    Serial.println(addr, HEX);

    Serial.println(F("Possible causes:"));
    Serial.println(F(" - Sensor is not powered"));
    Serial.println(F(" - Sensor GND pin is not connected"));
    Serial.println(F(" - SDA/SCL wiring is swapped or open"));
    Serial.println(F(" - Address latch sequence failed"));
    Serial.println(F(" - SDA state during power-up was incorrect"));
    Serial.println(F(" - Sensor is damaged"));
}

void explainBeginFailure()
{
    Serial.println(F("Possible causes:"));
    Serial.println(F(" - Sensor ACKs but library initialization failed"));
    Serial.println(F(" - Wrong TLx493D address enum"));
    Serial.println(F(" - I2C clock too fast"));
    Serial.println(F(" - Sensor configuration did not complete"));
}

void explainReadFailure()
{
    Serial.println(F("Possible causes:"));
    Serial.println(F(" - Sensor initialized but data read failed"));
    Serial.println(F(" - I2C bus instability"));
    Serial.println(F(" - Weak pull-ups"));
    Serial.println(F(" - Loose SDA/SCL connection"));
    Serial.println(F(" - Sensor brownout"));
}

// ============================================================
// LOW-LEVEL I2C ACK TEST
// ============================================================

bool i2cAddressResponds(uint8_t address)
{
    Wire.beginTransmission(address);
    uint8_t error = Wire.endTransmission();

    return (error == 0);
}

// ============================================================
// I2C BUS SCANNER
// ============================================================

void scanI2CBus()
{
    Serial.println(F("\nI2C BUS SCAN"));
    printDivider();

    int deviceCount = 0;

    for (uint8_t addr = 1; addr < 127; addr++)
    {
        Wire.beginTransmission(addr);
        uint8_t error = Wire.endTransmission();

        if (error == 0)
        {
            Serial.print(F("Device found at 0x"));
            if (addr < 16) Serial.print(F("0"));
            Serial.println(addr, HEX);

            deviceCount++;
        }
    }

    if (deviceCount == 0)
    {
        printFail(F("No I2C devices found."));
        Serial.println(F("Possible causes:"));
        Serial.println(F(" - SDA/SCL not connected"));
        Serial.println(F(" - Sensors unpowered"));
        Serial.println(F(" - Pull-ups missing"));
        Serial.println(F(" - Wrong board pins selected"));
    }
    else
    {
        Serial.print(F("Total I2C devices found: "));
        Serial.println(deviceCount);
    }

    printDivider();
}

// ============================================================
// SDA / SCL IDLE CHECK
// ============================================================

void checkI2CIdleLines()
{
    Serial.println(F("\nI2C IDLE LINE CHECK"));
    printDivider();

    pinMode(SDA_PIN, INPUT_PULLUP);
    pinMode(SCL_PIN, INPUT_PULLUP);

    delay(20);

    int sdaState = digitalRead(SDA_PIN);
    int sclState = digitalRead(SCL_PIN);

    Serial.print(F("SDA idle state: "));
    Serial.println(sdaState == HIGH ? F("HIGH") : F("LOW"));

    Serial.print(F("SCL idle state: "));
    Serial.println(sclState == HIGH ? F("HIGH") : F("LOW"));

    if (sdaState == HIGH)
    {
        sdaIdlePass = true;
        printPass(F("SDA is not stuck LOW."));
    }
    else
    {
        sdaIdlePass = false;
        printFail(F("SDA appears stuck LOW."));
        explainBusLineFailure();
    }

    if (sclState == HIGH)
    {
        sclIdlePass = true;
        printPass(F("SCL is not stuck LOW."));
    }
    else
    {
        sclIdlePass = false;
        printFail(F("SCL appears stuck LOW."));
        explainBusLineFailure();
    }

    printDivider();
}

// ============================================================
// SENSOR POWER CONTROL
// ============================================================

void powerOffBothSensors()
{
    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(500);
}

void configurePowerPins()
{
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
}

// ============================================================
// STARTUP HEADER
// ============================================================

void printStartupHeader()
{
    Serial.println();
    Serial.println(F("=================================================="));
    Serial.println(F("        TLV493D DUAL SENSOR DIAGNOSTIC            "));
    Serial.println(F("=================================================="));
    Serial.println(F("This utility checks:"));
    Serial.println(F(" - I2C bus idle state"));
    Serial.println(F(" - I2C address ACK response"));
    Serial.println(F(" - TLV493D address latch sequence"));
    Serial.println(F(" - Library initialization"));
    Serial.println(F(" - Magnetic field readout"));
    Serial.println(F(" - Live response from both sensors"));
    Serial.println(F("=================================================="));
    Serial.println();
}
// ============================================================
// TLV493D ADDRESS LATCHING, ACK CHECKS, BEGIN CHECKS, READ CHECKS
// ============================================================

// ============================================================
// TLV493D ADDRESS LATCHING SEQUENCE
// ============================================================

void runAddressLatchSequence()
{
    Serial.println(F("\nTLV493D ADDRESS LATCH SEQUENCE"));
    printDivider();

    Serial.println(F("Powering both TLV sensors OFF..."));
    powerOffBothSensors();

    pinMode(SDA_PIN, OUTPUT);

    Serial.println(F("TLV0: Holding SDA LOW, then powering TLV0."));
    digitalWrite(SDA_PIN, LOW);
    delay(50);

    digitalWrite(TLV0_PWR, HIGH);
    delay(250);

    Serial.println(F("Expected TLV0 address: A4 / 0x1F"));

    Serial.println(F("TLV1: Releasing SDA HIGH, then powering TLV1."));
    pinMode(SDA_PIN, INPUT_PULLUP);
    delay(50);

    digitalWrite(TLV1_PWR, HIGH);
    delay(250);

    Serial.println(F("Expected TLV1 address: A0 / 0x5E"));

    printPass(F("Address latch sequence completed."));
    printDivider();
}

// ============================================================
// ACK CHECKS
// ============================================================

void checkExpectedAddresses()
{
    Serial.println(F("\nEXPECTED ADDRESS ACK CHECK"));
    printDivider();

    tlv0AckPass = i2cAddressResponds(TLV0_EXPECTED_ADDR);

    if (tlv0AckPass)
    {
        Serial.print(F("[PASS] TLV0 ACK received at 0x"));
        Serial.println(TLV0_EXPECTED_ADDR, HEX);
    }
    else
    {
        Serial.print(F("[FAIL] TLV0 did NOT ACK at 0x"));
        Serial.println(TLV0_EXPECTED_ADDR, HEX);
        explainNoAckFailure(TLV0_EXPECTED_ADDR);
    }

    Serial.println();

    tlv1AckPass = i2cAddressResponds(TLV1_EXPECTED_ADDR);

    if (tlv1AckPass)
    {
        Serial.print(F("[PASS] TLV1 ACK received at 0x"));
        Serial.println(TLV1_EXPECTED_ADDR, HEX);
    }
    else
    {
        Serial.print(F("[FAIL] TLV1 did NOT ACK at 0x"));
        Serial.println(TLV1_EXPECTED_ADDR, HEX);
        explainNoAckFailure(TLV1_EXPECTED_ADDR);
    }

    printDivider();
}

// ============================================================
// COMMON TLV493D ADDRESSES CHECK
// ============================================================

void scanCommonTLVAddresses()
{
    Serial.println(F("\nCOMMON TLV493D ADDRESS CHECK"));
    printDivider();

    const uint8_t commonAddrs[] = {
        0x1F,
        0x5E,
        0x35,
        0x3E
    };

    const char *labels[] = {
        "A4 expected TLV0",
        "A0 expected TLV1",
        "Possible alternate",
        "Possible alternate"
    };

    for (byte i = 0; i < 4; i++)
    {
        bool ack = i2cAddressResponds(commonAddrs[i]);

        Serial.print(F("Address 0x"));
        Serial.print(commonAddrs[i], HEX);
        Serial.print(F(" ("));
        Serial.print(labels[i]);
        Serial.print(F("): "));

        if (ack)
        {
            Serial.println(F("ACK"));
        }
        else
        {
            Serial.println(F("No response"));
        }
    }

    Serial.println();
    Serial.println(F("If a sensor appears at the wrong address, likely causes are:"));
    Serial.println(F(" - SDA was not at the intended logic level during power-up"));
    Serial.println(F(" - TLV power sequencing was not clean"));
    Serial.println(F(" - SDA/ADDR pin is floating"));
    Serial.println(F(" - Pull-up is too weak or missing"));

    printDivider();
}

// ============================================================
// LIBRARY INITIALIZATION CHECK
// ============================================================

void checkLibraryBegin()
{
    Serial.println(F("\nTLx493D LIBRARY INITIALIZATION CHECK"));
    printDivider();

    Serial.println(F("Initializing TLV0 object at A4..."));

    tlv0BeginPass = mag_tlv0.begin();

    if (tlv0BeginPass)
    {
        printPass(F("TLV0 library begin() succeeded."));
    }
    else
    {
        printFail(F("TLV0 library begin() failed."));
        explainBeginFailure();
    }

    Serial.println();

    Serial.println(F("Initializing TLV1 object at A0..."));

    tlv1BeginPass = mag_tlv1.begin();

    if (tlv1BeginPass)
    {
        printPass(F("TLV1 library begin() succeeded."));
    }
    else
    {
        printFail(F("TLV1 library begin() failed."));
        explainBeginFailure();
    }

    printDivider();
}

// ============================================================
// SINGLE SENSOR FIELD READ
// ============================================================

bool readSensorField(
    TLx493D_A1B6 &sensor,
    const __FlashStringHelper *name,
    double &x,
    double &y,
    double &z
)
{
    x = 0.0;
    y = 0.0;
    z = 0.0;

    sensor.getMagneticField(&x, &y, &z);

    bool valuesLookValid =
        isfinite(x) &&
        isfinite(y) &&
        isfinite(z);

    Serial.print(name);
    Serial.print(F(" X="));
    Serial.print(x, 3);
    Serial.print(F(" mT | Y="));
    Serial.print(y, 3);
    Serial.print(F(" mT | Z="));
    Serial.print(z, 3);
    Serial.println(F(" mT"));

    return valuesLookValid;
}

// ============================================================
// MAGNETIC FIELD READ CHECK
// ============================================================

void checkMagneticFieldReads()
{
    Serial.println(F("\nMAGNETIC FIELD READ CHECK"));
    printDivider();

    double x0, y0, z0;
    double x1, y1, z1;

    if (tlv0BeginPass)
    {
        tlv0ReadPass = readSensorField(
            mag_tlv0,
            F("TLV0"),
            x0,
            y0,
            z0
        );

        if (tlv0ReadPass)
        {
            printPass(F("TLV0 returned finite magnetic field data."));
        }
        else
        {
            printFail(F("TLV0 magnetic field data invalid."));
            explainReadFailure();
        }
    }
    else
    {
        tlv0ReadPass = false;
        printWarn(F("Skipping TLV0 read because begin() failed."));
    }

    Serial.println();

    if (tlv1BeginPass)
    {
        tlv1ReadPass = readSensorField(
            mag_tlv1,
            F("TLV1"),
            x1,
            y1,
            z1
        );

        if (tlv1ReadPass)
        {
            printPass(F("TLV1 returned finite magnetic field data."));
        }
        else
        {
            printFail(F("TLV1 magnetic field data invalid."));
            explainReadFailure();
        }
    }
    else
    {
        tlv1ReadPass = false;
        printWarn(F("Skipping TLV1 read because begin() failed."));
    }

    printDivider();
}

// ============================================================
// REPEATED READ STABILITY CHECK
// ============================================================

void repeatedReadStabilityCheck()
{
    Serial.println(F("\nREPEATED READ STABILITY CHECK"));
    printDivider();

    if (!tlv0ReadPass && !tlv1ReadPass)
    {
        printWarn(F("Skipping repeated-read test because both sensors failed read checks."));
        printDivider();
        return;
    }

    bool tlv0Stable = true;
    bool tlv1Stable = true;

    for (int i = 0; i < 10; i++)
    {
        Serial.print(F("Sample "));
        Serial.print(i + 1);
        Serial.println(F(":"));

        if (tlv0ReadPass)
        {
            double x, y, z;
            bool ok = readSensorField(mag_tlv0, F("  TLV0"), x, y, z);
            if (!ok) tlv0Stable = false;
        }

        if (tlv1ReadPass)
        {
            double x, y, z;
            bool ok = readSensorField(mag_tlv1, F("  TLV1"), x, y, z);
            if (!ok) tlv1Stable = false;
        }

        delay(150);
    }

    Serial.println();

    if (tlv0ReadPass)
    {
        if (tlv0Stable)
        {
            printPass(F("TLV0 repeated reads remained valid."));
        }
        else
        {
            printFail(F("TLV0 repeated reads became invalid."));
            explainReadFailure();
        }
    }

    if (tlv1ReadPass)
    {
        if (tlv1Stable)
        {
            printPass(F("TLV1 repeated reads remained valid."));
        }
        else
        {
            printFail(F("TLV1 repeated reads became invalid."));
            explainReadFailure();
        }
    }

    printDivider();
}

// ============================================================
// SETUP PARTIAL FLOW
// ============================================================

void runCoreDiagnostics()
{
    checkI2CIdleLines();

    runAddressLatchSequence();

    Wire.begin();
    Wire.setClock(100000);
    delay(100);

    scanI2CBus();

    checkExpectedAddresses();

    scanCommonTLVAddresses();

    checkLibraryBegin();

    checkMagneticFieldReads();

    repeatedReadStabilityCheck();
}
// ============================================================
// FINAL SUMMARY, SETUP(), LOOP()
// ============================================================

// ============================================================
// FINAL REPORT
// ============================================================

void printSummary()
{
    Serial.println();
    Serial.println(F("========================================================"));
    Serial.println(F("             TLV493D DIAGNOSTIC SUMMARY"));
    Serial.println(F("========================================================"));

    Serial.println();

    Serial.print(F("TLV0 ACK............. "));
    Serial.println(tlv0AckPass ? F("PASS") : F("FAIL"));

    Serial.print(F("TLV1 ACK............. "));
    Serial.println(tlv1AckPass ? F("PASS") : F("FAIL"));

    Serial.println();

    Serial.print(F("TLV0 begin()......... "));
    Serial.println(tlv0BeginPass ? F("PASS") : F("FAIL"));

    Serial.print(F("TLV1 begin()......... "));
    Serial.println(tlv1BeginPass ? F("PASS") : F("FAIL"));

    Serial.println();

    Serial.print(F("TLV0 data............ "));
    Serial.println(tlv0ReadPass ? F("PASS") : F("FAIL"));

    Serial.print(F("TLV1 data............ "));
    Serial.println(tlv1ReadPass ? F("PASS") : F("FAIL"));

    Serial.println();
    printDivider();

    if (tlv0AckPass &&
        tlv1AckPass &&
        tlv0BeginPass &&
        tlv1BeginPass &&
        tlv0ReadPass &&
        tlv1ReadPass)
    {
        printPass(F("ALL DIAGNOSTICS PASSED"));
        Serial.println();
        Serial.println(F("Both TLV493D sensors appear healthy."));
        Serial.println(F("Hardware wiring is consistent."));
        Serial.println(F("Address latching succeeded."));
        Serial.println(F("I2C communication is functioning."));
        Serial.println(F("Library initialization succeeded."));
        Serial.println(F("Magnetic field readings are valid."));
    }
    else
    {
        printFail(F("ONE OR MORE TESTS FAILED"));
        Serial.println();

        Serial.println(F("Recommended troubleshooting order:"));
        Serial.println(F("1) Verify 3.3V power to each TLV."));
        Serial.println(F("2) Verify GND continuity."));
        Serial.println(F("3) Verify SDA wiring."));
        Serial.println(F("4) Verify SCL wiring."));
        Serial.println(F("5) Verify TLV0 power pin."));
        Serial.println(F("6) Verify TLV1 power pin."));
        Serial.println(F("7) Verify address latch sequence."));
        Serial.println(F("8) Verify pull-up resistors."));
        Serial.println(F("9) Verify both sensors are not damaged."));
    }

    printDivider();
}

// ============================================================
// LIVE MAGNETIC DATA MONITOR
// ============================================================

void liveMonitor()
{
    static unsigned long lastPrint = 0;

    if (millis() - lastPrint < 250)
        return;

    lastPrint = millis();

    if (!tlv0BeginPass || !tlv1BeginPass)
        return;

    double x0, y0, z0;
    double x1, y1, z1;

    mag_tlv0.getMagneticField(&x0, &y0, &z0);
    mag_tlv1.getMagneticField(&x1, &y1, &z1);

    Serial.println();

    Serial.println(F("---------------- LIVE DATA ----------------"));

    Serial.print(F("TLV0  X="));
    Serial.print(x0,2);
    Serial.print(F("  Y="));
    Serial.print(y0,2);
    Serial.print(F("  Z="));
    Serial.println(z0,2);

    Serial.print(F("TLV1  X="));
    Serial.print(x1,2);
    Serial.print(F("  Y="));
    Serial.print(y1,2);
    Serial.print(F("  Z="));
    Serial.println(z1,2);
}

// ============================================================
// SETUP
// ============================================================

void setup()
{
    Serial.begin(250000);

    while (!Serial);

    Serial.println();
    Serial.println(F("########################################################"));
    Serial.println(F("#          TLV493D COMPLETE DIAGNOSTIC UTILITY         #"));
    Serial.println(F("########################################################"));

    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    powerOffBothSensors();

    delay(250);

    runCoreDiagnostics();

    printSummary();

    Serial.println();
    Serial.println(F("Entering live monitor..."));
    Serial.println(F("Move a magnet around both sensors."));
    Serial.println(F("Values should continuously change."));
    Serial.println();
}

// ============================================================
// LOOP
// ============================================================

void loop()
{
    liveMonitor();
}