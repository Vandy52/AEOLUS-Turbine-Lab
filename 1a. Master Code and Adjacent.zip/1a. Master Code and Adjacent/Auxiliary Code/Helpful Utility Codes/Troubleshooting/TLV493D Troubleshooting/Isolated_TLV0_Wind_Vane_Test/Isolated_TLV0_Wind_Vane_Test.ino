// Isolated TLV0 Wind Vane Test

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

#define TLV0_PWR 12
#define TLV1_PWR 10

// TLV0 -> A4 address option
TLx493D_A1B6 mag_tlv0(Wire, TLx493D_IIC_ADDR_A4_e);

void setup()
{
  Serial.begin(250000);
  delay(1500);

  Serial.println();
  Serial.println(F("======================================"));
  Serial.println(F("       TLV0 SENSOR TEST"));
  Serial.println(F("======================================"));

  pinMode(TLV0_PWR, OUTPUT);
  pinMode(TLV1_PWR, OUTPUT);

  // Start with both TLV sensors powered off.
  digitalWrite(TLV0_PWR, LOW);
  digitalWrite(TLV1_PWR, LOW);
  delay(500);

  // TLV0 must see SDA LOW during power-up
  // so it latches the A4 address option.
  pinMode(SDA, OUTPUT);
  digitalWrite(SDA, LOW);
  delay(50);

  Serial.println(F("Powering TLV0 with SDA LOW..."));

  digitalWrite(TLV0_PWR, HIGH);
  delay(250);

  // Release SDA after the address has been latched.
  pinMode(SDA, INPUT_PULLUP);
  pinMode(SCL, INPUT_PULLUP);
  delay(100);

  Wire.begin();
  Wire.setClock(100000);
  Wire.setWireTimeout(25000, true);

  delay(100);

  Serial.println(F("Initializing TLV0..."));

  if (!mag_tlv0.begin())
  {
    Serial.println(F("FAILED: TLV0 did not ACK"));
    while (true)
    {
      delay(1000);
    }
  }

  Serial.println(F("SUCCESS: TLV0 detected"));
  Serial.println();
}

void loop()
{
  double x, y, z;

  mag_tlv0.getMagneticField(&x, &y, &z);

  float angle_deg =
      atan2((float)x, (float)y) * 180.0f / PI;

  if (angle_deg < 0.0f)
  {
    angle_deg += 360.0f;
  }

  Serial.print(F("TLV0 Angle: "));
  Serial.print(angle_deg, 1);
  Serial.print(F(" deg | X="));
  Serial.print(x, 2);
  Serial.print(F(" Y="));
  Serial.print(y, 2);
  Serial.print(F(" Z="));
  Serial.println(z, 2);

  delay(1000);
}