// Isolated TLV1 Collective Pitch Test

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

#define TLV0_PWR 12
#define TLV1_PWR 10

TLx493D_A1B6 mag_tlv1(Wire, TLx493D_IIC_ADDR_A0_e); // TLV1 -> A0 -> 0x5E

void setup() {
  Serial.begin(250000);
  delay(1500);

  pinMode(SDA, OUTPUT);
  pinMode(TLV0_PWR, OUTPUT);
  pinMode(TLV1_PWR, OUTPUT);

  digitalWrite(TLV0_PWR, LOW);
  digitalWrite(TLV1_PWR, LOW);
  delay(500);

  // TLV0 -> A4
  digitalWrite(SDA, LOW);
  delay(50);
  digitalWrite(TLV0_PWR, HIGH);
  delay(250);

  // TLV1 -> A0
  pinMode(SDA, INPUT);   // release SDA high
  delay(50);
  digitalWrite(TLV1_PWR, HIGH);
  delay(250);

  Wire.begin();
  Wire.setClock(100000);

  if (!mag_tlv1.begin()) {
    Serial.println(F("FAILED: TLV1 did not ACK"));
    while (1);
  }

  Serial.println(F("SUCCESS: TLV1 detected"));
}

void loop() {
  double x, y, z;
  mag_tlv1.getMagneticField(&x, &y, &z);

  float angle_deg = atan2((float)x, (float)y) * 180.0f / PI;
  if (angle_deg < 0) angle_deg += 360.0f;

  Serial.print(F("Collective Pitch: "));
  Serial.print(angle_deg, 1);
  Serial.print(F(" deg | X="));
  Serial.print(x);
  Serial.print(F(" Y="));
  Serial.print(y);
  Serial.print(F(" Z="));
  Serial.println(z);

  delay(1000);
}