// WT Load Bank Power Validation Test
//
// Purpose:
// Validate load-bank switches, MOSFET outputs, bulbs/load banks,
// INA219 measurement, and live turbine wattage.
//
// Operator workflow:
// 1. Upload this sketch.
// 2. Open Serial Monitor at 250000 baud.
// 3. Connect turbine/generator through INA219.
// 4. Turn on wind source.
// 5. Flip load-bank switches ON/OFF.
// 6. Bulbs should respond immediately.
// 7. Serial Monitor displays live power.

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_INA219.h>

// ============================================================
// PIN DEFINITIONS
// ============================================================

// 74HC165 switch input register
#define HC165_LOAD_PIN   15    // D15 / A1 -> SH/LD
#define HC165_CLOCK_PIN  16    // D16 / A2 -> CLK
#define HC165_DATA_PIN   17    // D17 / A3 <- QH

// 74HC595 MOSFET output register
#define HC595_DATA_PIN   11    // D11 -> SER
#define HC595_CLOCK_PIN  13    // D13 -> SRCLK
#define HC595_LATCH_PIN  14    // D14 / A0 -> RCLK

// ============================================================
// GLOBALS
// ============================================================

Adafruit_INA219 ina219;

byte lastSwitchState = 255;
byte outputState = 0;

// Same lookup style as Master Code.
// Index = number of active load banks.
const float LOAD_RESISTANCE_OHMS[7] =
{
    999999.0f,
    10.3f,
    5.15f,
    10.3f / 3.0f,
    2.575f,
    2.06f,
    10.3f / 6.0f
};  // Dynamic resistance lookup table

const float POWER_LPF = 0.15f;
float filteredPower_W = 0.0f;
bool powerInitialized = false;

// ============================================================
// FUNCTION DECLARATIONS
// ============================================================

byte readSwitches();
byte convertStateTo595(byte switchState);
void writeOutputs(byte state);
int countBanks(byte switchState);
void printActiveBanks(byte switchState);
void printSwitchChange(byte switchState);
void printLivePower(byte switchState);

// ============================================================
// SETUP
// ============================================================

void setup()
{
    Serial.begin(250000);
    while (!Serial);

    pinMode(HC165_LOAD_PIN, OUTPUT);
    pinMode(HC165_CLOCK_PIN, OUTPUT);
    pinMode(HC165_DATA_PIN, INPUT);

    digitalWrite(HC165_LOAD_PIN, HIGH);
    digitalWrite(HC165_CLOCK_PIN, LOW);

    pinMode(HC595_CLOCK_PIN, OUTPUT);
    pinMode(HC595_LATCH_PIN, OUTPUT);
    pinMode(HC595_DATA_PIN, OUTPUT);

    writeOutputs(0);

    Wire.begin();

    if (!ina219.begin())
    {
        Serial.println(F("ERROR: INA219 not detected. Check SDA/SCL, power, and GND."));
        while (true);
    }

    Serial.println();
    Serial.println(F("=================================================="));
    Serial.println(F("        AEOLUS POWER VALIDATION TEST              "));
    Serial.println(F("=================================================="));
    Serial.println(F("SETUP:"));
    Serial.println(F("1. Connect turbine/generator through INA219."));
    Serial.println(F("2. Connect load-bank bulbs/resistors."));
    Serial.println(F("3. Open Serial Monitor at 250000 baud."));
    Serial.println(F("4. Turn on wind source."));
    Serial.println(F("5. Flip load-bank switches ON/OFF."));
    Serial.println(F("6. Bulbs should illuminate immediately."));
    Serial.println(F("=================================================="));
    Serial.println();

    Serial.println(F("Live dashboard will update below."));
}

// ============================================================
// LOOP
// ============================================================

void loop()
{
    byte switchState = readSwitches();

    outputState = convertStateTo595(switchState);
    writeOutputs(outputState);

    if (switchState != lastSwitchState)
    {
        lastSwitchState = switchState;
        printSwitchChange(switchState);
    }

    printLivePower(switchState);

    delay(100);
}


// ============================================================
// READ SWITCHES
// ============================================================

byte readSwitches()
{
    byte raw = 0;

    digitalWrite(HC165_LOAD_PIN, LOW);
    delayMicroseconds(5);

    digitalWrite(HC165_LOAD_PIN, HIGH);
    delayMicroseconds(5);

    for (int i = 0; i < 8; i++)
    {
        raw <<= 1;

        if (digitalRead(HC165_DATA_PIN))
        {
            raw |= 1;
        }

        digitalWrite(HC165_CLOCK_PIN, HIGH);
        delayMicroseconds(5);

        digitalWrite(HC165_CLOCK_PIN, LOW);
        delayMicroseconds(5);
    }

    byte switches = 0;

    for (int bank = 0; bank < 6; bank++)
    {
        if (bitRead(raw, bank))
        {
            bitSet(switches, bank);
        }
    }

    return switches;
}

// ============================================================
// CONVERT SWITCH STATE TO 74HC595 OUTPUT STATE
// ============================================================

byte convertStateTo595(byte switchState)
{
    byte out = 0;

    for (int bank = 0; bank < 6; bank++)
    {
        if (bitRead(switchState, bank))
        {
            bitSet(out, bank + 1);   // QB = Bank 1, QC = Bank 2, etc.
        }
    }

    return out;
}

// ============================================================
// WRITE OUTPUTS
// ============================================================

void writeOutputs(byte state)
{
    digitalWrite(HC595_LATCH_PIN, LOW);
    shiftOut(HC595_DATA_PIN, HC595_CLOCK_PIN, MSBFIRST, state);
    digitalWrite(HC595_LATCH_PIN, HIGH);
}

// ============================================================
// COUNT BANKS
// ============================================================

int countBanks(byte switchState)
{
    int count = 0;

    for (int bank = 0; bank < 6; bank++)
    {
        if (bitRead(switchState, bank))
        {
            count++;
        }
    }

    return count;
}

// ============================================================
// PRINT ACTIVE BANKS
// ============================================================

void printActiveBanks(byte switchState)
{
    bool anyOn = false;

    for (int bank = 0; bank < 6; bank++)
    {
        if (bitRead(switchState, bank))
        {
            Serial.print(bank + 1);
            Serial.print(F(" "));
            anyOn = true;
        }
    }

    if (!anyOn)
    {
        Serial.print(F("NONE"));
    }
}

// ============================================================
// PRINT SWITCH CHANGE
// ============================================================

void printSwitchChange(byte switchState)
{
    int activeCount = countBanks(switchState);

    Serial.println();
    Serial.println(F("----------------------------------------"));
    Serial.println(F("SWITCH CHANGE DETECTED"));
    Serial.print(F("Active Banks: "));
    printActiveBanks(switchState);
    Serial.println();

    Serial.print(F("Equivalent Load: "));

    if (activeCount == 0)
    {
        Serial.println(F("OPEN CIRCUIT"));
    }
    else
    {
        Serial.print(LOAD_RESISTANCE_OHMS[activeCount], 4);
        Serial.println(F(" ohms"));
        Serial.print(F("Switch Byte: "));
        Serial.println(switchState, BIN);
        Serial.print(F("Output Byte: "));
        Serial.println(outputState, BIN);
    }


    Serial.println(F("----------------------------------------"));
}

// ============================================================
// PRINT LIVE POWER
// ============================================================

void printLivePower(byte switchState)
{
    int activeCount = countBanks(switchState);

    float voltage_V = ina219.getBusVoltage_V();
    float current_mA = ina219.getCurrent_mA();
    float current_A = current_mA / 1000.0f;

    float rawPower_W = voltage_V * current_A;

    if (!powerInitialized)
    {
        filteredPower_W = rawPower_W;
        powerInitialized = true;
    }

    filteredPower_W += POWER_LPF * (rawPower_W - filteredPower_W);

    Serial.println(F("----------------------------------------"));

    Serial.print(F("Active Banks : "));
    printActiveBanks(switchState);
    Serial.println();

    Serial.print(F("Voltage      : "));
    Serial.print(voltage_V, 3);
    Serial.println(F(" V"));

    Serial.print(F("Current      : "));
    Serial.print(current_mA, 2);
    Serial.println(F(" mA"));

    Serial.print(F("Power Raw    : "));
    Serial.print(rawPower_W, 5);
    Serial.println(F(" W"));

    Serial.print(F("Power Filter : "));
    Serial.print(filteredPower_W, 5);
    Serial.println(F(" W"));

    Serial.print(F("Eq. Load     : "));

    if (activeCount == 0)
    {
        Serial.println(F("OPEN"));
    }
    else
    {
        Serial.print(LOAD_RESISTANCE_OHMS[activeCount], 4);
        Serial.println(F(" ohms"));
    }

    Serial.print(F("Status       : "));

    if (activeCount == 0)
    {
        Serial.println(F("NO LOAD SELECTED"));
    }
    else if (fabs(current_mA) < 1.0f && fabs(rawPower_W) < 0.01f)
    {
        Serial.println(F("NO WIND / NO CURRENT"));
    }
    else
    {
        Serial.println(F("GENERATING"));
    }
}