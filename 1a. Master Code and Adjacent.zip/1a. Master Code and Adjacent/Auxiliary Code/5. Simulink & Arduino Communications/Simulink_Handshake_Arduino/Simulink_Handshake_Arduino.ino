// Simulink_Handshake_Arduino.ino

// The Arduino will send a signal incrementally from 1->5->1 continously to the Simulink block diagram
// Simulink will multiply the signal by 2 and send it back to the Arduino
// The Arduino will blink the appropriate amount of times before the sequence starts again after a 2 second pause
// (2 blinks then 4 blinks then 6 and so on)

#include <Arduino.h>

#define LED_PIN LED_BUILTIN

int counterValue = 1;
int counterStep  = 1;

float receivedValue = 0.0f;

void setup()
{
    Serial.begin(115200);

    pinMode(LED_PIN, OUTPUT);
}

void loop()
{
    float txValue = (float)counterValue;

    // ----------------------------------
    // Send value to Simulink
    // ----------------------------------
    while (Serial.available() > 0)
    {
        Serial.read();
    }

    Serial.write('S');
    Serial.write((uint8_t*)&txValue, sizeof(txValue));
    Serial.write('E');

    // ----------------------------------
    // Wait for Simulink response
    // ----------------------------------
    while (true)
    {
        if (Serial.available() >= 6)
        {
            if (Serial.read() == 'S')
            {
                Serial.readBytes((char*)&receivedValue,
                                 sizeof(receivedValue));

                Serial.read(); // consume 'E'
                break;
            }
        }
    }

    // ----------------------------------
    // Blink returned value times
    // ----------------------------------
    int blinkCount = (int)round(receivedValue);

    for (int i = 0; i < blinkCount; i++)
    {
        digitalWrite(LED_PIN, HIGH);
        delay(200);

        digitalWrite(LED_PIN, LOW);
        delay(200);
    }

    // Pause before moving to next number
    delay(2000);

    // ----------------------------------
    // Advance counter AFTER blinking
    // ----------------------------------
    counterValue += counterStep;

    if (counterValue >= 5)
    {
        counterValue = 5;
        counterStep = -1;
    }
    else if (counterValue <= 1)
    {
        counterValue = 1;
        counterStep = 1;
    }
}
