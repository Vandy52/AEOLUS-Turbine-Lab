/*
==================================================================================
                  Simulink Handshake with Arduino setup
==================================================================================
Follow these instructions exactly to establish the bidirectional serial link.
----------------------------------------------------------------------------------

1. Connect the Arduino Nano to your computer using a USB A to Mini USB cable 

2. Select the drop-down menu that says "Select Board" and then select "Select other board and port..."

3. Under "Boards" type Nano into the search bar and select "Arduino Nano"

4. Under "Ports" select the port that corresponds to the port that the Arduino Nano is plugged into and then click "OK"

5. Upload the AEOLUS code to the Arduino Nano using the arrow botton in the top right of the screen

6. Open the Simulink_Handshake_Simulink.slx file

7. These next settings will likely be set up, but if not complete the following

8. Navigate to the "Apps" tab and click the down arrow at the far right of the ribbon

9. Scroll down to the app category titled SETUP TO "RUN ON HARDWARE"

10. Select the app titled "Run on Hardware Board"

11. On the "Run on Hardware Board" configuration window in the "Hardware Board" drop-down menu select "Arduino Nano 3.0"

12. Click "Finish"

13. Now under the "HARDWARE" tab and under the "PREPARE" heading, click on "Hardware Settings"

14. In the lefthand selection tree select "Hardware Implementation" and expand the "Target hardware resources" menu 

15. Select "Host-board connect" and set "Host COM port" to the same port chosen in step 4
 
16. Double check that the all four of the Baud rate settings are set to 115200 

17. Now select "Solver" under the selection tree

18. Under "Solver Selection" set "Type" to "Fixed-Step" and "Solver" to "discrete (no continuous states)"

19. Set the "Stop time" to inf to run the Wind Turbine continuously until the stop button is manually selected

20. Expand the "Solver details" menu and change "Fixed-step size (fundamental sample time)" to 0.02

21. Select "Apply" in the bottom right hand corner of the "Configuration Parameters Window"

22. Click "OK" to the left off the "Apply" button

23. Under the "MODE" heading, select the drop-down arrow and select "Connected IO"

24. Under the "Connected IO" heading, select the drop-down arrow and select "Simulation Pacing"

25. Click "Enable pacing to slow down simulation" on the Simulation Pacing Options pop-up window then close the window

26. Click the "Run with IO" start button to start the experiment 

27. Once the bottom status bar of Simulink has compiled it will declare "Running" or "Ext: 100%"

========================
SIMULINK BLOCK SETTINGS
========================

-----------------------------
Host Serial Setup settings
-----------------------------
Port: COMx 
(Replace COMx with the proper Arduino COM port for here and where it is needed)
Baud Rate: 115200
Data Bits: 8
Parity: none
Stop Bits: 1
Byte Order: little-endian
Flow Control: none
Timeout: 1.0

-----------------------------
Host Serial Receive settings
-----------------------------
Port: COMx
Baud Rate: 115200
Header: 'S'
Data Size: 4 (4 for each signal coming in - Signal: 1 = Data Size: 4)
End Token: 'E'

-----------------------------
Byte Unpack settings
-----------------------------
Output Port Dimensions: {[1]}
Output Port Data Types: {'single'}
(Similar idea: for each added signal a ", [1]" or ", 'single'" is added)

-----------------------------
Byte Pack settings
-----------------------------
Output Port Data Type: uint8
Input Port Data Types: {'single'}
Same idea for "'single'" above

-----------------------------
Host Serial Transmit settings
-----------------------------
Port: COMx
Header: 'S'
Terminator:'E'

*/