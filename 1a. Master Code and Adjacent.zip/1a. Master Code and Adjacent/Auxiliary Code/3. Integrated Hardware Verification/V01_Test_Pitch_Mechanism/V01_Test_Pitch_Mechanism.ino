// Pitch Mechanism Test
// Wind Requirement: No wind (Run on a workbench).
// No generator connection!
// Purpose: Validates pitch min/max bounds, checks polarity, and performs
//          a full mechanical sweep (Origin -> Min -> Max -> Origin).

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

// -----------------------------
// PIN DEFINITIONS
// -----------------------------
#define TLV0_PWR 12  // Wind Vane Power Pin
#define TLV1_PWR 10  // Pitch Sensor Power Pin
#define M1_SLEEP 7   // Motor Driver Sleep Pin
#define M1_EN1   6   // Motor Driver Direction Pin 1
#define M1_EN0   5   // Motor Driver Direction Pin 0

TLx493D_A1B6 mag_collective(Wire, TLx493D_IIC_ADDR_A0_e);

// --- GLOBAL VARIABLES ---
float verified_deg_min = 0.0f;
float verified_deg_max = 0.0f;
float initial_y_reading = 0.0f;

// Motor drive pulse width (ms) for incremental movement
const int DRIVE_PULSE_MS = 50; 

// ============================================================
// HELPER FUNCTIONS
// ============================================================

float getFloatingInput() {
    while (Serial.available()) Serial.read(); // Clear buffer
    while (!Serial.available()) {
        delay(10);
    }
    float val = Serial.parseFloat();
    while (Serial.available()) Serial.read(); // Clear trailing bytes
    return val;
}

float readYValue() {
    double x = 0.0, y = 0.0, z = 0.0;
    mag_collective.getMagneticField(&x, &y, &z);
    return (float)y;
}

void stopMotor() {
    digitalWrite(M1_EN0, LOW);
    digitalWrite(M1_EN1, LOW);
    digitalWrite(M1_SLEEP, LOW);
}

void driveMotorForward() {
    digitalWrite(M1_SLEEP, HIGH);
    digitalWrite(M1_EN0, LOW);
    digitalWrite(M1_EN1, HIGH);
}

void driveMotorReverse() {
    digitalWrite(M1_SLEEP, HIGH);
    digitalWrite(M1_EN0, HIGH);
    digitalWrite(M1_EN1, LOW);
}

void validateDegreeBounds(float raw_min, float raw_max) {
    if (raw_min > raw_max) {
        Serial.println(F("\n[SAFETY WARNING] Entered coll_deg_min is greater than coll_deg_max!"));
        Serial.print(F("--> Automatically swapping: Min set to ")); 
        Serial.print(raw_max, 1);
        Serial.print(F("°, Max set to ")); 
        Serial.print(raw_min, 1); 
        Serial.println(F("°"));
        
        verified_deg_min = raw_max;
        verified_deg_max = raw_min;
    } else {
        verified_deg_min = raw_min;
        verified_deg_max = raw_max;
    }

    Serial.print(F(">> VERIFIED SAFETY BOUNDS: Min Pitch = "));
    Serial.print(verified_deg_min, 1);
    Serial.print(F("° | Max Pitch = "));
    Serial.print(verified_deg_max, 1);
    Serial.println(F("°"));
}

void driveToTargetY(float target_y, const char* label) {
    Serial.print(F("\n[SWEEP] Moving pitch to "));
    Serial.print(label);
    Serial.print(F(" (Target Y: "));
    Serial.print(target_y, 2);
    Serial.println(F(" mT)..."));

    unsigned long sweep_start = millis();
    const unsigned long SWEEP_TIMEOUT_MS = 6000; // 6-second max movement timeout

    while (millis() - sweep_start < SWEEP_TIMEOUT_MS) {
        float current_y = readYValue();
        float error = target_y - current_y;

        // Stop if within 0.3 mT tolerance band
        if (fabs(error) <= 0.3f) {
            stopMotor();
            Serial.print(F(">> Reached "));
            Serial.print(label);
            Serial.print(F(" | Final Y: "));
            Serial.print(current_y, 2);
            Serial.println(F(" mT"));
            return;
        }

        // Pulse motor in required direction
        if (error > 0) {
            driveMotorForward();
        } else {
            driveMotorReverse();
        }
        
        delay(DRIVE_PULSE_MS);
        stopMotor();
        delay(30); // Stabilization delay between pulses
    }

    stopMotor();
    Serial.print(F("WARNING: Movement timed out before reaching "));
    Serial.println(label);
}

// ============================================================
// SETUP
// ============================================================

void setup() {
    Serial.begin(250000);
    while (!Serial);

    pinMode(M1_EN0, OUTPUT);
    pinMode(M1_EN1, OUTPUT);
    pinMode(M1_SLEEP, OUTPUT);
    stopMotor();

    // Reset I2C Bus and configure sensor power lines
    pinMode(SDA, OUTPUT);
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(500);

    digitalWrite(SDA, LOW);
    delay(50);
    digitalWrite(TLV0_PWR, HIGH); // TLV0 Address: 0x44
    delay(250);

    pinMode(SDA, INPUT);          // Release SDA line back to I2C hardware control
    delay(50);
    digitalWrite(TLV1_PWR, HIGH); // TLV1 Address: 0x1F
    delay(250);

    Wire.begin();
    Wire.setClock(400000);           // Fast Mode I2C
    Wire.setWireTimeout(3000, true); // Hardware hang protection

    if (!mag_collective.begin()) {
        Serial.println(F("CRITICAL ERROR: TLV1 Collective Sensor failed to initialize!"));
        while (1) delay(100);
    }

    Serial.println(F("=================================================="));
    Serial.println(F("   PITCH MECHANISM SWEEP & BOUNDARY CALIBRATION   "));
    Serial.println(F("=================================================="));

    // Mandatory User Inputs
    Serial.println(F("\nEnter coll_deg_min (e.g., 2.0):"));
    float input_min = getFloatingInput();
    
    Serial.println(F("Enter coll_deg_max (e.g., 15.0):"));
    float input_max = getFloatingInput();

    // Bound Verification & Auto-Correction
    validateDegreeBounds(input_min, input_max);

    // Step 1: Capture Original Position
    initial_y_reading = readYValue();
    Serial.print(F("\n[ORIGIN CAPTURED] Starting Y-axis magnetic reading: "));
    Serial.print(initial_y_reading, 2);
    Serial.println(F(" mT"));

    // Step 2: Determine Direction Polarity with a short test pulse
    Serial.println(F("\nExecuting short direction pulse to establish sensor polarity..."));
    driveMotorForward();
    delay(200);
    stopMotor();
    delay(100);

    float post_pulse_y = readYValue();
    float pulse_delta = post_pulse_y - initial_y_reading;

    float min_target_y, max_target_y;

    if (pulse_delta < -0.3f) {
        Serial.println(F("--> Forward drive DECREASED Y-reading."));
        // Forward drive decreases Y -> Min angle maps to higher Y, Max angle maps to lower Y
        min_target_y = initial_y_reading + 3.0f;
        max_target_y = initial_y_reading - 3.0f;
    } else {
        Serial.println(F("--> Forward drive INCREASED Y-reading."));
        // Forward drive increases Y -> Min angle maps to lower Y, Max angle maps to higher Y
        min_target_y = initial_y_reading - 3.0f;
        max_target_y = initial_y_reading + 3.0f;
    }

    // --- EXECUTE FULL MECHANICAL SWEEP ROUTINE ---
    Serial.println(F("\n=================================================="));
    Serial.println(F("          STARTING FULL MECHANICAL SWEEP          "));
    Serial.println(F("=================================================="));

    // Stage 1: Sweep from Origin -> Extreme 1 (Min Pitch)
    driveToTargetY(min_target_y, "Extreme 1 (coll_deg_min)");
    delay(1000);

    // Stage 2: Sweep from Extreme 1 -> Extreme 2 (Max Pitch)
    driveToTargetY(max_target_y, "Extreme 2 (coll_deg_max)");
    delay(1000);

    // Stage 3: Sweep from Extreme 2 -> Return to Origin
    driveToTargetY(initial_y_reading, "Original Starting Position");

    Serial.println(F("\n=================================================="));
    Serial.println(F("          PITCH MECHANISM SWEEP COMPLETE          "));
    Serial.println(F("==================================================\n"));
}

void loop() {
    // Static hold state
}