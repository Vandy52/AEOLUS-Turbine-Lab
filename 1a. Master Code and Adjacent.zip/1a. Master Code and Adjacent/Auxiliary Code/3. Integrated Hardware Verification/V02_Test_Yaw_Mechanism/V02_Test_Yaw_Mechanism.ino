// Yaw Mechanism
// Wind Requirement: No wind (Run on a workbench).
// No generator connection!
// Purpose: Verifies yaw movement, establishes I2C safety, and tests deadband thresholds.

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

// ============================================================
// SYSTEM CONFIGURATION & PIN MAPPING
// ============================================================
#define TLV0_PWR 12  // D12 -> Power for Yaw Vane 3D Sensor
#define TLV1_PWR 10  // D10 -> Power for Collective Pitch 3D Sensor
#define M0_SLEEP 4   // D4  -> Yaw Motor Sleep
#define M0_EN1   3   // D3  -> Yaw Motor Enable 1
#define M0_EN0   2   // D2  -> Yaw Motor Enable 0

// TLV0 tracks wind vane (Address A4)
TLx493D_A1B6 mag_wvane(Wire, TLx493D_IIC_ADDR_A4_e);

// Global Variables
float yaw_deadband = 5.0f;  // Default deadband in degrees
float wvane_lpf    = 0.15f;  // LPF alpha constant (0.01 = heavy filtering, 1.0 = no filtering)

// LPF Filter State (Magnetic Vector Components)
float filtered_x = 0.0f;
float filtered_y = 0.0f;
bool filter_initialized = false;

// ============================================================
// HELPER FUNCTIONS
// ============================================================

float getFloatingInput() {
    while (Serial.available()) Serial.read(); // Clear stale bytes
    while (!Serial.available()) {
        delay(10);
    }
    float val = Serial.parseFloat();
    while (Serial.available()) Serial.read(); // Clear trailing bytes
    return val;
}

void stopYawMotor() {
    digitalWrite(M0_EN0, LOW);
    digitalWrite(M0_EN1, LOW);
    digitalWrite(M0_SLEEP, LOW);
}

void drive_yaw(bool reverse, int duration) {
    digitalWrite(M0_SLEEP, HIGH);
    if (reverse) {
        digitalWrite(M0_EN0, HIGH);
        digitalWrite(M0_EN1, LOW);
    } else {
        digitalWrite(M0_EN0, LOW);
        digitalWrite(M0_EN1, HIGH);
    }
    delay(duration);
    stopYawMotor();
}

// Read raw magnetic field and apply exponential LPF on X/Y components
float readFilteredVaneAngleDeg(float &raw_angle_out) {
    double xmag = 0.0, ymag = 0.0, zmag = 0.0;
    mag_wvane.getMagneticField(&xmag, &ymag, &zmag);
    
    float raw_x = (float)xmag;
    float raw_y = (float)ymag;

    // Calculate raw angle before filtering
    raw_angle_out = atan2(raw_x, raw_y) * 180.0f / PI;

    // Initialize filter state on first execution
    if (!filter_initialized) {
        filtered_x = raw_x;
        filtered_y = raw_y;
        filter_initialized = true;
    } else {
        // Exponential Moving Average (EMA) on Vector Components
        filtered_x = (wvane_lpf * raw_x) + ((1.0f - wvane_lpf) * filtered_x);
        filtered_y = (wvane_lpf * raw_y) + ((1.0f - wvane_lpf) * filtered_y);
    }

    // Return filtered angle
    float filtered_angle_rad = atan2(filtered_x, filtered_y);
    return filtered_angle_rad * 180.0f / PI;
}

// ============================================================
// SETUP
// ============================================================

void setup() {
    Serial.begin(250000);
    while (!Serial);

    // Motor driver pin configurations
    pinMode(M0_EN0, OUTPUT);
    pinMode(M0_EN1, OUTPUT);
    pinMode(M0_SLEEP, OUTPUT);
    stopYawMotor();

    // Configure power control and SDA lines for address latching
    pinMode(SDA, OUTPUT);
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(500);

    // Sequential address-latching sequence
    digitalWrite(SDA, LOW);
    delay(50);
    digitalWrite(TLV0_PWR, HIGH); // TLV0 boots with SDA LOW -> Latches Address A4
    delay(250);

    pinMode(SDA, INPUT);          // Release SDA line for hardware I2C control
    delay(50);
    digitalWrite(TLV1_PWR, HIGH); // TLV1 boots with SDA pulled HIGH -> Latches Address A0
    delay(250);

    Wire.begin();
    Wire.setClock(400000);           // Standard 400 kHz Fast I2C
    Wire.setWireTimeout(3000, true); // Hardware hang recovery protection

    if (!mag_wvane.begin()) {
        Serial.println(F("CRITICAL ERROR: TLV0 Wind Vane Sensor failed to initialize!"));
        while (true) delay(100);
    }

    Serial.println(F("=================================================="));
    Serial.println(F("    TEST 2: YAW MECHANISM, DEADBAND & LPF CHECK   "));
    Serial.println(F("=================================================="));

    // Interactive Prompt 1: Yaw Deadband
    Serial.println(F("\nEnter desired YAW DEADBAND in degrees (e.g., 5.0):"));
    yaw_deadband = getFloatingInput();
    if (yaw_deadband <= 0.0f) yaw_deadband = 5.0f;

    // Interactive Prompt 2: LPF Alpha Coefficient
    Serial.println(F("Enter wvane_lpf alpha coefficient (0.05 to 0.30, default 0.15):"));
    wvane_lpf = getFloatingInput();
    if (wvane_lpf <= 0.0f || wvane_lpf > 1.0f) wvane_lpf = 0.15f;

    Serial.print(F("--> Configured: YAW DEADBAND = ±"));
    Serial.print(yaw_deadband, 1);
    Serial.print(F("° | wvane_lpf Alpha = "));
    Serial.println(wvane_lpf, 2);

    Serial.println(F("\nExecuting short rotational burst CLOCKWISE..."));
    drive_yaw(false, 300);
    delay(1000);

    Serial.println(F("Executing short rotational burst COUNTER-CLOCKWISE..."));
    drive_yaw(true, 300);
    delay(1000);

    Serial.println(F("\n[SUCCESS] Motor actuation verified in both directions."));
    Serial.println(F("Streaming live RAW vs FILTERED angles with deadband evaluation...\n"));
}

// ============================================================
// LOOP (Live Tracking & Filtered Deadband Evaluation)
// ============================================================

void loop() {
    float raw_angle = 0.0f;
    float filtered_angle = readFilteredVaneAngleDeg(raw_angle);
    float abs_error = fabs(filtered_angle);

    Serial.print(F("RAW: "));
    Serial.print(raw_angle, 1);
    Serial.print(F("° | FILTERED: "));
    Serial.print(filtered_angle, 1);
    Serial.print(F("° | Status: "));

    if (abs_error <= yaw_deadband) {
        Serial.println(F("[INSIDE DEADBAND - Stable]"));
    } else {
        Serial.print(F("[OUTSIDE DEADBAND - Correction Needed ("));
        if (filtered_angle > 0) {
            Serial.println(F("CCW)]"));
        } else {
            Serial.println(F("CW)]"));
        }
    }

    delay(100); // 10 Hz telemetry rate
}