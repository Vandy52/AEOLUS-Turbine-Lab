// Test LoadBank Power

// Wind Requirement: WIND REQUIRED (Turn on the wind tunnel or fan stream to spin the blades).
// Generator Connection needed!
// Variable Load Bank needed!
// Purpose: Ensure switching on electrical MOSFET banks creates electromagnetic braking torque and reads valid power generation telemetry.

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_INA219.h>

// ============================================================
// 0) SYSTEM CONFIGURATION & PIN MAPPING (Cleaned)
// ============================================================
#define HC595_DATA_PIN   11    // D11 → SER (Data Out)
#define HC595_CLOCK_PIN  13    // D13 → SRCLK (Shift Clock)
#define HC595_LATCH_PIN  14    // D14 → RCLK (Latch Clock)

Adafruit_INA219 ina219;


void writeOutputs(byte state) {
  digitalWrite(HC595_LATCH_PIN, LOW);
  shiftOut(HC595_DATA_PIN, HC595_CLOCK_PIN, MSBFIRST, state);
  digitalWrite(HC595_LATCH_PIN, HIGH);
}

void setup() {
  Serial.begin(250000);
  while (!Serial);

  pinMode(HC595_CLOCK_PIN, OUTPUT); 
  pinMode(HC595_LATCH_PIN, OUTPUT); 
  pinMode(HC595_DATA_PIN, OUTPUT);
  
  Wire.begin();
  if (!ina219.begin()) {
    Serial.println(F("ERROR: INA219 power architecture missing on I2C bus!"));
    while(1);
  }
  
  Serial.println(F("=================================================="));
  Serial.println(F("     TEST 4: POWER GENERATION & BRAKING SWEEP     "));
  Serial.println(F("=================================================="));
  Serial.println(F("ENVIRONMENT REQUIREMENT: CONSTANT ACTIVE WIND STREAMS"));
  Serial.println(F("ENVIRONMENT REQUIREMENT: Connect to the generator"));

  // MANDATORY ENTRANCE GATE
  Serial.println(F("\nInstructions: Turn on your wind source now. Ensure turbine is spinning freely."));
  writeOutputs(0); 
}

void loop() {
  for(int bank = 0; bank < 6; bank++) {
    byte testState = 0;
    // FIXED: Starts at bit 0 (Channel 1) and ends at bit 5 (Channel 6)
    bitSet(testState, bank); 
    
    Serial.print(F("\nIsolating & Testing Load Bank Channel [")); Serial.print(bank + 1); Serial.println(F("]..."));
    Serial.println(F("Observation note: Watch if rotor velocity slows down due to electrical back-EMF braking."));
    
    writeOutputs(testState);
    delay(1500); 
    
    const int NUM_POWER_SAMPLES = 25;

    float voltageSum = 0.0f;
    float currentSum = 0.0f;
    float powerSum   = 0.0f;

    for (int i = 0; i < NUM_POWER_SAMPLES; i++)
    {
        float voltage = ina219.getBusVoltage_V();
        float current_A = ina219.getCurrent_mA() / 1000.0f;

        voltageSum += voltage;
        currentSum += current_A;
        powerSum   += voltage * current_A;

        delay(40);
    }

    float v  = voltageSum / NUM_POWER_SAMPLES;
    float mA = (currentSum / NUM_POWER_SAMPLES) * 1000.0f;
    float W  = powerSum / NUM_POWER_SAMPLES;
    
    Serial.print(F(" -> Measured Generation EMF:  ")); Serial.print(v, 2); Serial.println(F(" V"));
    Serial.print(F(" -> Measured System Draw:    ")); Serial.print(mA, 1); Serial.println(F(" mA"));
    Serial.print(F(" -> Net Turbine Wattage Output: ")); Serial.print(W, 4); Serial.println(F(" W"));
    
    // Safely turn off the channel before stepping into the transition delay
    writeOutputs(0);
    delay(2000);
  }
  
  Serial.println(F("\nFull sweep complete. Disengaging load banks for system dump protection (5s cooldown)..."));
  writeOutputs(0);
  delay(5000);

  // ============================================================
  // SUCCESS SIGNATURE: END OF COMPLETE SWEEP PATTERN
  // ============================================================
  Serial.println(F("\n============================================="));
  Serial.println(F("    [SUCCESS] LOAD SWEEP CYCLE PASSED    "));
  Serial.println(F("============================================="));
  Serial.println(F("All 6 braking channels cycled without system brownouts."));
  Serial.println(F("Power translation parameters recorded cleanly. Re-shuffling..."));
  Serial.println(F("=============================================\n"));
}