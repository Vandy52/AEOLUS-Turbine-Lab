// Test Pitch Tracking
// Wind Requirement: No wind (Run on a workbench).
// No generator connection!
// Purpose: Verifies pitch step-response and closed-loop position tracking without oscillation.

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

// ============================================================
// SYSTEM CONFIGURATION & PIN MAPPING
// ============================================================
#define TLV0_PWR 12  // D12 -> Power for Wind Vane 3D Sensor
#define TLV1_PWR 10  // D10 -> Power for Collective Pitch 3D Sensor
#define M1_SLEEP 7   // D7  -> Pitch Motor Sleep
#define M1_EN1   6   // D6  -> Pitch Motor Enable 1
#define M1_EN0   5   // D5  -> Pitch Motor Enable 0

// Sensor instance at Address A0 (0x1F)
TLx493D_A1B6 mag_collective(Wire, TLx493D_IIC_ADDR_A0_e);

// Global Calibration Variables
float coll_deg_min = 55.0f;
float coll_deg_max = 105.0f;
float coll_motor_drivetime_ms = 150.0f;
float BETA_LPF = 0.12f;

float filtered_beta_deg = 0.0f;
bool betaInitialized = false;

// ============================================================
// HELPER FUNCTIONS
// ============================================================

float getFloatingInput() {
    while (Serial.available()) Serial.read(); // Clear buffer
    while (!Serial.available()) {
        delay(10);
    }
    float val = Serial.parseFloat();
    while (Serial.available()) Serial.read(); // Clear trailing bytes
    return val;
}

void stopPitchMotor() {
    digitalWrite(M1_EN0, LOW);
    digitalWrite(M1_EN1, LOW);
    digitalWrite(M1_SLEEP, LOW);
}

void drive_pitch(bool reverse) {
    digitalWrite(M1_SLEEP, HIGH);
    if (reverse) {
        digitalWrite(M1_EN0, HIGH);
        digitalWrite(M1_EN1, LOW);
    } else {
        digitalWrite(M1_EN0, LOW);
        digitalWrite(M1_EN1, HIGH);
    }
    delay((int)coll_motor_drivetime_ms);
    stopPitchMotor();
}

float get_collective_deg() {
    double xmag = 0.0, ymag = 0.0, zmag = 0.0;
    mag_collective.getMagneticField(&xmag, &ymag, &zmag);

    // Continuous 2D vector angle in degrees (0° to 360°)
    float rad = atan2((float)ymag, (float)xmag);
    float raw_angle_deg = rad * (180.0f / 3.14159265f);
    if (raw_angle_deg < 0.0f) raw_angle_deg += 360.0f;

    // Smoothly initialize LPF on first sample
    if (!betaInitialized) {
        filtered_beta_deg = raw_angle_deg;
        betaInitialized = true;
    } else {
        filtered_beta_deg += BETA_LPF * (raw_angle_deg - filtered_beta_deg);
    }

    return filtered_beta_deg;
}

void track_target(float target_deg) {
    target_deg = constrain(target_deg, min(coll_deg_min, coll_deg_max), max(coll_deg_min, coll_deg_max));

    Serial.print(F("\n[STEP COMMAND] Moving Pitch Target to: "));
    Serial.print(target_deg, 1);
    Serial.println(F(" deg"));

    unsigned long start_time = millis();
    const unsigned long TIMEOUT_MS = 6000;
    const float PITCH_TOLERANCE_DEG = 0.5f; // Tolerance in degrees

    while (millis() - start_time < TIMEOUT_MS) {
        float current_deg = get_collective_deg();
        float error = target_deg - current_deg;

        Serial.print(F("Current: "));
        Serial.print(current_deg, 1);
        Serial.print(F(" deg | Target: "));
        Serial.print(target_deg, 1);
        Serial.print(F(" deg | Error: "));
        Serial.print(error, 1);
        Serial.println(F(" deg"));

        // Within ±0.5 deg deadband
        if (fabs(error) <= PITCH_TOLERANCE_DEG) {
            Serial.println(F(">> [HOLD] Target reached within tolerance."));
            stopPitchMotor();
            return;
        }

        // Drive motor in direction that reduces position error
        drive_pitch(error < 0.0f);
        delay(50); // Stabilization pause between pulses
    }

    stopPitchMotor();
    Serial.println(F("WARNING: Step tracking timed out before reaching exact target."));
}

// ============================================================
// SETUP
// ============================================================

void setup() {
    Serial.begin(250000);
    while (!Serial);

    pinMode(M1_EN0, OUTPUT);
    pinMode(M1_EN1, OUTPUT);
    pinMode(M1_SLEEP, OUTPUT);
    stopPitchMotor();

    pinMode(SDA, OUTPUT);
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(500);

    // Sequential I2C address-latching sequence
    digitalWrite(SDA, LOW);
    delay(50);
    digitalWrite(TLV0_PWR, HIGH); // TLV0 Address: A4
    delay(250);

    pinMode(SDA, INPUT);          // Release SDA line back to hardware control
    delay(50);
    digitalWrite(TLV1_PWR, HIGH); // TLV1 Address: A0
    delay(250);

    Wire.begin();
    Wire.setClock(400000);           // Standard 400 kHz Fast Mode
    Wire.setWireTimeout(3000, true); // Hardware hang protection

    if (!mag_collective.begin()) {
        Serial.println(F("CRITICAL ERROR: TLV1 Collective Sensor failed to initialize!"));
        while (1) delay(100);
    }

    Serial.println(F("=================================================="));
    Serial.println(F("    TEST 3: STEP-RESPONSE PITCH TRACKING TEST    "));
    Serial.println(F("=================================================="));

    // Interactive Seed Inputs
    Serial.println(F("\nEnter coll_deg_min calibration value (e.g., 55.0):"));
    coll_deg_min = getFloatingInput();

    Serial.println(F("Enter coll_deg_max calibration value (e.g., 105.0):"));
    coll_deg_max = getFloatingInput();

    Serial.println(F("Enter tuned BETA_LPF alpha value (0.05 - 0.30, default 0.12):"));
    BETA_LPF = getFloatingInput();
    if (BETA_LPF <= 0.0f || BETA_LPF > 1.0f) BETA_LPF = 0.12f;

    Serial.print(F("\n--> Seeded Bounds: coll_deg_min = "));
    Serial.print(coll_deg_min, 1);
    Serial.print(F(" deg | coll_deg_max = "));
    Serial.print(coll_deg_max, 1);
    Serial.print(F(" deg | BETA_LPF = "));
    Serial.println(BETA_LPF, 3);

    // Initial sensor warm-up read
    get_collective_deg();

    Serial.println(F("\nCommencing automated step-response verification sweep..."));
    delay(1000);

    // Calculate 25% and 75% pitch positions across the physical degree range
    float span = coll_deg_max - coll_deg_min;
    float target_25 = coll_deg_min + (0.25f * span);
    float target_75 = coll_deg_min + (0.75f * span);

    track_target(target_25); // Step 1: 25% Pitch Angle
    delay(2000);

    track_target(target_75); // Step 2: 75% Pitch Angle
    delay(2000);

    track_target(coll_deg_min); // Step 3: Return to Minimum Safe Angle

    Serial.println(F("\n============================================="));
    Serial.println(F("       [SUCCESS] V03 COMPLETION GATE        "));
    Serial.println(F("============================================="));
    Serial.println(F("Pitch tracking verified. Ready for Loadbank Power Test.\n"));
}

void loop() {
    // Static hold state
}