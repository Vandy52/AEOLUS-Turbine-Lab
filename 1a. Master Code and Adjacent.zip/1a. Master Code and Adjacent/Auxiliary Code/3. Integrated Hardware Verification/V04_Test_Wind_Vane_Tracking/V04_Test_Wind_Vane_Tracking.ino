// Yaw Following Wind Vane System

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

//=====================
// PIN MAPPING
//=====================
#define TLV0_PWR 12  // D12 -> Power for Wind Vane 3D Sensor
#define TLV1_PWR 10  // Secondary power mirror

// MOTOR DRIVER CONTROL (YAW SYSTEM)
#define M0_SLEEP 4   // D4 -> Motor 0 Sleep (Yaw)
#define M0_EN1   3   // D3 -> Motor 0 Enable 1
#define M0_EN0   2   // D2 -> Motor 0 Enable 0

// ============================================================
// CONTROL / SYSTEM SETTINGS
// ============================================================
float wvane_zeropos = 0.0f;              // Calibrated via interactive setup
float wvane_lpf = 0.15f;                 // Vector/Angle LPF Alpha factor (0.05 - 0.30)
float yaw_deadband_rad = 0.1919f;        // Interactively configured (Default: 11 deg)

const unsigned long YAW_COOLDOWN_MS = 2000;
float base_motor_drivetime_ms = 1500;

// ============================================================
// GLOBAL TRACKING VARIABLES
// ============================================================
const unsigned long VANE_SAMPLE_INTERVAL_MS = 100; // 10 Hz sampling
unsigned long lastYawAdjustMs = 0;
unsigned long lastVaneSampleMs = 0;
unsigned long yawMotorStartMs = 0;
bool yawMotorActive = false;

float winddir = 0.0f;
unsigned long lastLoopPrintMs = 0;

TLx493D_A1B6 mag_wvane(Wire, TLx493D_IIC_ADDR_A4_e); // Address A4 (0x1F)

// Helper: Clear Serial buffer & fetch float input
float getFloatingInput() {
    while (Serial.available()) Serial.read();
    while (!Serial.available()) delay(10);
    float val = Serial.parseFloat();
    while (Serial.available()) Serial.read();
    return val;
}

float get_wind_dir(TLx493D_A1B6 &MagSensor);
float angleError(float target, float current);
void drive_motor(int pin_en0, int pin_en1, int pin_sleep, bool reverse);

// ============================================================
// SETUP
// ============================================================
void setup() {
    Serial.begin(250000);
    while (!Serial);

    // Motor Driver Pins
    pinMode(M0_EN0, OUTPUT);
    pinMode(M0_EN1, OUTPUT);
    pinMode(M0_SLEEP, OUTPUT);

    digitalWrite(M0_EN0, LOW);
    digitalWrite(M0_EN1, LOW);
    digitalWrite(M0_SLEEP, LOW);

    // Sensor Address Latching Pins
    pinMode(SDA, OUTPUT);
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(500);

    // Latch Address A4 (0x1F) for TLV0
    digitalWrite(SDA, LOW);
    delay(50);
    digitalWrite(TLV0_PWR, HIGH);
    delay(250);

    // CRITICAL FIX: Release SDA line back to I2C controller hardware
    pinMode(SDA, INPUT);
    delay(50);
    digitalWrite(TLV1_PWR, HIGH);
    delay(250);

    Wire.begin();
    Wire.setClock(400000);           // 400 kHz Fast Mode
    Wire.setWireTimeout(3000, true); // Prevent hardware hangs

    if (!mag_wvane.begin()) {
        Serial.println(F("CRITICAL ERROR: Wind Vane Sensor (TLV0) failed to initialize!"));
        while (true) delay(100);
    }

    Serial.println(F("=================================================="));
    Serial.println(F("       YAW TRACKING SYSTEM SETUP         "));
    Serial.println(F("=================================================="));

    // 1. INTERACTIVE YAW DEADBAND DETERMINATION
    Serial.println(F("\n[STEP 1] Enter allowable Yaw Deadband in DEGREES (e.g., 10.0 or 15.0):"));
    float deadband_deg = getFloatingInput();
    if (deadband_deg <= 0.0f) deadband_deg = 11.0f; // Fallback default
    yaw_deadband_rad = deadband_deg * (PI / 180.0f);

    Serial.print(F("--> Deadband configured: "));
    Serial.print(deadband_deg, 1);
    Serial.print(F(" deg ("));
    Serial.print(yaw_deadband_rad, 4);
    Serial.println(F(" rad)"));

Serial.println(F("\nEnter calibrated wvane_zeropos from C02 (e.g., 0.0000):"));
    wvane_zeropos = getFloatingInput();
    Serial.print(F("-> wvane_zeropos = "));
    Serial.println(wvane_zeropos, 4);

    Serial.println(F("\nEnter tuned wvane_lpf alpha value (0.05 - 0.30, default 0.12):"));
    wvane_lpf = getFloatingInput();
    if (wvane_lpf <= 0.0f || wvane_lpf > 1.0f) wvane_lpf = 0.12f;
    Serial.print(F("-> wvane_lpf = "));
    Serial.println(wvane_lpf, 3);

    Serial.println(F("\n>>> SUCCESS! Configuration loaded."));
    Serial.println(F("Engaging active yaw tracking mode...\n"));
}

// ============================================================
// MAIN LOOP
// ============================================================
void loop() {
    unsigned long currentMillis = millis();

    // 1. Motor Pulse Auto-Cutoff
    if (yawMotorActive && (currentMillis - yawMotorStartMs >= (unsigned long)base_motor_drivetime_ms)) {
        digitalWrite(M0_EN0, LOW);
        digitalWrite(M0_EN1, LOW);
        digitalWrite(M0_SLEEP, LOW);
        yawMotorActive = false;
    }

    // 2. Wind Vane Sampling & LPF (10 Hz)
    if (currentMillis - lastVaneSampleMs >= VANE_SAMPLE_INTERVAL_MS) {
        lastVaneSampleMs = currentMillis;
        float raw_vane = get_wind_dir(mag_wvane);
        winddir += wvane_lpf * angleError(raw_vane, winddir);

        // Keep winddir strictly bounded to [-PI, PI]
        while (winddir > PI)  winddir -= 2.0f * PI;
        while (winddir < -PI) winddir += 2.0f * PI;
    }

    // 3. Automated Yaw Correction with User-Defined Deadband
    if (!yawMotorActive && (currentMillis - lastYawAdjustMs > YAW_COOLDOWN_MS)) {
        if (winddir < -yaw_deadband_rad) {
            drive_motor(M0_EN0, M0_EN1, M0_SLEEP, true);
            lastYawAdjustMs = currentMillis;
        } else if (winddir > yaw_deadband_rad) {
            drive_motor(M0_EN0, M0_EN1, M0_SLEEP, false);
            lastYawAdjustMs = currentMillis;
        }
    }

    // 4. Status Telemetry Log
    if (currentMillis - lastLoopPrintMs >= 250) {
        lastLoopPrintMs = currentMillis;
        Serial.print(F("Wind Angle Deviation: "));
        Serial.print(winddir, 4);
        Serial.print(F(" rad ("));
        Serial.print(winddir * (180.0f / PI), 1);
        Serial.print(F("°) | Deadband: ±"));
        Serial.print(yaw_deadband_rad * (180.0f / PI), 1);
        Serial.println(F("°"));

        if (yawMotorActive) {
            Serial.println(F(" [MOTOR ACTIVE - CORRECTING YAW]"));
        }
    }
}

// ============================================================
// HARDWARE INTERFACE FUNCTIONS
// ============================================================

float get_wind_dir(TLx493D_A1B6 &MagSensor) {
    double xmag = 0.0, ymag = 0.0, zmag = 0.0;
    MagSensor.getMagneticField(&xmag, &ymag, &zmag);

    float w_dir = atan2((float)xmag, (float)ymag) - wvane_zeropos;
    while (w_dir > PI)  w_dir -= 2.0f * PI;
    while (w_dir < -PI) w_dir += 2.0f * PI;
    return w_dir;
}

float angleError(float target, float current) {
    float error = target - current;
    while (error > PI)  error -= 2.0f * PI;
    while (error < -PI) error += 2.0f * PI;
    return error;
}

void drive_motor(int pin_en0, int pin_en1, int pin_sleep, bool reverse) {
    digitalWrite(pin_sleep, HIGH);
    if (reverse) {
        digitalWrite(pin_en0, LOW);
        digitalWrite(pin_en1, HIGH);
    } else {
        digitalWrite(pin_en0, HIGH);
        digitalWrite(pin_en1, LOW);
    }

    yawMotorStartMs = millis();
    yawMotorActive = true;
}