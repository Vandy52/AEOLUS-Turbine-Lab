// Isolated_Yaw_Actuator_Test.ino

/*
==================================================
ISOLATED YAW ACTUATOR TEST
==================================================

Purpose:
Verify yaw motor wiring, motor driver operation,
and rotation direction before integrating the
wind vane sensor and yaw control logic.

Expected Behavior:
- Motor rotates clockwise for 10 s
- Pauses for 2 s
- Motor rotates counter-clockwise for 10 s
- Pauses for 2 s
- Repeats continuously
==================================================
*/


#include <Arduino.h>

#define M0_SLEEP 4   // D4 → Yaw Motor Sleep
#define M0_EN1 3     // D3 → Yaw Motor Enable 1
#define M0_EN0 2     // D2 → Yaw Motor Enable 0

void drive_yaw(bool reverse, int duration) {
    digitalWrite(M0_SLEEP, HIGH);
    if (reverse) {
        digitalWrite(M0_EN0, HIGH);
        digitalWrite(M0_EN1, LOW);
    } else {
        digitalWrite(M0_EN0, LOW);
        digitalWrite(M0_EN1, HIGH);
    }
    delay(duration);
    
    // Hard brake / turn off
    digitalWrite(M0_SLEEP, LOW);
    digitalWrite(M0_EN0, LOW);
    digitalWrite(M0_EN1, LOW);
}

void setup() {
    Serial.begin(250000);
    while (!Serial);

    pinMode(M0_EN0, OUTPUT);
    pinMode(M0_EN1, OUTPUT);
    pinMode(M0_SLEEP, OUTPUT);

    digitalWrite(M0_SLEEP, LOW);
    digitalWrite(M0_EN0, LOW);
    digitalWrite(M0_EN1, LOW);
    
    Serial.println(F("--- STARTING YAW ACTUATOR CYCLE TEST ---"));
}

void loop() {
    Serial.println(F("Verify clockwise rotation."));
    Serial.println(F("Driving CLOCKWISE for 10000 ms..."));
    delay(1000);
    drive_yaw(false, 10000);                // drives for 10 seconds
    delay(2000); // Rest for 2 seconds

    Serial.println(F("Verify counter-clockwise rotation."));
    Serial.println(F("Driving COUNTER-CLOCKWISE for 10000 ms..."));
    delay(1000);
    drive_yaw(true, 10000);                 // drives for 10 seconds
    delay(2000); // Rest for 2 seconds
}
