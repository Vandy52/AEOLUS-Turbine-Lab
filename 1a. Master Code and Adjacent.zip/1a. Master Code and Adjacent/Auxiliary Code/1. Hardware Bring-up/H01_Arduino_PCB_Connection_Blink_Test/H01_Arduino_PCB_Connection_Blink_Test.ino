// Ardunio PCB Connection Blink Test
// The built-in LED on the Arduino Nano is connected to digital pin 13
const int ledPin = LED_BUILTIN; 

void setup() {
  // Initialize the digital pin as an output
  pinMode(ledPin, OUTPUT);

  // Initialize serial communication at 250000 bits per second
  Serial.begin(250000);

  // Print instructions to the Serial Monitor
  Serial.println("Waiting for you to press a key and hit Enter...");

  // Wait here until data is received in the serial buffer
  while (Serial.available() == 0) {
    // Do nothing, just wait
  }

  // Optional: Read and clear the character sent so it doesn't linger
  Serial.read(); 
  Serial.println("Key received! Blinking 5 times now...");

  // Loop exactly 5 times
  for (int i = 0; i < 5; i++) {
    digitalWrite(ledPin, HIGH);   // Turn the LED on
    delay(500);                  // Wait for half a second
    digitalWrite(ledPin, LOW);    // Turn the LED off
    delay(500);                  // Wait for half a second
  }
  
  Serial.println("Done!");
}

void loop() {
  // Left empty so it only runs once per reset/power-on
}