// Dual Sensor Test - TLV493D
#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

#define TLV0_PWR 12
#define TLV1_PWR 10

// TLV0 gets SDA LOW -> A4
TLx493D_A1B6 mag_tlv0(Wire, TLx493D_IIC_ADDR_A4_e);

// TLV1 gets SDA HIGH -> A0
TLx493D_A1B6 mag_tlv1(Wire, TLx493D_IIC_ADDR_A0_e);

void setup()
{
    Serial.begin(250000);
    delay(1500);

    Serial.println("\n=== DUAL TLV493D TEST ===");

    pinMode(SDA, OUTPUT);
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    //
    // Start with both sensors OFF
    //
    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(500);

    //
    // TLV0 -> A4
    //
    Serial.println("Powering TLV0 as A4");

    digitalWrite(SDA, LOW);
    delay(50);

    digitalWrite(TLV0_PWR, HIGH);
    delay(250);

    //
    // TLV1 -> A0
    //
    Serial.println("Powering TLV1 as A0");

    pinMode(SDA, INPUT);     // release SDA, pullup drives HIGH
    //pinMode(SDA, INPUT_PULLUP);
    delay(50);

    digitalWrite(TLV1_PWR, HIGH);
    delay(250);

    //
    // Start I2C
    
    Wire.begin();
    Wire.setClock(100000);

    //
    // Initialize TLV0
    //
    Serial.println("Initializing TLV0...");

    if (!mag_tlv0.begin())
    {
        Serial.println("FAILED: TLV0 did not ACK");
        while (1);
    }

    Serial.println("SUCCESS: TLV0 detected");

    //
    // Initialize TLV1
    //
    Serial.println("Initializing TLV1...");

    if (!mag_tlv1.begin())
    {
        Serial.println("FAILED: TLV1 did not ACK");
        while (1);
    }

    Serial.println("SUCCESS: TLV1 detected");

    Serial.println("\nBoth sensors initialized!");
}

void loop()
{
    double x0, y0, z0;
    double x1, y1, z1;

    mag_tlv0.getMagneticField(&x0, &y0, &z0);
    mag_tlv1.getMagneticField(&x1, &y1, &z1);

    Serial.print("TLV0: ");
    Serial.print("X=");
    Serial.print(x0);
    Serial.print(" Y=");
    Serial.print(y0);
    Serial.print(" Z=");
    Serial.println(z0);

    Serial.print("TLV1: ");
    Serial.print("X=");
    Serial.print(x1);
    Serial.print(" Y=");
    Serial.print(y1);
    Serial.print(" Z=");
    Serial.println(z1);

    Serial.println();

    delay(1000);
}