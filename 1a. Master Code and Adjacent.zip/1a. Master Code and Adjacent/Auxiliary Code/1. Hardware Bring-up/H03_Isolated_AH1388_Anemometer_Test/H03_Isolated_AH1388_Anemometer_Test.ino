// Isolated_AH1388_Anemometer_Test
//
// A magnet is detected when the reading switches between 1 and 0

#include <Arduino.h>

#define HS_N 8   // D8 -> North Channel
#define HS_S 9   // D9 -> South Channel

void setup() {
    Serial.begin(250000);
    while (!Serial);

    pinMode(HS_N, INPUT);
    pinMode(HS_S, INPUT);

    Serial.println(F("--- RAW PIN READOUT ---"));
}

void loop() {
    int north = digitalRead(HS_N);
    int south = digitalRead(HS_S);

    Serial.print(F("RAW Pin D8 (North): "));
    Serial.print(north);
    Serial.print(F("  |  RAW Pin D9 (South): "));
    Serial.println(south);


    delay(200);
}