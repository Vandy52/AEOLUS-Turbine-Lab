// Wind_Vane_LPF
// Purpose: Captures raw X/Y magnetic vectors and optimizes wvane_lpf alpha 

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp> 

using namespace ifx::tlx493d;

#define TLV0_PWR 12 
#define TLV1_PWR 10

TLx493D_A1B6 mag_wvane(Wire, TLx493D_IIC_ADDR_A4_e);

const int SAMPLE_COUNT = 200;

// Arrays store raw X and Y magnetic vectors scaled by 100 to save RAM
int16_t raw_x_scaled[SAMPLE_COUNT]; 
int16_t raw_y_scaled[SAMPLE_COUNT]; 

void setup() {
    Serial.begin(250000);
    while (!Serial);

    // Power and Address Hardware Latching
    pinMode(SDA, OUTPUT); 
    pinMode(TLV0_PWR, OUTPUT); 
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(TLV0_PWR, LOW); 
    digitalWrite(TLV1_PWR, LOW); 
    delay(500);

    digitalWrite(SDA, LOW); 
    delay(50);
    digitalWrite(TLV0_PWR, HIGH); // TLV0 Address: A4
    delay(250);

    pinMode(SDA, INPUT);          // CRITICAL: Release SDA back to hardware I2C control
    delay(50);
    digitalWrite(TLV1_PWR, HIGH); // TLV1 Address: A0
    delay(250);

    Wire.begin();
    Wire.setClock(400000); 
    Wire.setWireTimeout(3000, true); 

    if (!mag_wvane.begin()) { 
        Serial.println(F("CRITICAL ERROR: TLV0 Wind Vane Sensor failed to initialize!")); 
        while (1) delay(100); 
    }
    
    Serial.println(F("=================================================="));
    Serial.println(F("     20-SECOND VECTOR-BASED wvane_lpf TUNER       "));
    Serial.println(F("=================================================="));
    Serial.println(F("Instructions:"));
    Serial.println(F("1. Type 'start' into Serial Monitor and press Enter."));
    Serial.println(F("2. Perform the 3 test stages during the 20-second capture:"));
    Serial.println(F("   - 0.0s to  7.0s: Hold vane perfectly still (Noise test)"));
    Serial.println(F("   - 7.0s to 14.0s: Move vane slowly and smoothly (Lag test)"));
    Serial.println(F("   - 14.0s to 20.0s: Flick vane sharply a few times (Step test)"));
    Serial.println(F("--------------------------------------------------"));
}

void runTuningSession() {
    Serial.println(F("\n[!] GET READY... CAPTURE STARTS IN 1 SECOND."));
    delay(1000);
    Serial.println(F("[>] RECORDING STARTED! [0.0s to 7.0s: Hold vane completely still...]"));

    unsigned long start_time = millis();
    int current_step = 1;
    
    float last_valid_x = 0.0f;
    float last_valid_y = 0.0f;

    Wire.clearWireTimeoutFlag();

    // 1. Capture Raw X/Y Vectors
    for (int i = 0; i < SAMPLE_COUNT; i++) {
        unsigned long now = millis();
        float elapsed_secs = (now - start_time) / 1000.0f;

        if (elapsed_secs >= 7.0f && current_step == 1) {
            current_step = 2;
            Serial.println(F("\n[>] [7.0s to 14.0s: Start moving vane slowly back and forth...]"));
        }
        else if (elapsed_secs >= 14.0f && current_step == 2) {
            current_step = 3;
            Serial.println(F("\n[>] [14.0s to 20.0s: Flick vane sharply a few times!]"));
        }

        if (i % 20 == 0) {
            Serial.print(F("[Timer: "));
            Serial.print(elapsed_secs, 1);
            Serial.println(F("s / 20.0s]"));
        }

        double xmag = 0.0, ymag = 0.0, zmag = 0.0;
        mag_wvane.getMagneticField(&xmag, &ymag, &zmag);

        float rx = last_valid_x;
        float ry = last_valid_y;

        if (Wire.getWireTimeoutFlag()) {
            Wire.clearWireTimeoutFlag(); 
        } else {
            rx = (float)xmag;
            ry = (float)ymag;
            last_valid_x = rx;
            last_valid_y = ry;
        }

        // Scale by 100 to store floats safely in int16_t arrays
        raw_x_scaled[i] = (int16_t)(rx * 100.0f);
        raw_y_scaled[i] = (int16_t)(ry * 100.0f);

        delay(100); // 10 Hz sampling rate
    }

    Serial.println(F("\n[+] 20-Second Capture Complete. Processing vector optimization..."));

    // 2. Simulate Vector LPF Optimization
    float best_alpha = 0.15f;
    float lowest_penalty = 999999.0f;

    // Sweep alpha values directly from 0.02 to 0.50
    for (float test_alpha = 0.02f; test_alpha <= 0.50f; test_alpha += 0.01f) {
        float fx = (float)raw_x_scaled[0] / 100.0f;
        float fy = (float)raw_y_scaled[0] / 100.0f;
        
        float total_error = 0.0f;
        float total_jitter = 0.0f;

        for (int i = 1; i < SAMPLE_COUNT; i++) {
            float rx = (float)raw_x_scaled[i] / 100.0f;
            float ry = (float)raw_y_scaled[i] / 100.0f;

            // Store previous filtered values to assess output jitter
            float prev_fx = fx;
            float prev_fy = fy;

            // Apply Vector EMA LPF (Identical to Test 2 runtime code)
            fx = (test_alpha * rx) + ((1.0f - test_alpha) * fx);
            fy = (test_alpha * ry) + ((1.0f - test_alpha) * fy);

            // Compute angles for lag and jitter penalization
            float raw_angle  = atan2(rx, ry) * 180.0f / PI;
            float filt_angle = atan2(fx, fy) * 180.0f / PI;
            float prev_filt  = atan2(prev_fx, prev_fy) * 180.0f / PI;

            // Angular tracking lag error
            float diff = raw_angle - filt_angle;
            while (diff > 180.0f)  diff -= 360.0f;
            while (diff < -180.0f) diff += 360.0f;

            // Filter output step jitter
            float jitter = filt_angle - prev_filt;
            while (jitter > 180.0f)  jitter -= 360.0f;
            while (jitter < -180.0f) jitter += 360.0f;

            total_error += fabs(diff);
            total_jitter += fabs(jitter);
        }

        // Weighted penalty balance (6x multiplier heavily penalizes jitter)
        float penalty = total_error + (total_jitter * 6.0f); 

        if (penalty < lowest_penalty) {
            lowest_penalty = penalty;
            best_alpha = test_alpha;
        }
    }

    // 3. Output Results
    Serial.println(F("=================================================="));
    Serial.print(F(" OPTIMIZED VECTOR ALPHA: wvane_lpf = ")); 
    Serial.println(best_alpha, 2);
    Serial.println(F("=================================================="));
    Serial.println(F("Type 'start' to run another trial.\n"));
}

void loop() {
    if (Serial.available() > 0) {
        String cmd = Serial.readStringUntil('\n');
        cmd.trim();
        if (cmd.equalsIgnoreCase("start")) {
            runTuningSession();
        }
    }
}