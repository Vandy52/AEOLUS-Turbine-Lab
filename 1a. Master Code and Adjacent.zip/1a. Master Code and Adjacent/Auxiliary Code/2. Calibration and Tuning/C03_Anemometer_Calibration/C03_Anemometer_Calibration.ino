/*
=========================================================
ANEMOMETER CALIBRATION UTILITY
=========================================================

Purpose:
Determine ANEMOMETER_SCALE for use in the Master Code.

The Master Code converts measured anemometer speed
(rotations per second) into wind velocity using:

    wind_speed =
        anemometer_speed_rps *
        ANEMOMETER_SCALE

This utility experimentally determines the correct
value of ANEMOMETER_SCALE.

---------------------------------------------------------
Required Equipment
---------------------------------------------------------

1. Arduino running this sketch
2. Wind turbine with anemometer installed
3. Known wind-speed reference

Examples:

- Handheld anemometer
- Wind tunnel readout
- Calibrated fan data

---------------------------------------------------------
Procedure
---------------------------------------------------------

1. Upload sketch to Arduino.

2. Open Serial Monitor.

       Baud Rate = 250000

3. Enter the number of wind-speed tests
   you wish to perform.

4. Set the turbine in a known airflow.

5. Allow the anemometer speed to stabilize.

6. Press:

       Y

   to begin measurement.

7. The sketch will measure:

       anemometer_speed_rps

8. Enter the ACTUAL wind speed
   measured by the reference instrument.

9. The sketch computes:

       scale_factor =
           actual_wind_speed /
           measured_rps

10. Repeat for all requested test points.

11. After the final test, the sketch will:

       • Average all scale factors
       • Compute min/max values
       • Compute calibration spread
       • Display the recommended value

12. Copy the displayed result into
    the Master Code:

       const float ANEMOMETER_SCALE = X.XXXXf;

---------------------------------------------------------
Expected Result
---------------------------------------------------------

The final value should replace the temporary
wind-speed conversion factor currently used in:

    float get_wind_vel()
    {
        return anemometer_speed_rps *
               ANEMOMETER_SCALE;
    }

---------------------------------------------------------
Notes
---------------------------------------------------------

• More test points generally improve accuracy.

• Use a wide range of wind speeds if possible.

• Large spread values may indicate:
    - sensor noise
    - turbulent airflow
    - anemometer nonlinearity

• The calibrated ANEMOMETER_SCALE directly
  affects:

       windvel
       Pmax estimation
       load-bank decisions

  so accurate calibration is important.

=========================================================
*/
/*
=========================================================
ANEMOMETER CALIBRATION UTILITY (MPH INPUT VERSION)
=========================================================
UPDATED:
• Accepts actual wind speed inputs in MILES PER HOUR (MPH)
• Automatically converts to METERS PER SECOND (m/s)
• Generates ANEMOMETER_SCALE for m/s calculations in Master Code
• Uses HS_N (D8) with Pull-Up and disables Pin 9 (HS_S)
=========================================================
*/

#include <Arduino.h>
#include <PinChangeInterrupt.h>

#define ANEMOMETER_PIN 8      // HS_N (Port B)
#define UNUSED_HS_S_PIN 9     // HS_S (Port B) - Shared PCINT vector pin
#define SAMPLE_TIME_MS 10000  // 10 second measurement window

const int MAX_TESTS = 20;
const float MPH_TO_MS = 0.44704f; // Conversion constant: 1 mph = 0.44704 m/s

float scaleFactors[MAX_TESTS];

volatile unsigned long pulseCount = 0;
volatile unsigned long firstPulseTime = 0;
volatile unsigned long lastPulseTime = 0;

void anemometer_int()
{
    unsigned long now = micros();

    if (pulseCount == 0)
    {
        firstPulseTime = now;
    }

    lastPulseTime = now;
    pulseCount++;
}

void waitForY()
{
    while (true)
    {
        if (Serial.available())
        {
            char c = Serial.read();

            if (c == 'Y' || c == 'y')
            {
                while (Serial.available()) Serial.read();
                return;
            }
        }
    }
}

int readInt()
{
    while (Serial.available()) Serial.read();

    while (!Serial.available())
    {
        delay(10);
    }

    int val = Serial.parseInt();

    while (Serial.available()) Serial.read();

    return val;
}

float readFloatPositive()
{
    float val = 0.0f;

    while (val <= 0.0f)
    {
        while (Serial.available()) Serial.read();

        while (!Serial.available())
        {
            delay(10);
        }

        val = Serial.parseFloat();

        while (Serial.available()) Serial.read();

        if (val <= 0.0f)
        {
            Serial.println("Please enter a wind speed greater than 0.0:");
        }
    }

    return val;
}

void setup()
{
    Serial.begin(250000);

    // Set Pin 8 to Pull-Up for cleaner logic edge transitions
    pinMode(ANEMOMETER_PIN, INPUT);

    // Disable Pin 9 (HS_S) so it doesn't trigger Port B PCINT interrupts
    pinMode(UNUSED_HS_S_PIN, INPUT);
    disablePCINT(digitalPinToPCINT(UNUSED_HS_S_PIN));

    Serial.println();
    Serial.println("====================================");
    Serial.println("ANEMOMETER CALIBRATION UTILITY (MPH)");
    Serial.println("====================================");
    Serial.println();

    Serial.println("Enter number of wind-speed tests:");
}

void loop()
{
    static bool completed = false;

    if (completed)
    {
        return;
    }

    int numTests = readInt();

    if (numTests < 1) numTests = 1;
    if (numTests > MAX_TESTS) numTests = MAX_TESTS;

    float scaleSum = 0.0f;

    for (int test = 0; test < numTests; test++)
    {
        Serial.println();
        Serial.println("------------------------------------");
        Serial.print("TEST ");
        Serial.print(test + 1);
        Serial.print(" OF ");
        Serial.println(numTests);
        Serial.println("------------------------------------");

        Serial.println();
        Serial.println("Set desired airflow.");
        Serial.println("Wait for RPM to stabilize.");
        Serial.println("Press Y to begin 10-second measurement.");

        waitForY();

        noInterrupts();
        pulseCount = 0;
        firstPulseTime = 0;
        lastPulseTime = 0;
        interrupts();

        // Attach interrupt right before measurement delay
        attachPCINT(
            digitalPinToPCINT(ANEMOMETER_PIN),
            anemometer_int,
            FALLING
        );

        Serial.println();
        Serial.println("Measuring for 10 seconds...");
        delay(SAMPLE_TIME_MS);

        // Detach interrupt to freeze counting
        detachPCINT(digitalPinToPCINT(ANEMOMETER_PIN));

        float measuredRPS = 0.0f;

        noInterrupts();
        unsigned long pulses = pulseCount;
        unsigned long first = firstPulseTime;
        unsigned long last = lastPulseTime;
        interrupts();

        if (pulses >= 2)
        {
            float elapsedSeconds = (last - first) / 1000000.0f;
            measuredRPS = (float)(pulses - 1) / elapsedSeconds;
        }

        Serial.print("Pulse Count  = ");
        Serial.println(pulses);

        Serial.print("Measured RPS = ");
        Serial.println(measuredRPS, 4);

        if (measuredRPS <= 0.0f)
        {
            Serial.println("ERROR: No anemometer rotation detected.");
            test--;
            continue;
        }

        Serial.println();
        Serial.println("Enter ACTUAL wind speed in MPH, then press Enter:");

        float actualWindSpeedMPH = readFloatPositive();
        float actualWindSpeedMS  = actualWindSpeedMPH * MPH_TO_MS; // Convert to m/s

        // Compute scale factor based on m/s
        float scaleFactor = actualWindSpeedMS / measuredRPS;

        scaleFactors[test] = scaleFactor;
        scaleSum += scaleFactor;

        Serial.println();
        Serial.print("Actual Wind Speed = ");
        Serial.print(actualWindSpeedMPH, 2);
        Serial.print(" MPH (");
        Serial.print(actualWindSpeedMS, 3);
        Serial.println(" m/s)");

        Serial.print("Scale Factor (m/s) = ");
        Serial.println(scaleFactor, 6);
    }

    float averageScale = scaleSum / numTests;

    float minScale = scaleFactors[0];
    float maxScale = scaleFactors[0];

    for (int i = 1; i < numTests; i++)
    {
        if (scaleFactors[i] < minScale) minScale = scaleFactors[i];
        if (scaleFactors[i] > maxScale) maxScale = scaleFactors[i];
    }

    float spread = maxScale - minScale;

    Serial.println();
    Serial.println("====================================");
    Serial.println("CALIBRATION SUMMARY");
    Serial.println("====================================");

    for (int i = 0; i < numTests; i++)
    {
        Serial.print("Test ");
        Serial.print(i + 1);
        Serial.print(": ");
        Serial.println(scaleFactors[i], 6);
    }

    Serial.println();

    Serial.print("Average Scale Factor (m/s) = ");
    Serial.println(averageScale, 6);

    Serial.print("Minimum = ");
    Serial.println(minScale, 6);

    Serial.print("Maximum = ");
    Serial.println(maxScale, 6);

    Serial.print("Spread = ");
    Serial.println(spread, 6);

    Serial.println();

    Serial.println("Paste this into Master Code:");

    Serial.print("const float ANEMOMETER_SCALE = ");
    Serial.print(averageScale, 6);
    Serial.println("f;");

    Serial.println();
    Serial.println("Calibration Complete.");

    completed = true;
}