/* =========================================================
   WIND VANE ZERO POSITION CALIBRATION
   =========================================================
   Purpose: Determine wvane_zeropos for the Master Code.
   
   Procedure:
   1. Upload sketch.
   2. Open Serial Monitor @ 250000 baud.
   3. Point vane directly into the turbine centerline.
   4. Wait for readings to stabilize.
   5. Record the displayed Raw Angle (radians).
   6. Copy value into: float wvane_zeropos = X.XXXf;
   ========================================================= */

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp> // Modern Infineon Library

// Bring in the library classes safely
using namespace ifx::tlx493d;

// Power gating pins from your KiCad schematic
#define TLV0_PWR 12 
#define TLV1_PWR 10

// TLV0 tracks wind vane and maps to address profile A4 (0x1F)
TLx493D_A1B6 mag_wvane(Wire, TLx493D_IIC_ADDR_A4_e);

void setup() {
    Serial.begin(250000);
    while (!Serial);

    pinMode(SDA, OUTPUT);
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    // Clear rail state before executing your address assignment sequence
    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(100);

    Serial.println();
    Serial.println(F("=================================================="));
    Serial.println(F("  EXECUTING SEQUENTIAL ADDRESS CONFIGURATION...   "));
    Serial.println(F("=================================================="));

    // Force TLV0 (Wind Vane) to latch A4 (0x1F) and TLV1 (Pitch) to latch A0 (0x5E)
    uint16_t stabilize_ms = 20;

    digitalWrite(SDA, LOW);
    delay(stabilize_ms);
    digitalWrite(TLV0_PWR, HIGH); // TLV0 boots seeing SDA LOW -> Latches A4 (0x1F)
    delay(stabilize_ms);

    digitalWrite(SDA, HIGH);
    delay(stabilize_ms);
    digitalWrite(TLV1_PWR, HIGH); // TLV1 boots seeing SDA HIGH -> Latches A0 (0x5E)
    delay(stabilize_ms);

    // Initialize I2C Bus after addresses are physically locked
    Wire.begin();
    Wire.setClock(1000000);

    Serial.println();
    Serial.println(F("=================================================="));
    Serial.println(F("         WIND VANE ZERO ALIGNMENT UTILITY         "));
    Serial.println(F("=================================================="));
    Serial.println();
    Serial.println(F("Point vane perfectly straight ahead."));
    Serial.println(F("Record the stable Raw Angle value."));
    Serial.println();

    // Initialize the library structure for TLV0 (A4)
    if (!mag_wvane.begin()) {
        Serial.println(F("CRITICAL ERROR: TLV0 Wind Vane Sensor failed to initialize!"));
        while (1); 
    }

    delay(1000);
}

void loop() {
    double xmag = 0.0, ymag = 0.0, zmag = 0.0;

    // Modern library data fetch block
    mag_wvane.getMagneticField(&xmag, &ymag, &zmag);

    float xmag_f = (float)xmag;
    float ymag_f = (float)ymag;
    float rawAngle = atan2(xmag_f, ymag_f);

    // Prints with the memory-saving F() macro applied
    Serial.print(F("X: ")); 
    Serial.print(xmag_f, 3);
    Serial.print(F(" Y: ")); 
    Serial.print(ymag_f, 3);
    Serial.print(F(" | Raw Angle (rad): ")); 
    Serial.print(rawAngle, 4);
    Serial.print(F(" | Raw Angle (deg): ")); 
    Serial.println(rawAngle * 180.0f / PI, 2);

    delay(250);
}
