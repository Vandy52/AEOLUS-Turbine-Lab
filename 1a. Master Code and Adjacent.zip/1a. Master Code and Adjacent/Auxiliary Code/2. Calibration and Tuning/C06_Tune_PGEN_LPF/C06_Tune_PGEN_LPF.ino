// Tune PGEN LPF With LoadBank Switches
//
// Purpose:
// Automatically recommend PGEN_LPF for the Master Code.
//
// Added behavior:
// Physical switches -> 74HC165 -> Arduino -> 74HC595 -> MOSFETs -> Load banks
//
// Result:
// Flip a load-bank switch ON and the matching bulb/load bank turns ON immediately.
// The INA219 records the resulting power transient for PGEN_LPF tuning.

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_INA219.h>

Adafruit_INA219 ina219;

// ============================================================
// 74HC165 SWITCH INPUTS
// ============================================================

#define HC165_LOAD_PIN   15    // A1 / D15 -> SH/LD
#define HC165_CLOCK_PIN  16    // A2 / D16 -> CLK
#define HC165_DATA_PIN   17    // A3 / D17 <- QH

// ============================================================
// 74HC595 MOSFET OUTPUTS
// ============================================================

#define HC595_DATA_PIN   11    // D11 -> SER
#define HC595_CLOCK_PIN  13    // D13 -> SRCLK
#define HC595_LATCH_PIN  14    // A0 / D14 -> RCLK

// ============================================================
// LOAD BANK RESISTANCE TABLE
// ============================================================

const float LOAD_RESISTANCE_OHMS[7] =
{
    999999.0f,
    10.3f,
    5.15f,
    10.3f / 3.0f,
    2.575f,
    2.06f,
    10.3f / 6.0f
};

// ============================================================
// TEST SETTINGS
// ============================================================

const int NUM_LPF_VALUES = 7;

float lpfValues[NUM_LPF_VALUES] =
{
    0.05f,
    0.10f,
    0.15f,
    0.20f,
    0.25f,
    0.30f,
    0.40f
};

const int BASELINE_SAMPLES = 30;
const int NUM_SAMPLES = 120;
const int FINAL_AVG_SAMPLES = 20;
const int SETTLE_HOLD_SAMPLES = 8;

const unsigned long SAMPLE_DELAY_MS = 50;

float rawPowerSamples[NUM_SAMPLES];

float settlingTimeResults[NUM_LPF_VALUES];
float noiseResults[NUM_LPF_VALUES];
float scoreResults[NUM_LPF_VALUES];

byte lastSwitchState = 255;

// ============================================================
// SERIAL HELPERS
// ============================================================

void flushSerial()
{
    while (Serial.available() > 0)
    {
        Serial.read();
    }
}

void waitForY()
{
    flushSerial();

    while (true)
    {
        mirrorSwitchesToLoadBanks();

        if (Serial.available() > 0)
        {
            char c = Serial.read();

            if (c == 'Y' || c == 'y')
            {
                flushSerial();
                return;
            }
        }

        delay(20);
    }
}

// ============================================================
// SHIFT REGISTER FUNCTIONS
// ============================================================

byte readSwitches()
{
    byte raw = 0;

    digitalWrite(HC165_LOAD_PIN, LOW);
    delayMicroseconds(5);

    digitalWrite(HC165_LOAD_PIN, HIGH);
    delayMicroseconds(5);

    for (int i = 0; i < 8; i++)
    {
        raw <<= 1;

        if (digitalRead(HC165_DATA_PIN))
        {
            raw |= 1;
        }

        digitalWrite(HC165_CLOCK_PIN, HIGH);
        delayMicroseconds(5);

        digitalWrite(HC165_CLOCK_PIN, LOW);
        delayMicroseconds(5);
    }

    byte switches = 0;

    for (int bank = 0; bank < 6; bank++)
    {
        if (bitRead(raw, bank))
        {
            bitSet(switches, bank);
        }
    }

    return switches;
}

byte convertStateTo595(byte switchState)
{
    byte out = 0;

    for (int bank = 0; bank < 6; bank++)
    {
        if (bitRead(switchState, bank))
        {
            bitSet(out, bank + 1);   // QB = Bank 1
        }
    }

    return out;
}

void writeOutputs(byte state)
{
    digitalWrite(HC595_LATCH_PIN, LOW);
    shiftOut(HC595_DATA_PIN, HC595_CLOCK_PIN, MSBFIRST, state);
    digitalWrite(HC595_LATCH_PIN, HIGH);
}

int countBanks(byte switchState)
{
    int count = 0;

    for (int bank = 0; bank < 6; bank++)
    {
        if (bitRead(switchState, bank))
        {
            count++;
        }
    }

    return count;
}

void printActiveBanks(byte switchState)
{
    bool anyOn = false;

    for (int bank = 0; bank < 6; bank++)
    {
        if (bitRead(switchState, bank))
        {
            Serial.print(bank + 1);
            Serial.print(F(" "));
            anyOn = true;
        }
    }

    if (!anyOn)
    {
        Serial.print(F("NONE"));
    }
}

void mirrorSwitchesToLoadBanks()
{
    byte switchState = readSwitches();

    if (switchState != lastSwitchState)
    {
        lastSwitchState = switchState;

        byte outputState = convertStateTo595(switchState);
        writeOutputs(outputState);

        int activeCount = countBanks(switchState);

        Serial.println();
        Serial.println(F("------------------------------------"));
        Serial.println(F("SWITCH CHANGE DETECTED"));
        Serial.print(F("Active Banks: "));
        printActiveBanks(switchState);
        Serial.println();

        Serial.print(F("Equivalent Load: "));

        if (activeCount == 0)
        {
            Serial.println(F("OPEN CIRCUIT"));
        }
        else
        {
            Serial.print(LOAD_RESISTANCE_OHMS[activeCount], 4);
            Serial.println(F(" ohms"));
        }

        Serial.println(F("------------------------------------"));
    }
}
// ============================================================
// POWER HELPERS
// ============================================================

float readPower_W()
{
    // Keep switches mirrored while sampling
    mirrorSwitchesToLoadBanks();

    float voltage = ina219.getBusVoltage_V();
    float current_A = ina219.getCurrent_mA() / 1000.0f;

    return voltage * current_A;
}

float averagePower(int samples, int delay_ms)
{
    float sum = 0.0f;

    for (int i = 0; i < samples; i++)
    {
        mirrorSwitchesToLoadBanks();

        sum += readPower_W();

        delay(delay_ms);
    }

    return sum / (float)samples;
}

float computeMean(float data[], int startIndex, int count)
{
    float sum = 0.0f;

    for (int i = 0; i < count; i++)
    {
        sum += data[startIndex + i];
    }

    return sum / (float)count;
}

float computeStdDev(float data[], int startIndex, int count)
{
    float mean = computeMean(data, startIndex, count);

    float variance = 0.0f;

    for (int i = 0; i < count; i++)
    {
        float error = data[startIndex + i] - mean;
        variance += error * error;
    }

    variance /= (float)count;

    return sqrt(variance);
}

// ============================================================
// LPF EVALUATION
// ============================================================

void evaluateLPFValues(float baselinePower, float finalPower)
{
    float stepMagnitude = fabs(finalPower - baselinePower);

    if (stepMagnitude < 0.005f)
    {
        Serial.println();
        Serial.println(F("WARNING:"));
        Serial.println(F("Power change was very small."));
        Serial.println(F("Try changing another load bank."));
    }

    float settleBand = max(0.005f, stepMagnitude * 0.05f);

    Serial.println();
    Serial.println(F("=================================================="));
    Serial.println(F("        EVALUATING PGEN_LPF VALUES"));
    Serial.println(F("=================================================="));

    for (int c = 0; c < NUM_LPF_VALUES; c++)
    {
        float lpf = lpfValues[c];

        float filteredSamples[NUM_SAMPLES];

        float filtered = baselinePower;

        for (int i = 0; i < NUM_SAMPLES; i++)
        {
            filtered +=
                lpf *
                (rawPowerSamples[i] - filtered);

            filteredSamples[i] = filtered;
        }

        int settleIndex = -1;

        for (int i = 0; i < NUM_SAMPLES - SETTLE_HOLD_SAMPLES; i++)
        {
            bool settled = true;

            for (int j = 0; j < SETTLE_HOLD_SAMPLES; j++)
            {
                if (fabs(filteredSamples[i + j] - finalPower) > settleBand)
                {
                    settled = false;
                    break;
                }
            }

            if (settled)
            {
                settleIndex = i;
                break;
            }
        }

        float settlingTime;

        if (settleIndex < 0)
        {
            settlingTime = 999.0f;
        }
        else
        {
            settlingTime =
                (settleIndex * SAMPLE_DELAY_MS) / 1000.0f;
        }

        int noiseStart =
            NUM_SAMPLES - FINAL_AVG_SAMPLES;

        float noise =
            computeStdDev(
                filteredSamples,
                noiseStart,
                FINAL_AVG_SAMPLES);

        float normalizedNoise =
            noise /
            max(stepMagnitude, 0.01f);

        float score =
            settlingTime +
            normalizedNoise * 5.0f;

        settlingTimeResults[c] = settlingTime;
        noiseResults[c] = noise;
        scoreResults[c] = score;

        Serial.print(F("LPF "));
        Serial.print(lpf, 2);

        Serial.print(F(" | Settling: "));

        if (settlingTime > 900.0f)
        {
            Serial.print(F("NO SETTLE"));
        }
        else
        {
            Serial.print(settlingTime, 2);
            Serial.print(F(" s"));
        }

        Serial.print(F(" | Noise: "));
        Serial.print(noise, 5);

        Serial.print(F(" W | Score: "));
        Serial.println(score, 4);
    }
}

// ============================================================
// PRINT FINAL RECOMMENDATION
// ============================================================

void printRecommendation()
{
    int bestIndex = 0;

    for (int i = 1; i < NUM_LPF_VALUES; i++)
    {
        if (scoreResults[i] < scoreResults[bestIndex])
        {
            bestIndex = i;
        }
    }

    Serial.println();
    Serial.println(F("=================================================="));
    Serial.println(F("             PGEN_LPF RESULTS"));
    Serial.println(F("=================================================="));
    Serial.println(F("LPF     Settling(s)     Noise(W)     Score"));

    for (int i = 0; i < NUM_LPF_VALUES; i++)
    {
        Serial.print(lpfValues[i], 2);
        Serial.print(F("     "));

        if (settlingTimeResults[i] > 900.0f)
        {
            Serial.print(F("NO SETTLE     "));
        }
        else
        {
            Serial.print(settlingTimeResults[i], 2);
            Serial.print(F("          "));
        }

        Serial.print(noiseResults[i], 5);
        Serial.print(F("      "));
        Serial.println(scoreResults[i], 4);
    }

    Serial.println();
    Serial.println(F("=================================================="));
    Serial.println(F("RECOMMENDED MASTER CODE VALUE"));
    Serial.println(F("=================================================="));

    Serial.print(F("const float PGEN_LPF = "));
    Serial.print(lpfValues[bestIndex], 2);
    Serial.println(F("f;"));

    Serial.println();

    Serial.print(F("Winning Score: "));
    Serial.println(scoreResults[bestIndex], 4);

    Serial.println(F("=================================================="));
}
// ============================================================
// SETUP
// ============================================================

void setup()
{
    Serial.begin(250000);

    while (!Serial)
    {
        delay(10);
    }

    // ---------- 74HC165 ----------
    pinMode(HC165_LOAD_PIN, OUTPUT);
    pinMode(HC165_CLOCK_PIN, OUTPUT);
    pinMode(HC165_DATA_PIN, INPUT);

    digitalWrite(HC165_LOAD_PIN, HIGH);
    digitalWrite(HC165_CLOCK_PIN, LOW);

    // ---------- 74HC595 ----------
    pinMode(HC595_CLOCK_PIN, OUTPUT);
    pinMode(HC595_LATCH_PIN, OUTPUT);
    pinMode(HC595_DATA_PIN, OUTPUT);

    writeOutputs(0);

    // ---------- INA219 ----------
    Wire.begin();

    if (!ina219.begin())
    {
        Serial.println(F("ERROR: INA219 not detected."));
        while (true)
        {
            delay(100);
        }
    }

    Serial.println();
    Serial.println(F("=================================================="));
    Serial.println(F("      PGEN_LPF AUTO-TUNING WITH LIVE LOAD BANK"));
    Serial.println(F("=================================================="));
    Serial.println(F("Wind source ON"));
    Serial.println(F("Generator connected"));
    Serial.println(F("Flip any physical switch."));
    Serial.println(F("The corresponding light bulb/load bank should"));
    Serial.println(F("turn on immediately."));
    Serial.println(F("=================================================="));

    Serial.println();
    Serial.println(F("STEP 1"));
    Serial.println(F("Allow turbine to stabilize."));
    Serial.println(F("Press Y when ready."));
    waitForY();

    float baselinePower =
        averagePower(BASELINE_SAMPLES,
                     SAMPLE_DELAY_MS);

    Serial.println();

    Serial.print(F("Baseline Power = "));
    Serial.print(baselinePower,5);
    Serial.println(F(" W"));

    Serial.println();
    Serial.println(F("STEP 2"));
    Serial.println(F("Flip ONE load-bank switch."));
    Serial.println(F("The bulb should illuminate immediately."));
    Serial.println(F("Press Y immediately after changing it."));
    waitForY();

    Serial.println();
    Serial.println(F("Recording transient..."));

    for(int i=0;i<NUM_SAMPLES;i++)
    {
        mirrorSwitchesToLoadBanks();

        rawPowerSamples[i]=readPower_W();

        Serial.print(i);
        Serial.print(F(": "));
        Serial.print(rawPowerSamples[i],5);
        Serial.println(F(" W"));

        delay(SAMPLE_DELAY_MS);
    }

    float finalPower =
        computeMean(
            rawPowerSamples,
            NUM_SAMPLES-FINAL_AVG_SAMPLES,
            FINAL_AVG_SAMPLES);

    Serial.println();

    Serial.print(F("Final Power = "));
    Serial.print(finalPower,5);
    Serial.println(F(" W"));

    Serial.print(F("Power Step = "));
    Serial.print(fabs(finalPower-baselinePower),5);
    Serial.println(F(" W"));

    evaluateLPFValues(
        baselinePower,
        finalPower);

    printRecommendation();

    Serial.println();
    Serial.println(F("=================================================="));
    Serial.println(F("Tuning Complete"));
    Serial.println(F("Paste the recommended"));
    Serial.println(F("PGEN_LPF into the Master Code."));
    Serial.println(F("=================================================="));
}

// ============================================================
// LOOP
// ============================================================

void loop()
{
    // Keep switches mirrored forever so the
    // user can continue testing load banks.

    mirrorSwitchesToLoadBanks();

    delay(10);
}