// Yaw_Deadband_Determination
// Purpose: Analyzes live wind vane turbulence/bobble over a test window 
//          and automatically recommends an optimal YAW_DEADBAND angle.

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

#define TLV0_PWR 12 
#define TLV1_PWR 10

TLx493D_A1B6 mag_wvane(Wire, TLx493D_IIC_ADDR_A4_e);

// --- CALIBRATION CONFIGURATION ---
float wvane_lpf = 0.08f;                      // Default LPF (updated at startup)
const unsigned long SAMPLING_TIME_MS = 30000; // 30-second observation window
const float SAFETY_MARGIN_FACTOR = 1.25f;      // 25% safety buffer above peak-to-peak jitter

// --- GLOBAL VARIABLES ---
float filtered_angle_rad = 0.0f;
float last_valid_raw_rad = 0.0f;
bool wvaneInitialized = false;

// ============================================================
// HELPER FUNCTIONS
// ============================================================

float getFloatingInput() {
    while (!Serial.available());
    float val = Serial.parseFloat();
    while (Serial.available()) Serial.read(); 
    return val;
}

void waitForUser() {
    Serial.println(F(">>> Type 'Y' and press Send to start sampling..."));
    while (true) {
        if (Serial.available() > 0) {
            char ch = Serial.read();
            if (ch == 'Y' || ch == 'y') {
                while (Serial.available() > 0) Serial.read();
                break;
            }
        }
        delay(20);
    }
}

float readFilteredVaneRad() {
    double xmag = 0.0, ymag = 0.0, zmag = 0.0;
    mag_wvane.getMagneticField(&xmag, &ymag, &zmag);

    float raw_angle_rad = last_valid_raw_rad;

    // Protection against I2C bus faults
    if (Wire.getWireTimeoutFlag()) {
        Wire.clearWireTimeoutFlag();
    } else {
        raw_angle_rad = atan2((float)xmag, (float)ymag);
        last_valid_raw_rad = raw_angle_rad;
    }

    if (!wvaneInitialized) {
        filtered_angle_rad = raw_angle_rad;
        wvaneInitialized = true;
    }

    // Standard Exponential Moving Average LPF
    filtered_angle_rad += wvane_lpf * (raw_angle_rad - filtered_angle_rad);
    return filtered_angle_rad;
}

// ============================================================
// SETUP
// ============================================================

void setup() {
    Serial.begin(250000);
    while (!Serial);

    Serial.println(F("\n=================================================="));
    Serial.println(F("MANDATORY INPUT REQUIRED:"));
    Serial.println(F("Enter your optimal 'wvane_lpf' (e.g., 0.08):"));
    wvane_lpf = getFloatingInput();
    Serial.print(F(">> Using wvane_lpf = "));
    Serial.println(wvane_lpf, 3);

    // Hardware power-up sequence for TLV0 isolation
    pinMode(SDA, OUTPUT); 
    pinMode(TLV0_PWR, OUTPUT); 
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(TLV0_PWR, LOW); 
    digitalWrite(TLV1_PWR, LOW); 
    delay(500);

    digitalWrite(SDA, LOW); 
    delay(50);
    digitalWrite(TLV0_PWR, HIGH); 
    delay(250);

    pinMode(SDA, INPUT); 
    delay(50);
    digitalWrite(TLV1_PWR, HIGH); 
    delay(250);

    Wire.begin();
    Wire.setClock(400000);           // Fast Mode I2C
    Wire.setWireTimeout(3000, true); // Hardware hang protection

    if (!mag_wvane.begin()) { 
        Serial.println(F("CRITICAL ERROR: TLV0 Wind Vane Sensor failed to initialize!")); 
        while (1) delay(100); 
    }

    Serial.println(F("=================================================="));
    Serial.println(F("  FILTERED YAW DEADBAND AUTO-TUNING ROUTINE      "));
    Serial.println(F("=================================================="));
    Serial.println(F("Measures smoothed aerodynamic bobble over 30 seconds"));
    Serial.println(F("to calculate an optimal YAW_DEADBAND limit."));
    Serial.println(F("--------------------------------------------------"));
}

// ============================================================
// MAIN LOOP
// ============================================================

void loop() {
    Serial.println(F("\nSet wind source to operational speed."));
    waitForUser();

    Serial.println(F("\n[SAMPLING] Measuring LPF-filtered wind vane excursion..."));
    
    Wire.clearWireTimeoutFlag();
    wvaneInitialized = false; // Reset LPF initialization for fresh start

    unsigned long startTime = millis();
    unsigned long sampleCount = 0;

    float min_angle_rad = 100.0f;
    float max_angle_rad = -100.0f;
    double sum_angle_rad = 0.0;

    while (millis() - startTime < SAMPLING_TIME_MS) {
        float current_rad = readFilteredVaneRad();

        if (current_rad < min_angle_rad) min_angle_rad = current_rad;
        if (current_rad > max_angle_rad) max_angle_rad = current_rad;
        sum_angle_rad += current_rad;
        sampleCount++;

        // Live telemetry line
        Serial.print(F("\rFiltered Angle: "));
        Serial.print(current_rad * 180.0f / PI, 2);
        Serial.print(F("° | Elapsed: "));
        Serial.print((millis() - startTime) / 1000.0f, 1);
        Serial.print(F("s  "));

        delay(50); // 20 Hz sample rate
    }

    // --- CALCULATIONS ---
    float mean_rad = (float)(sum_angle_rad / sampleCount);
    float peak_to_peak_rad = max_angle_rad - min_angle_rad;
    
    // Half of peak-to-peak equals peak amplitude away from mean
    float raw_noise_half_amplitude_deg = (peak_to_peak_rad / 2.0f) * (180.0f / PI);
    
    // Apply safety margin buffer
    float recommended_deadband_deg = raw_noise_half_amplitude_deg * SAFETY_MARGIN_FACTOR;
    float recommended_deadband_rad = recommended_deadband_deg * (PI / 180.0f);

    // --- DISPLAY RESULTS ---
    Serial.println(F("\n\n================ AUTOTUNE RESULTS ================"));
    Serial.print(F("Total Samples Captured   : ")); Serial.println(sampleCount);
    Serial.print(F("Mean Center Angle        : ")); Serial.print(mean_rad * 180.0f / PI, 2); Serial.println(F("°"));
    Serial.print(F("Min / Max Excursions     : ")); Serial.print(min_angle_rad * 180.0f / PI, 2); Serial.print(F("° to ")); Serial.print(max_angle_rad * 180.0f / PI, 2); Serial.println(F("°"));
    Serial.print(F("Filtered Bobble Amplitude: ±")); Serial.print(raw_noise_half_amplitude_deg, 2); Serial.println(F("°"));
    Serial.println(F("--------------------------------------------------"));
    Serial.print(F("RECOMMENDED YAW_DEADBAND : ±")); Serial.print(recommended_deadband_deg, 2); Serial.println(F("°"));
    Serial.print(F("                       ( ")); Serial.print(recommended_deadband_rad, 4); Serial.println(F(" rad )"));
    Serial.println(F("=================================================="));
}