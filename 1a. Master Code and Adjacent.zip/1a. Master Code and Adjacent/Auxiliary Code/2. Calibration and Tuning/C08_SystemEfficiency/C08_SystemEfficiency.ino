// ==================================================================================
//  DISCOVERING ELECTROMECHANICAL SYSTEM EFFICIENCY
// ==================================================================================
// PURPOSE:
// Once Cp Discovery identifies the optimal aerodynamic pitch angle, this script isolates
// internal electromechanical conversion losses. By locking the blade assembly
// into that winning position, aerodynamic variable shifts are eliminated. The operator
// then alters wind tunnel speed steps. This code records the resulting power curves
// to identify internal losses caused by friction, generator core heat, and dual
// bridge rectifier voltage drops.
//
// HOW TO RUN:
// 1. Open Serial Monitor at 250000 baud with "No Line Ending".
// 2. Input your winning Cp value and target angle discovered in Cp Discovery.
// 3. Turn on your physical electrical load resistor switches as prompted.
// 4. Vary your wind tunnel velocity across different speed steps, running a
//    new measurement validation command ('Y') at each step.
//
// Note: The Variable Load bank is needed
// Note: This code bypasses the MOSFETS
// ==================================================================================

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_INA219.h>
#include <TLx493D_inc.hpp>
#include <PinChangeInterrupt.h>

using namespace ifx::tlx493d;

// -----------------------------
// PIN DEFINITIONS
// -----------------------------
#define ANEMOMETER_PIN  8    // HS_N (Port B PinChange Interrupt)
#define UNUSED_HS_S_PIN 9    // HS_S (Port B) - Pin 9 shares vector with Pin 8

#define TLV0_PWR 12
#define TLV1_PWR 10

#define M1_SLEEP 7
#define M1_EN1   6
#define M1_EN0   5

// 74HC165 switch inputs
#define HC165_LOAD_PIN   15
#define HC165_CLOCK_PIN  16
#define HC165_DATA_PIN   17

// 74HC595 load-bank outputs
#define HC595_DATA_PIN   11
#define HC595_CLOCK_PIN  13
#define HC595_LATCH_PIN  14

Adafruit_INA219 ina219;
TLx493D_A1B6 mag_collective(Wire, TLx493D_IIC_ADDR_A0_e);

// -----------------------------
// CALIBRATION & CONSTANTS
// -----------------------------
float TUNED_CP = 0.0f;
float ANEMOMETER_SCALE = 1.575226f; // Calibrated factor
float BETA_LPF = 0.10f;
float PGEN_LPF = 0.15f;

// Physical Pitch Angle Boundaries (Degrees)
float Blade_angle_min = 55.0f;
float Blade_angle_max = 105.0f;

float coll_motor_drivetime_ms = 150.0f;

float filtered_beta_deg = 0.0f;
float filteredPower_W = 0.0f;

bool betaInitialized = false;
bool powerInitialized = false;

const float RHO = 1.225f;
const float ROTOR_AREA = 0.503f;
const float MS_TO_MPH = 2.23694f; // Conversion constant

// -----------------------------
// ANEMOMETER VARIABLES
// -----------------------------
volatile unsigned long pulseCount = 0;
volatile unsigned long firstPulseTime = 0;
volatile unsigned long lastPulseTime = 0;

// -----------------------------
// LOAD BANK VARIABLES
// -----------------------------
byte lastSwitchState = 255;
byte outputState = 0;

// ============================================================
// FUNCTION DECLARATIONS
// ============================================================
float getFloatingInput();
void waitForUser();

void anemometer_int();
float get_wind_vel();

byte readSwitches();
byte convertStateTo595(byte switchState);
void writeOutputs(byte state);
void mirrorSwitchesToLoadBanks();

float get_collective_deg(TLx493D_A1B6 &MagSensor);
void drive_motor(int pin_en0, int pin_en1, int pin_sleep, bool reverse, int time_ms);
void commandPitchToTarget(float targetAngleDeg);

float readFilteredPower_W();

// ============================================================
// SERIAL HELPERS
// ============================================================

float getFloatingInput()
{
    while (true)
    {
        mirrorSwitchesToLoadBanks();

        if (Serial.available() > 0)
        {
            float val = Serial.parseFloat();

            delay(10);

            while (Serial.available() > 0)
            {
                Serial.read();
            }

            return val;
        }

        delay(10);
    }
}

void waitForUser()
{
    Serial.println(F(">>> Type 'Y' and press Send to proceed..."));

    while (true)
    {
        mirrorSwitchesToLoadBanks();

        if (Serial.available() > 0)
        {
            char ch = Serial.read();

            if (ch == 'Y' || ch == 'y')
            {
                delay(10);

                while (Serial.available() > 0)
                {
                    Serial.read();
                }

                break;
            }
        }

        delay(20);
    }
}

// ============================================================
// LOAD BANK CONTROL
// ============================================================

byte readSwitches()
{
    byte raw = 0;

    digitalWrite(HC165_LOAD_PIN, LOW);
    delayMicroseconds(5);
    digitalWrite(HC165_LOAD_PIN, HIGH);
    delayMicroseconds(5);

    for (int i = 0; i < 8; i++)
    {
        raw <<= 1;

        if (digitalRead(HC165_DATA_PIN))
        {
            raw |= 1;
        }

        digitalWrite(HC165_CLOCK_PIN, HIGH);
        delayMicroseconds(5);
        digitalWrite(HC165_CLOCK_PIN, LOW);
        delayMicroseconds(5);
    }

    byte switches = 0;

    for (int bank = 0; bank < 6; bank++)
    {
        if (bitRead(raw, bank))
        {
            bitSet(switches, bank);
        }
    }

    return switches;
}

byte convertStateTo595(byte switchState)
{
    byte out = 0;

    for (int bank = 0; bank < 6; bank++)
    {
        if (bitRead(switchState, bank))
        {
            bitSet(out, bank + 1);
        }
    }

    return out;
}

void writeOutputs(byte state)
{
    digitalWrite(HC595_LATCH_PIN, LOW);
    shiftOut(HC595_DATA_PIN, HC595_CLOCK_PIN, MSBFIRST, state);
    digitalWrite(HC595_LATCH_PIN, HIGH);
}

void mirrorSwitchesToLoadBanks()
{
    byte switchState = readSwitches();

    if (switchState != lastSwitchState)
    {
        lastSwitchState = switchState;

        outputState = convertStateTo595(switchState);
        writeOutputs(outputState);

        Serial.println();
        Serial.println(F("------------------------------------"));
        Serial.println(F("LOAD BANK SWITCH CHANGE DETECTED"));
        Serial.print(F("Switch Byte: "));
        Serial.println(switchState, BIN);
        Serial.print(F("595 Output : "));
        Serial.println(outputState, BIN);
        Serial.println(F("------------------------------------"));
    }
}

// ============================================================
// ANEMOMETER ISR + SPEED CALCULATION
// ============================================================

void anemometer_int()
{
    unsigned long now = micros();

    if (pulseCount == 0)
    {
        firstPulseTime = now;
    }

    lastPulseTime = now;
    pulseCount++;
}

float get_wind_vel()
{
    noInterrupts();

    unsigned long pulses = pulseCount;
    unsigned long first = firstPulseTime;
    unsigned long last = lastPulseTime;

    interrupts();

    if (pulses < 2)
    {
        return 0.0f;
    }

    float elapsed_s = (last - first) / 1000000.0f;

    if (elapsed_s <= 0.0f)
    {
        return 0.0f;
    }

    float rps = (float)(pulses - 1) / elapsed_s;

    return rps * ANEMOMETER_SCALE;
}

// ============================================================
// PITCH FEEDBACK + MOTOR CONTROL (2D VECTOR ANGLE BASED)
// ============================================================

float get_collective_deg(TLx493D_A1B6 &MagSensor)
{
    double xmag = 0.0;
    double ymag = 0.0;
    double zmag = 0.0;

    MagSensor.getMagneticField(&xmag, &ymag, &zmag);

    // Compute continuous 2D magnetic vector angle in degrees (0° to 360°)
    float rad = atan2((float)ymag, (float)xmag);
    float raw_angle_deg = rad * (180.0f / 3.14159265f);
    if (raw_angle_deg < 0.0f) raw_angle_deg += 360.0f;

    if (!betaInitialized)
    {
        filtered_beta_deg = raw_angle_deg;
        betaInitialized = true;
    }

    filtered_beta_deg += BETA_LPF * (raw_angle_deg - filtered_beta_deg);

    return filtered_beta_deg;
}

void drive_motor(int pin_en0, int pin_en1, int pin_sleep, bool reverse, int time_ms)
{
    digitalWrite(pin_sleep, HIGH);

    if (reverse)
    {
        digitalWrite(pin_en0, HIGH);
        digitalWrite(pin_en1, LOW);
    }
    else
    {
        digitalWrite(pin_en0, LOW);
        digitalWrite(pin_en1, HIGH);
    }

    delay(time_ms);

    digitalWrite(pin_sleep, LOW);
    digitalWrite(pin_en0, LOW);
    digitalWrite(pin_en1, LOW);
}

void commandPitchToTarget(float targetAngleDeg)
{
    const float PITCH_TOLERANCE_DEG = 0.5f; // Tolerance in degrees

    targetAngleDeg = constrain(targetAngleDeg, min(Blade_angle_min, Blade_angle_max), max(Blade_angle_min, Blade_angle_max));

    unsigned long startMoveTime = millis();

    while (millis() - startMoveTime < 6000)
    {
        mirrorSwitchesToLoadBanks();

        float current_deg = get_collective_deg(mag_collective);
        float pitch_error_deg = targetAngleDeg - current_deg;

        if (fabs(pitch_error_deg) <= PITCH_TOLERANCE_DEG)
        {
            break;
        }

        if (pitch_error_deg > 0.0f)
        {
            drive_motor(M1_EN0, M1_EN1, M1_SLEEP, false, coll_motor_drivetime_ms);
        }
        else
        {
            drive_motor(M1_EN0, M1_EN1, M1_SLEEP, true, coll_motor_drivetime_ms);
        }

        delay(50);
    }
}

// ============================================================
// POWER MEASUREMENT
// ============================================================

float readFilteredPower_W()
{
    mirrorSwitchesToLoadBanks();

    float voltage = ina219.getBusVoltage_V();
    float current_A = ina219.getCurrent_mA() / 1000.0f;

    float rawPower = voltage * current_A;

    if (!powerInitialized)
    {
        filteredPower_W = rawPower;
        powerInitialized = true;
    }

    filteredPower_W += PGEN_LPF * (rawPower - filteredPower_W);

    return filteredPower_W;
}

// ============================================================
// SETUP
// ============================================================

void setup()
{
    Serial.begin(250000);

    while (!Serial)
    {
        delay(10);
    }

    pinMode(ANEMOMETER_PIN, INPUT_PULLUP);
    pinMode(UNUSED_HS_S_PIN, INPUT);
    disablePCINT(digitalPinToPCINT(UNUSED_HS_S_PIN));

    attachPCINT(digitalPinToPCINT(ANEMOMETER_PIN), anemometer_int, FALLING);

    pinMode(M1_EN0, OUTPUT);
    pinMode(M1_EN1, OUTPUT);
    pinMode(M1_SLEEP, OUTPUT);

    digitalWrite(M1_EN0, LOW);
    digitalWrite(M1_EN1, LOW);
    digitalWrite(M1_SLEEP, LOW);

    pinMode(HC165_LOAD_PIN, OUTPUT);
    pinMode(HC165_CLOCK_PIN, OUTPUT);
    pinMode(HC165_DATA_PIN, INPUT);

    digitalWrite(HC165_LOAD_PIN, HIGH);
    digitalWrite(HC165_CLOCK_PIN, LOW);

    pinMode(HC595_DATA_PIN, OUTPUT);
    pinMode(HC595_CLOCK_PIN, OUTPUT);
    pinMode(HC595_LATCH_PIN, OUTPUT);

    writeOutputs(0);

    pinMode(SDA, OUTPUT);
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(500);

    digitalWrite(SDA, LOW);
    delay(50);
    digitalWrite(TLV0_PWR, HIGH);
    delay(250);

    pinMode(SDA, INPUT);
    delay(50);
    digitalWrite(TLV1_PWR, HIGH);
    delay(250);

    Wire.begin();
    Wire.setClock(100000);

    if (!mag_collective.begin())
    {
        Serial.println(F("CRITICAL ERROR: TLV1 Collective Sensor failed to initialize!"));
        while (true) delay(100);
    }

    if (!ina219.begin())
    {
        Serial.println(F("ERROR: INA219 configuration matrix fault!"));
        while (true) delay(100);
    }

    Serial.println(F("=================================================="));
    Serial.println(F("   WIND TURBINE TEST: DISCOVER SYSTEM EFFICIENCY  "));
    Serial.println(F("   WITH LIVE SWITCH -> LOAD BANK MIRRORING         "));
    Serial.println(F("=================================================="));

    // PROMPT BOUNDS FIRST
    Serial.println(F("Enter Blade_angle_min (e.g., 55.0):"));
    Blade_angle_min = getFloatingInput();
    Serial.print(F("-> Blade_angle_min = "));
    Serial.println(Blade_angle_min, 1);

    Serial.println(F("\nEnter Blade_angle_max (e.g., 105.0):"));
    Blade_angle_max = getFloatingInput();
    Serial.print(F("-> Blade_angle_max = "));
    Serial.println(Blade_angle_max, 1);

    // THEN PROMPT OPTIMAL PITCH ANGLE
    Serial.println(F("\nWhat was the optimal pitch angle?"));
    float bestAngle = getFloatingInput();
    Serial.print(F("-> Optimal angle = "));
    Serial.print(bestAngle, 1);
    Serial.println(F(" deg"));

    Serial.println(F("\nWhat is your discovered Tuned_CP value from Cp Discovery?"));
    TUNED_CP = getFloatingInput();
    Serial.print(F("-> TUNED_CP = "));
    Serial.println(TUNED_CP, 4);

    Serial.println(F("\nEnter calibrated ANEMOMETER_SCALE:"));
    ANEMOMETER_SCALE = getFloatingInput();
    Serial.print(F("-> ANEMOMETER_SCALE = "));
    Serial.println(ANEMOMETER_SCALE, 4);

    Serial.println(F("\nEnter tuned BETA_LPF:"));
    BETA_LPF = getFloatingInput();
    Serial.print(F("-> BETA_LPF = "));
    Serial.println(BETA_LPF, 3);

    Serial.println(F("\nEnter tuned PGEN_LPF:"));
    PGEN_LPF = getFloatingInput();
    Serial.print(F("-> PGEN_LPF = "));
    Serial.println(PGEN_LPF, 3);

    if (TUNED_CP <= 0.0f) {
        TUNED_CP = 0.0001f;
    }

    Serial.print(F("\nDriving pitch to "));
    Serial.print(bestAngle, 1);
    Serial.println(F(" deg..."));

    commandPitchToTarget(bestAngle);

    Serial.println(F("[LOCKED] Pitch configuration stable."));

    Serial.println(F("\nFlip desired load-bank switches ON."));
    Serial.println(F("Bulbs/load banks should respond immediately."));
    waitForUser();

    Serial.println(F("Verifying electrical continuity..."));
    delay(500);

    mirrorSwitchesToLoadBanks();

    float test_current = ina219.getCurrent_mA();

    if (abs(test_current) < 2.0f)
    {
        Serial.println(F("--> WARNING: Current is very low."));
        Serial.println(F("--> Ensure wind source is ON and load switches are ON."));
        waitForUser();
    }
    else
    {
        Serial.println(F("[SUCCESS] Active current detected."));
    }

    Serial.println(F("Initializing logging script..."));
}

// ============================================================
// LOOP
// ============================================================

void loop()
{
    Serial.println(F("\n--------------------------------------------------"));
    Serial.println(F("Set wind tunnel to a NEW velocity step."));
    Serial.println(F("Once stabilized, type Y to measure."));
    waitForUser();

    noInterrupts();
    pulseCount = 0;
    firstPulseTime = 0;
    lastPulseTime = 0;
    interrupts();

    Serial.println(F("Sampling wind velocity for 10 seconds..."));

    delay(10000);

    float localWindSpeed = get_wind_vel();
    if (localWindSpeed < 0.1f)
    {
        localWindSpeed = 0.1f;
    }

    float localWindSpeedMPH = localWindSpeed * MS_TO_MPH;

    Serial.print(F("Wind Speed Captured: "));
    Serial.print(localWindSpeed, 2);
    Serial.print(F(" m/s ("));
    Serial.print(localWindSpeedMPH, 2);
    Serial.println(F(" MPH)"));

    Serial.println(F("Analyzing electrical bus power..."));

    const int NUM_POWER_SAMPLES = 30;
    float totalPower = 0.0f;
    powerInitialized = false;

    for (int i = 0; i < NUM_POWER_SAMPLES; i++)
    {
        mirrorSwitchesToLoadBanks();
        totalPower += readFilteredPower_W();
        delay(70);
    }

    float realPgen = totalPower / (float)NUM_POWER_SAMPLES;

    float pMechanicalBlades =
        0.5f *
        RHO *
        ROTOR_AREA *
        TUNED_CP *
        localWindSpeed *
        localWindSpeed *
        localWindSpeed;

    float SystemEfficiency = 0.0f;
    if (pMechanicalBlades > 0.0001f)
    {
        SystemEfficiency = realPgen / pMechanicalBlades;
    }

    Serial.println(F("\n====== DISCOVERY LOG RESULTS ======"));
    Serial.print(F("Computed Wind Speed: "));
    Serial.print(localWindSpeed, 2);
    Serial.print(F(" m/s ("));
    Serial.print(localWindSpeedMPH, 2);
    Serial.println(F(" MPH)"));

    Serial.print(F("Blade Mechanical Power Prediction: "));
    Serial.print(pMechanicalBlades, 4);
    Serial.println(F(" W"));

    Serial.print(F("True Electrical Power INA219: "));
    Serial.print(realPgen, 4);
    Serial.println(F(" W"));

    Serial.println(F("------------------------------------"));

    Serial.print(F("DISCOVERED SYSTEM EFFICIENCY VALUE: "));
    Serial.print(SystemEfficiency, 4);

    Serial.print(F(" or "));
    Serial.print(SystemEfficiency * 100.0f, 1);
    Serial.println(F("%"));

    Serial.println(F("===================================="));
}