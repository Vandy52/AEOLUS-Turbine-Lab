// Auto Tune Pitch LPF
//
// Purpose:
// Automatically test several BETA_LPF values and recommend the best one.
//
// This test:
// - Asks for coll_deg_min and coll_deg_max
// - Moves the pitch motor during each test
// - Measures raw pitch response
// - Measures filtered pitch response
// - Scores each BETA_LPF value
//
// Commands:
// - Follow Serial Monitor prompts
// - Press ENTER when ready for each movement

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

// ============================================================
// PIN DEFINITIONS
// ============================================================
#define TLV0_PWR 12
#define TLV1_PWR 10

#define M1_SLEEP 7
#define M1_EN1   6
#define M1_EN0   5

// ============================================================
// SENSOR OBJECT & BACKUP STATE
// ============================================================
// Address A0 for collective pitch sensor (TLV1)
TLx493D_A1B6 mag_collective(Wire, TLx493D_IIC_ADDR_A0_e);
float last_valid_percent = 0.0f; 

// ============================================================
// CALIBRATION VALUES
// ============================================================
float coll_deg_min = 55.0f;
float coll_deg_max = 105.0f;

// ============================================================
// LPF TEST VALUES
// ============================================================
const int NUM_LPF_VALUES = 7;
float beta_lpf_values[NUM_LPF_VALUES] = {0.05f, 0.10f, 0.15f, 0.20f, 0.30f, 0.40f, 0.60f};

float score_results[NUM_LPF_VALUES];
float raw_jitter_results[NUM_LPF_VALUES];
float filtered_jitter_results[NUM_LPF_VALUES];
float lag_results[NUM_LPF_VALUES];

// ============================================================
// TEST SETTINGS
// ============================================================
const unsigned long SAMPLE_INTERVAL_MS = 50;
const unsigned long MOTOR_RUN_TIME_MS  = 5000; // 5 Seconds Forward / 5 Seconds Back
const unsigned long SETTLE_TIME_MS     = 800;

// ============================================================
// SERIAL HELPERS
// ============================================================
void waitForEnter()
{
    while (Serial.available() > 0) Serial.read();
    Serial.println(F("Press ENTER when ready..."));
    while (Serial.available() == 0) delay(10);
    while (Serial.available() > 0) Serial.read();
}

float getFloatingInput()
{
    while (Serial.available() == 0) delay(10);
    float val = Serial.parseFloat();
    while (Serial.available() > 0) Serial.read();
    return val;
}

// ============================================================
// MOTOR HELPERS
// ============================================================
void stopMotor()
{
    digitalWrite(M1_SLEEP, LOW);
    digitalWrite(M1_EN0, LOW);
    digitalWrite(M1_EN1, LOW);
}

void driveForward()
{
    digitalWrite(M1_SLEEP, HIGH);
    digitalWrite(M1_EN0, LOW);
    digitalWrite(M1_EN1, HIGH);
}

void driveBackward()
{
    digitalWrite(M1_SLEEP, HIGH);
    digitalWrite(M1_EN0, HIGH);
    digitalWrite(M1_EN1, LOW);
}

// ============================================================
// SELF-HEALING RECOVERY SENSOR READ
// ============================================================
float get_collective_percent()
{
    double xmag = 0.0, ymag = 0.0, zmag = 0.0;
    
    Wire.clearWireTimeoutFlag();
    mag_collective.getMagneticField(&xmag, &ymag, &zmag);

    // Reset I2C connection on bus freeze or motor noise fault
    if (Wire.getWireTimeoutFlag() || (xmag == 0.0 && ymag == 0.0 && zmag == 0.0)) 
    {
        Wire.clearWireTimeoutFlag();
        Wire.begin();
        Wire.setClock(400000);
        Wire.setWireTimeout(3000, true);
        mag_collective.begin();
        return last_valid_percent; 
    }

    // Compute continuous 2D magnetic angle in degrees (0° to 360°)
    float rad = atan2((float)ymag, (float)xmag);
    float raw_angle_deg = rad * (180.0f / 3.14159265f);
    if (raw_angle_deg < 0.0f) raw_angle_deg += 360.0f;

    float sensor_span = coll_deg_max - coll_deg_min;
    if (fabs(sensor_span) < 0.01f) return 0.0f;

    float percent = (raw_angle_deg - coll_deg_min) / sensor_span;
    last_valid_percent = constrain(percent, 0.0f, 1.0f);
    return last_valid_percent;
}

// ============================================================
// TEST ONE LPF VALUE
// ============================================================
void runLPFTest(int index)
{
    float beta_lpf = beta_lpf_values[index];

    Serial.println();
    Serial.println(F("================================================"));
    Serial.print(F("Testing BETA_LPF = ")); Serial.println(beta_lpf, 2);
    Serial.println(F("================================================"));

    waitForEnter();

    float filtered = get_collective_percent();

    long count = 0;
    float M2_raw = 0.0f, M2_filtered = 0.0f;
    float mean_raw = 0.0f, mean_filtered = 0.0f;
    float total_lag = 0.0f;

    // --- PHASE 1: FORWARD MOTION ---
    Serial.println(F("Driving FORWARD..."));
    driveForward();
    unsigned long startTime = millis();

    while (millis() - startTime < MOTOR_RUN_TIME_MS)
    {
        float raw = get_collective_percent();
        filtered += beta_lpf * (raw - filtered);

        count++;
        total_lag += fabs(raw - filtered);

        float delta_raw = raw - mean_raw;
        mean_raw += delta_raw / count;
        M2_raw += delta_raw * (raw - mean_raw);

        float delta_filt = filtered - mean_filtered;
        mean_filtered += delta_filt / count;
        M2_filtered += delta_filt * (filtered - mean_filtered);

        delay(SAMPLE_INTERVAL_MS);
    }
    stopMotor();
    delay(SETTLE_TIME_MS);

    // --- PHASE 2: BACKWARD MOTION ---
    Serial.println(F("Driving BACKWARD..."));
    driveBackward();
    startTime = millis();

    while (millis() - startTime < MOTOR_RUN_TIME_MS)
    {
        float raw = get_collective_percent();
        filtered += beta_lpf * (raw - filtered);

        count++;
        total_lag += fabs(raw - filtered);

        float delta_raw = raw - mean_raw;
        mean_raw += delta_raw / count;
        M2_raw += delta_raw * (raw - mean_raw);

        float delta_filt = filtered - mean_filtered;
        mean_filtered += delta_filt / count;
        M2_filtered += delta_filt * (filtered - mean_filtered);

        delay(SAMPLE_INTERVAL_MS);
    }
    stopMotor();

    raw_jitter_results[index] = (count > 1) ? sqrt(M2_raw / count) : 0.0f;
    filtered_jitter_results[index] = (count > 1) ? sqrt(M2_filtered / count) : 0.0f;
    lag_results[index] = total_lag / (float)count;

    score_results[index] = filtered_jitter_results[index] + (2.0f * lag_results[index]);

    Serial.println();
    Serial.print(F("Raw Jitter      : ")); Serial.println(raw_jitter_results[index], 5);
    Serial.print(F("Filtered Jitter : ")); Serial.println(filtered_jitter_results[index], 5);
    Serial.print(F("Estimated Lag   : ")); Serial.println(lag_results[index], 5);
    Serial.print(F("Overall Score   : ")); Serial.println(score_results[index], 5);
}

// ============================================================
// ARDUINO SETUP & MAIN LOOP
// ============================================================
void setup() 
{
    Serial.begin(250000);
    while(!Serial);

    pinMode(M1_SLEEP, OUTPUT);
    pinMode(M1_EN0, OUTPUT);
    pinMode(M1_EN1, OUTPUT);
    stopMotor();

    pinMode(SDA, OUTPUT); 
    pinMode(TLV0_PWR, OUTPUT); 
    pinMode(TLV1_PWR, OUTPUT);
    
    // Exact Power Sequence Routine matching Master Code
    digitalWrite(TLV0_PWR, LOW); 
    digitalWrite(TLV1_PWR, LOW); 
    delay(500);

    // Assign TLV0 -> Address A4
    digitalWrite(SDA, LOW); 
    delay(50);
    digitalWrite(TLV0_PWR, HIGH); 
    delay(250);

    // Assign TLV1 -> Address A0
    pinMode(SDA, INPUT);     // Release SDA line for pull-ups
    delay(50);
    digitalWrite(TLV1_PWR, HIGH); 
    delay(250);

    Wire.begin();
    Wire.setClock(400000); 
    Wire.setWireTimeout(3000, true); 

    if (!mag_collective.begin()) 
    { 
        Serial.println(F("Collective sensor (A0) initialization failed!")); 
        while(1); 
    }

    Serial.println(F("\n=================================================="));
    Serial.println(F("      AUTOMATED BETA_LPF OPTIMIZATION RUN        "));
    Serial.println(F("=================================================="));
    
    Serial.println(F("Enter calibration value for 'coll_deg_min' (degrees):"));
    coll_deg_min = getFloatingInput();
    Serial.print(F("Saved coll_deg_min = ")); Serial.println(coll_deg_min, 2);

    Serial.println(F("Enter calibration value for 'coll_deg_max' (degrees):"));
    coll_deg_max = getFloatingInput();
    Serial.print(F("Saved coll_deg_max = ")); Serial.println(coll_deg_max, 2);
    
    Serial.println(F("\nReady to run optimization passes."));
}

void loop() 
{
    for (int i = 0; i < NUM_LPF_VALUES; i++) 
    {
        runLPFTest(i);
    }

    // Matrix Evaluation: Identify Top 2 valid responses
    int bestIndex = -1;
    int secondIndex = -1;
    float lowestScore = 999999.0f;
    float secondLowestScore = 999999.0f;
    
    for (int i = 0; i < NUM_LPF_VALUES; i++) 
    {
        if (score_results[i] <= 0.00001f) {
            continue;
        }

        if (score_results[i] < lowestScore) 
        {
            secondLowestScore = lowestScore;
            secondIndex = bestIndex;
            
            lowestScore = score_results[i];
            bestIndex = i;
        }
        else if (score_results[i] < secondLowestScore)
        {
            secondLowestScore = score_results[i];
            secondIndex = i;
        }
    }

    Serial.println(F("\n=================================================="));
    Serial.println(F("               OPTIMIZATION RESULTS               "));
    Serial.println(F("=================================================="));
    
    if (bestIndex != -1) {
        Serial.print(F(" 1ST PLACE (RECOMMENDED BETA_LPF): "));
        Serial.println(beta_lpf_values[bestIndex], 2);
        Serial.print(F(" Performance Penalty Score       : "));
        Serial.println(score_results[bestIndex], 5);
    } else {
        Serial.println(F(" 1ST PLACE                       : No valid profiles detected above 0.0"));
    }
    
    Serial.println(F("--------------------------------------------------"));
    
    if (secondIndex != -1) {
        Serial.print(F(" 2ND PLACE (RUNNER-UP OPTION)    : "));
        Serial.println(beta_lpf_values[secondIndex], 2);
        Serial.print(F(" Performance Penalty Score       : "));
        Serial.println(score_results[secondIndex], 5);
    } else {
        Serial.println(F(" 2ND PLACE                       : No secondary profiles detected"));
    }
    Serial.println(F("=================================================="));
    
    Serial.println(F("Testing complete. To rerun, press reset on the board."));
    while(1); 
}