// ==================================================================================
// AUTOMATED PITCH TUNING & OPTIMAL Cp DISCOVERY
// ==================================================================================
// PURPOSE:
// This script automates a full aerodynamic performance sweep. It automatically
// commands the pitch motor to step from Pitch min to Pitch max in 1-degree increments.
// At each step, it tracks the electrical power generation via the INA219. By
// comparing electrical power against the raw wind energy hitting the rotor, it
// calculates the total performance efficiency. At the end of the sweep, it displays
// the exact pitch angle that yielded the highest performance coefficient (Cp).
//
// HOW TO RUN:
// 1. Turn on the wind tunnel to a steady state test velocity.
// 2. Open the Serial Monitor set to 250000 baud with "No Line Ending".
// 3. Pass the mandatory input validation step to run the automated sweep.
//
// Note: The Variable Load bank is needed
//
// ==================================================================================

// ==================================================================================
// AUTOMATED PITCH TUNING & OPTIMAL Cp DISCOVERY
// Updated for:
// - Physical switches -> load banks ON immediately
// - BETA_LPF filtered pitch feedback
// - PGEN_LPF filtered power measurement
// - D8 anemometer input
// ==================================================================================

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_INA219.h>
#include <TLx493D_inc.hpp>
#include <PinChangeInterrupt.h>

using namespace ifx::tlx493d;

// ============================================================
// PIN DEFINITIONS
// ============================================================

#define ANEMOMETER_PIN 8
#define UNUSED_HS_S_PIN 9 // Pin 9 is wired to HS_S on PCB and shares Port B PCINT with Pin 8

#define TLV0_PWR 12
#define TLV1_PWR 10

#define M1_SLEEP 7
#define M1_EN1   6
#define M1_EN0   5

// 74HC165 switch input register
#define HC165_LOAD_PIN   15
#define HC165_CLOCK_PIN  16
#define HC165_DATA_PIN   17

// 74HC595 MOSFET output register
#define HC595_DATA_PIN   11
#define HC595_CLOCK_PIN  13
#define HC595_LATCH_PIN  14

// ============================================================
// SENSOR OBJECTS
// ============================================================

Adafruit_INA219 ina219;
TLx493D_A1B6 mag_collective(Wire, TLx493D_IIC_ADDR_A0_e);

// ============================================================
// CALIBRATION / TUNING VALUES
// ============================================================

// Default safety-band sensor bounds (130° to 210°)
float coll_deg_min = 130.0f; // Mapped to 0.0° pitch
float coll_deg_max = 210.0f; // Mapped to MAX pitch

float ANEMOMETER_SCALE = 1.575226f; // Default updated to your calibrated factor
float PGEN_LPF = 0.15f;

float filteredPower_W = 0.0f;
bool powerInitialized = false;

float coll_motor_drivetime_ms = 120.0f; // Pulses motor in 120ms increments
float windSpeed = 0.0f;

// ============================================================
// PHYSICAL CONSTANTS & DYNAMIC BOUNDS
// ============================================================

const float RHO = 1.225f;
const float ROTOR_AREA = 0.503f;
const float MS_TO_MPH = 2.23694f; // Conversion constant (1 m/s = 2.23694 MPH)

const float PITCH_MIN_DEG = 0.0f;

// Helper function to dynamically derive MAX pitch from active bounds
float get_pitch_max_deg()
{
    return fabs(coll_deg_max - coll_deg_min);
}

// ============================================================
// ANEMOMETER VARIABLES
// ============================================================

volatile unsigned long pulseCount = 0;
volatile unsigned long firstPulseTime = 0;
volatile unsigned long lastPulseTime = 0;

// ============================================================
// LOAD BANK VARIABLES
// ============================================================

byte lastSwitchState = 255;
byte outputState = 0;

// ============================================================
// FUNCTION DECLARATIONS
// ============================================================

float getFloatingInput();
void waitForUser();

void anemometer_int();
float get_wind_vel();

float get_raw_angle_deg(TLx493D_A1B6 &MagSensor, float &outY, float &outX);
float get_collective_percent(float current_sensor_deg);
float get_current_pitch_deg(float current_sensor_deg);

void drive_motor(int pin_en0, int pin_en1, int pin_sleep, bool reverse, int time_ms);
void commandPitchToTarget(float targetPitchDeg);

byte readSwitches();
byte convertStateTo595(byte switchState);
void writeOutputs(byte state);
void mirrorSwitchesToLoadBanks();

float readFilteredPower_W();

// ============================================================
// ROBUST SERIAL INPUT READER
// ============================================================

float getFloatingInput()
{
    while (Serial.available() > 0) Serial.read();

    String inputString = "";

    while (true)
    {
        mirrorSwitchesToLoadBanks(); // Keep load banks responsive while waiting

        if (Serial.available() > 0)
        {
            char c = Serial.read();

            if (c == '\n' || c == '\r')
            {
                inputString.trim();
                if (inputString.length() > 0)
                {
                    return inputString.toFloat();
                }
            }
            else
            {
                inputString += c;
            }
        }
        delay(10);
    }
}

void waitForUser()
{
    Serial.println(F(">>> Type 'Y' and press Send to continue..."));

    while (true)
    {
        mirrorSwitchesToLoadBanks();

        if (Serial.available() > 0)
        {
            char ch = Serial.read();

            if (ch == 'Y' || ch == 'y')
            {
                delay(10);
                while (Serial.available() > 0) Serial.read();
                break;
            }
        }
        delay(20);
    }
}

// ============================================================
// ANEMOMETER ISR + WIND SPEED
// ============================================================

void anemometer_int()
{
    unsigned long now = micros();

    if (pulseCount == 0)
    {
        firstPulseTime = now;
    }

    lastPulseTime = now;
    pulseCount++;
}

float get_wind_vel()
{
    noInterrupts();
    unsigned long pulses = pulseCount;
    unsigned long first = firstPulseTime;
    unsigned long last = lastPulseTime;
    interrupts();

    if (pulses < 2) return 0.0f;

    float elapsed_s = (last - first) / 1000000.0f;
    if (elapsed_s <= 0.0f) return 0.0f;

    float rps = (float)(pulses - 1) / elapsed_s;
    return rps * ANEMOMETER_SCALE;
}

// ============================================================
// LOAD BANK SWITCH MIRRORING
// ============================================================

byte readSwitches()
{
    byte raw = 0;

    digitalWrite(HC165_LOAD_PIN, LOW);
    delayMicroseconds(5);
    digitalWrite(HC165_LOAD_PIN, HIGH);
    delayMicroseconds(5);

    for (int i = 0; i < 8; i++)
    {
        raw <<= 1;
        if (digitalRead(HC165_DATA_PIN)) raw |= 1;

        digitalWrite(HC165_CLOCK_PIN, HIGH);
        delayMicroseconds(5);
        digitalWrite(HC165_CLOCK_PIN, LOW);
        delayMicroseconds(5);
    }

    byte switches = 0;
    for (int bank = 0; bank < 6; bank++)
    {
        if (bitRead(raw, bank)) bitSet(switches, bank);
    }

    return switches;
}

byte convertStateTo595(byte switchState)
{
    byte out = 0;
    for (int bank = 0; bank < 6; bank++)
    {
        if (bitRead(switchState, bank)) bitSet(out, bank + 1);
    }
    return out;
}

void writeOutputs(byte state)
{
    digitalWrite(HC595_LATCH_PIN, LOW);
    shiftOut(HC595_DATA_PIN, HC595_CLOCK_PIN, MSBFIRST, state);
    digitalWrite(HC595_LATCH_PIN, HIGH);
}

void mirrorSwitchesToLoadBanks()
{
    byte switchState = readSwitches();

    if (switchState != lastSwitchState)
    {
        lastSwitchState = switchState;
        outputState = convertStateTo595(switchState);
        writeOutputs(outputState);

        Serial.println();
        Serial.println(F("------------------------------------"));
        Serial.println(F("LOAD BANK SWITCH CHANGE DETECTED"));
        Serial.print(F("Switch Byte: "));
        Serial.println(switchState, BIN);
        Serial.print(F("595 Output : "));
        Serial.println(outputState, BIN);
        Serial.println(F("------------------------------------"));
    }
}

// ============================================================
// 2D ANGULAR TRACKING & PITCH CALCULATIONS
// ============================================================

float get_raw_angle_deg(TLx493D_A1B6 &MagSensor, float &outY, float &outX)
{
    double xmag = 0.0, ymag = 0.0, zmag = 0.0;
    MagSensor.getMagneticField(&xmag, &ymag, &zmag);
    outX = (float)xmag;
    outY = (float)ymag;

    float rad = atan2(outY, outX);
    float deg = rad * (180.0f / 3.14159265f);
    if (deg < 0.0f) deg += 360.0f;
    return deg;
}

float get_collective_percent(float current_sensor_deg)
{
    float deg_delta = coll_deg_max - coll_deg_min;
    if (fabs(deg_delta) < 0.01f) return 0.0f;

    float raw_percent = (current_sensor_deg - coll_deg_min) / deg_delta;
    return constrain(raw_percent, 0.0f, 1.0f);
}

float get_current_pitch_deg(float current_sensor_deg)
{
    float col_pct = get_collective_percent(current_sensor_deg);
    float pitch_max = get_pitch_max_deg();
    return PITCH_MIN_DEG + col_pct * (pitch_max - PITCH_MIN_DEG);
}

void drive_motor(int pin_en0, int pin_en1, int pin_sleep, bool reverse, int time_ms)
{
    digitalWrite(pin_sleep, HIGH);

    if (reverse)
    {
        digitalWrite(pin_en0, HIGH);
        digitalWrite(pin_en1, LOW);
    }
    else
    {
        digitalWrite(pin_en0, LOW);
        digitalWrite(pin_en1, HIGH);
    }

    delay(time_ms);

    digitalWrite(pin_sleep, LOW);
    digitalWrite(pin_en0, LOW);
    digitalWrite(pin_en1, LOW);
}

// ============================================================
// MOTOR POSITION CONTROL WITH BOUND CHECKING
// ============================================================

void commandPitchToTarget(float targetPitchDeg)
{
    float pitch_max = get_pitch_max_deg();

    float target_pct = (targetPitchDeg - PITCH_MIN_DEG) / (pitch_max - PITCH_MIN_DEG);
    target_pct = constrain(target_pct, 0.0f, 1.0f);

    const float TOLERANCE_PCT = 0.03f; // ~3% position window

    while (true)
    {
        mirrorSwitchesToLoadBanks();

        float outY = 0.0f, outX = 0.0f;
        float current_sensor_deg = get_raw_angle_deg(mag_collective, outY, outX);
        float current_pct        = get_collective_percent(current_sensor_deg);

        float error_pct = target_pct - current_pct;

        if (fabs(error_pct) <= TOLERANCE_PCT)
        {
            break;
        }

        bool reverse_drive = false;
        if (coll_deg_max > coll_deg_min)
        {
            reverse_drive = (error_pct < 0.0f); 
        }
        else
        {
            reverse_drive = (error_pct > 0.0f);
        }

        if (error_pct > 0.0f && current_pct >= 1.0f)
        {
            Serial.println(F("[SAFETY HALT] Reached 100% Upper Limit!"));
            break;
        }
        if (error_pct < 0.0f && current_pct <= 0.0f)
        {
            Serial.println(F("[SAFETY HALT] Reached 0% Lower Limit!"));
            break;
        }

        drive_motor(M1_EN0, M1_EN1, M1_SLEEP, reverse_drive, coll_motor_drivetime_ms);
        delay(30);
    }
}

// ============================================================
// POWER MEASUREMENT
// ============================================================

float readFilteredPower_W()
{
    mirrorSwitchesToLoadBanks();

    float voltage = ina219.getBusVoltage_V();
    float current_A = ina219.getCurrent_mA() / 1000.0f;
    float rawPower = voltage * current_A;

    if (!powerInitialized)
    {
        filteredPower_W = rawPower;
        powerInitialized = true;
    }

    filteredPower_W += PGEN_LPF * (rawPower - filteredPower_W);
    return filteredPower_W;
}

// ============================================================
// SETUP
// ============================================================

void setup()
{
    Serial.begin(250000);
    while (!Serial) delay(10);

    // Explicitly configure ANEMOMETER_PIN with INPUT
    pinMode(ANEMOMETER_PIN, INPUT);

    // Ensure Pin 9 (HS_S) PCINT interrupt vector is disabled
    pinMode(UNUSED_HS_S_PIN, INPUT);
    disablePCINT(digitalPinToPCINT(UNUSED_HS_S_PIN));

    attachPCINT(
        digitalPinToPCINT(ANEMOMETER_PIN),
        anemometer_int,
        FALLING
    );

    // Pitch Motor Control Pins
    pinMode(M1_EN0, OUTPUT);
    pinMode(M1_EN1, OUTPUT);
    pinMode(M1_SLEEP, OUTPUT);

    digitalWrite(M1_EN0, LOW);
    digitalWrite(M1_EN1, LOW);
    digitalWrite(M1_SLEEP, LOW);

    // Shift Register Pins
    pinMode(HC165_LOAD_PIN, OUTPUT);
    pinMode(HC165_CLOCK_PIN, OUTPUT);
    pinMode(HC165_DATA_PIN, INPUT);

    digitalWrite(HC165_LOAD_PIN, HIGH);
    digitalWrite(HC165_CLOCK_PIN, LOW);

    pinMode(HC595_DATA_PIN, OUTPUT);
    pinMode(HC595_CLOCK_PIN, OUTPUT);
    pinMode(HC595_LATCH_PIN, OUTPUT);

    writeOutputs(0);

    // TLV Sensor Power Management Pins
    pinMode(SDA, OUTPUT);
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(500);

    digitalWrite(SDA, LOW);
    delay(50);
    digitalWrite(TLV0_PWR, HIGH);
    delay(250);

    pinMode(SDA, INPUT);
    delay(50);
    digitalWrite(TLV1_PWR, HIGH);
    delay(250);

    Wire.begin();
    Wire.setClock(100000);

    if (!mag_collective.begin())
    {
        Serial.println(F("CRITICAL ERROR: TLV1 Collective Sensor failed to initialize!"));
        while (true) delay(100);
    }

    if (!ina219.begin())
    {
        Serial.println(F("ERROR: INA219 power sensor missing!"));
        while (true) delay(100);
    }

    Serial.println(F("=================================================="));
    Serial.println(F(" AUTOMATED WIND TURBINE PITCH SWEEP (Cp TEST)     "));
    Serial.println(F("=================================================="));

    Serial.println(F("\nEnter calibrated ANEMOMETER_SCALE:"));
    ANEMOMETER_SCALE = getFloatingInput();
    Serial.print(F("-> ANEMOMETER_SCALE = ")); Serial.println(ANEMOMETER_SCALE, 4);

    Serial.println(F("\nEnter tuned PGEN_LPF:"));
    PGEN_LPF = getFloatingInput();
    Serial.print(F("-> PGEN_LPF = ")); Serial.println(PGEN_LPF, 3);

    Serial.println(F("\nEnter coll_deg_min (Sensor Angle in deg at 0 pitch):"));
    coll_deg_min = getFloatingInput();
    Serial.print(F("-> Received coll_deg_min = ")); Serial.println(coll_deg_min, 2);

    Serial.println(F("\nEnter coll_deg_max (Sensor Angle in deg at MAX pitch):"));
    coll_deg_max = getFloatingInput();
    Serial.print(F("-> Received coll_deg_max = ")); Serial.println(coll_deg_max, 2);

    // Physical bound validation
    if (fabs(coll_deg_max - coll_deg_min) < 1.0f)
    {
        Serial.println(F("\n[WARNING] Bounds too close! Reverting to safety defaults (130.0, 210.0)."));
        coll_deg_min = 130.0f;
        coll_deg_max = 210.0f;
    }

    float pitch_max = get_pitch_max_deg();

    Serial.println();
    Serial.print(F("-> ACTIVE coll_deg_min (0.0 deg pitch)  = ")); Serial.print(coll_deg_min, 2); Serial.println(F(" deg"));
    Serial.print(F("-> ACTIVE coll_deg_max (")); Serial.print(pitch_max, 1); Serial.print(F(" deg pitch) = ")); Serial.print(coll_deg_max, 2); Serial.println(F(" deg"));

    Serial.println(F("\nTurn on wind tunnel and set desired load-bank switches."));
    waitForUser();

    // ============================================================
    // CLEAN 10-SECOND WIND SPEED SAMPLING FIX (m/s & MPH)
    // ============================================================
    noInterrupts();
    pulseCount = 0;
    firstPulseTime = 0;
    lastPulseTime = 0;
    interrupts();

    Serial.println(F("\nSampling wind speed for 10 seconds..."));

    // Quiet delay to prevent shift register toggling noise during pulse counting
    delay(10000);

    // Calculate wind speed ONCE over the exact 10-second pulse window
    windSpeed = get_wind_vel(); // In m/s
    if (windSpeed < 0.1f) windSpeed = 0.1f;

    float windSpeedMPH = windSpeed * MS_TO_MPH; // Convert to MPH

    Serial.println(F("\n>>> WIND SPEED LOCKED <<<"));
    Serial.print(F("Steady Wind Speed: "));
    Serial.print(windSpeed, 2);
    Serial.print(F(" m/s ("));
    Serial.print(windSpeedMPH, 2);
    Serial.println(F(" MPH)"));

    Serial.println(F("\nReady to start sweep."));
    waitForUser();

    // ============================================================
    // AUTOMATED SWEEP LOOP
    // ============================================================

    float bestAngle = -1.0f;
    float maxEfficiency = -1.0f;

    float P_wind = 0.5f * RHO * ROTOR_AREA * windSpeed * windSpeed * windSpeed;

    Serial.println(F("\n=================================================="));
    Serial.println(F("            BEGINNING PITCH SWEEP                 "));
    Serial.println(F("=================================================="));

    for (int currentAngle = (int)PITCH_MIN_DEG; currentAngle <= (int)pitch_max; currentAngle++)
    {
        mirrorSwitchesToLoadBanks();

        Serial.print(F("\nSweeping Step: Moving to "));
        Serial.print(currentAngle);
        Serial.println(F(" degrees..."));

        commandPitchToTarget((float)currentAngle);

        // 1. SETTLING PHASE: 3s delay while keeping load bank switches responsive
        unsigned long settleStart = millis();
        while (millis() - settleStart < 3000)
        {
            mirrorSwitchesToLoadBanks();
            delay(20);
        }

        // 2. SAMPLING PHASE: Take 50 samples (2 seconds) to average out cogging ripple
        const int NUM_POWER_SAMPLES = 50;
        float totalPower = 0.0f;

        for (int i = 0; i < NUM_POWER_SAMPLES; i++)
        {
            mirrorSwitchesToLoadBanks();
            totalPower += readFilteredPower_W();
            delay(40); // 50 * 40ms = 2000ms
        }

        float avgPgen = totalPower / (float)NUM_POWER_SAMPLES;
        float currentEff = avgPgen / P_wind;

        Serial.print(F("Measured Power: "));
        Serial.print(avgPgen, 4);
        Serial.print(F(" W | Combined Eff: "));
        Serial.print(currentEff * 100.0f, 4); // 4 decimal places for fine efficiency values
        Serial.println(F("%"));

        if (currentEff > maxEfficiency)
        {
            maxEfficiency = currentEff;
            bestAngle = (float)currentAngle;
        }
    }

    // ============================================================
    // RESULTS
    // ============================================================

    Serial.println(F("\n=================================================="));
    Serial.println(F("              SWEEP COMPLETED                     "));
    Serial.println(F("=================================================="));

    Serial.print(F("OPTIMAL EXPERIMENTAL PITCH ANGLE: "));
    Serial.print(bestAngle, 1);
    Serial.println(F(" degrees"));

    Serial.print(F("MAXIMUM COMBINED EFFICIENCY: "));
    Serial.print(maxEfficiency * 100.0f, 4);
    Serial.println(F("%"));

    Serial.print(F("Estimated Cp: "));
    Serial.println(maxEfficiency, 4);
    Serial.println(F("=================================================="));
}

// ============================================================
// LOOP
// ============================================================

void loop()
{
    mirrorSwitchesToLoadBanks();
    delay(20);
}