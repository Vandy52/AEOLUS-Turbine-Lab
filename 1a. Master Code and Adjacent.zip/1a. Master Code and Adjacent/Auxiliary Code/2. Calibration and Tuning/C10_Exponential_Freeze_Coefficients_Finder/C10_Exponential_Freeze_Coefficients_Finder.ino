// Calibration tool for finding Exponential Freeze Coefficients

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_INA219.h>
#include <PinChangeInterrupt.h>

// -----------------------------
// PIN DEFINITIONS (Synchronized)
// -----------------------------
#define ANEMOMETER_PIN   8    // HS_N (Port B PinChange Interrupt)
#define UNUSED_HS_S_PIN  9    // HS_S - Disabled to avoid interrupt conflicts

// 74HC595 Shift Register Pins
#define HC595_DATA_PIN   11   // SER
#define HC595_CLOCK_PIN  13   // SRCLK
#define HC595_LATCH_PIN  14   // RCLK (A0)

// -----------------------------
// GLOBAL CALIBRATION & CONSTANTS
// -----------------------------
float ANEMOMETER_SCALE = 1.575226f; // Standard system factor
float TUNED_CP = 0.0f;

Adafruit_INA219 ina219;

// Anemometer ISR Variables
volatile unsigned long pulseCount = 0;
volatile unsigned long firstPulseTime = 0;
volatile unsigned long lastPulseTime = 0;

// ============================================================
// HELPER FUNCTIONS
// ============================================================

void writeOutputs(byte state) {
    digitalWrite(HC595_LATCH_PIN, LOW);
    shiftOut(HC595_DATA_PIN, HC595_CLOCK_PIN, MSBFIRST, state);
    digitalWrite(HC595_LATCH_PIN, HIGH);
}

void anemometer_int() {
    unsigned long now = micros();
    if (pulseCount == 0) {
        firstPulseTime = now;
    }
    lastPulseTime = now;
    pulseCount++;
}

float readWind() {
    noInterrupts();
    unsigned long pulses = pulseCount;
    unsigned long first = firstPulseTime;
    unsigned long last = lastPulseTime;
    interrupts();

    if (pulses < 2) return 0.0f;

    float elapsed_s = (last - first) / 1000000.0f;
    if (elapsed_s <= 0.0f) return 0.0f;

    float rps = (float)(pulses - 1) / elapsed_s;
    return rps * ANEMOMETER_SCALE;
}

void resetAnemometer() {
    noInterrupts();
    pulseCount = 0;
    firstPulseTime = 0;
    lastPulseTime = 0;
    interrupts();
}

float getFloatingInput() {
    while (Serial.available()) Serial.read(); // Clean buffer
    while (!Serial.available()) {
        delay(10);
    }
    float val = Serial.parseFloat();
    while (Serial.available()) Serial.read(); // Clean trailing bytes
    return val;
}

void waitUser() {
    while (Serial.available()) Serial.read();
    while (true) {
        if (Serial.available()) {
            char c = Serial.read();
            if (c == 'Y' || c == 'y') break;
        }
        delay(50);
    }
}

float measureSettlingTime(byte initialOutput, byte targetOutput) {
    writeOutputs(initialOutput);
    delay(3000); // Steady state stabilization

    float v_start = ina219.getBusVoltage_V();
    unsigned long start_t = millis();

    writeOutputs(targetOutput); // Fire step transient load
    delay(40);                  // Filter transient contact noise

    float v_min = v_start;
    unsigned long min_time = millis();

    unsigned long window = millis();
    while (millis() - window < 4000) {
        float v = ina219.getBusVoltage_V();
        if (v < v_min) {
            v_min = v;
            min_time = millis();
        }
        delay(5);
    }

    writeOutputs(initialOutput); // Reset load bank

    float tau = (float)(min_time - start_t) / 1000.0f;
    return tau * 4.0f; // Settle criterion = 4 * Tau
}

// ============================================================
// SETUP
// ============================================================

void setup() {
    Serial.begin(250000);
    while (!Serial);

    // Pin Configurations
    pinMode(HC595_CLOCK_PIN, OUTPUT);
    pinMode(HC595_LATCH_PIN, OUTPUT);
    pinMode(HC595_DATA_PIN, OUTPUT);
    writeOutputs(0);

    // Anemometer Interrupt Configuration
    pinMode(ANEMOMETER_PIN, INPUT);
    pinMode(UNUSED_HS_S_PIN, INPUT);
    disablePCINT(digitalPinToPCINT(UNUSED_HS_S_PIN));
    attachPCINT(digitalPinToPCINT(ANEMOMETER_PIN), anemometer_int, FALLING);

    Wire.begin();
    if (!ina219.begin()) {
        Serial.println(F("ERROR: INA219 sensor not detected on I2C bus!"));
        while (true) delay(100);
    }

    Serial.println(F("\nMANDATORY INPUT REQUIRED FOR CALIBRATION:"));
    Serial.println(F("What is your discovered Tuned_CP value? (e.g., 0.28):"));
    TUNED_CP = getFloatingInput();
    Serial.print(F("-> Tuned_CP set to: ")); 
    Serial.println(TUNED_CP, 4);

    Serial.println(F("Enter calibrated ANEMOMETER_SCALE (default: 1.5752):"));
    ANEMOMETER_SCALE = getFloatingInput();
    if (ANEMOMETER_SCALE <= 0.0f) ANEMOMETER_SCALE = 1.575226f;
    Serial.print(F("-> ANEMOMETER_SCALE set to: ")); 
    Serial.println(ANEMOMETER_SCALE, 4);
}

// ============================================================
// LOOP
// ============================================================

void loop() {
    Serial.println(F("\n============================================="));
    Serial.println(F("     SMART WIND TURBINE CALIBRATION WIZARD   "));
    Serial.println(F("============================================="));

    // STEP 1: LOW SPEED baseline
    Serial.println(F("\n[STEP 1] Set wind tunnel to LOW speed (~2-3 m/s)."));
    Serial.println(F("Type 'Y' and press send when speed is stabilized..."));
    waitUser();

    resetAnemometer();
    delay(3000); // 3-second pulse sampling window
    float low_wind = readWind();

    Serial.print(F("Captured Wind Speed: ")); 
    Serial.print(low_wind, 2); 
    Serial.println(F(" m/s. Measuring 1-bank step drop..."));

    float t_low_1bank = measureSettlingTime(0, 0x02);
    Serial.print(F("Resulting Settle Duration: ")); 
    Serial.print(t_low_1bank, 2); 
    Serial.println(F(" seconds."));

    // STEP 2: HIGH SPEED scaling
    Serial.println(F("\n[STEP 2] Set wind tunnel to HIGH speed (~8-10 m/s)."));
    Serial.println(F("Type 'Y' and press send when speed is stabilized..."));
    waitUser();

    resetAnemometer();
    delay(3000);
    float high_wind = readWind();

    Serial.print(F("Captured Wind Speed: ")); 
    Serial.print(high_wind, 2); 
    Serial.println(F(" m/s. Measuring 1-bank step drop..."));

    float t_high_1bank = measureSettlingTime(0, 0x02);
    Serial.print(F("Resulting Settle Duration: ")); 
    Serial.print(t_high_1bank, 2); 
    Serial.println(F(" seconds."));

    // STEP 3: Heavy Load Multiplier Tracking
    Serial.println(F("\n[STEP 3] Keep wind tunnel at HIGH speed."));
    Serial.println(F("Measuring impact of turning ON all 6 load banks."));
    Serial.println(F("Type 'Y' and press send to execute..."));
    waitUser();

    float t_high_6bank = measureSettlingTime(0, 0x7E);
    Serial.print(F("6-Bank Settle Duration: ")); 
    Serial.print(t_high_6bank, 2); 
    Serial.println(F(" seconds."));

    // MATHEMATICAL COEFFICIENT CALCULATION
    if (fabs(high_wind - low_wind) < 0.1f) {
        Serial.println(F("\nERROR: Wind speeds between low and high tests are too close."));
        Serial.println(F("Rerun test with a larger speed differential."));
        return;
    }

    if (t_high_1bank <= 0.0001f || t_low_1bank <= 0.0001f) {
        Serial.println(F("\nERROR: Settling time measurement fault. Cannot calculate log."));
        return;
    }

    float decay_factor = (log(t_low_1bank) - log(t_high_1bank)) / (high_wind - low_wind);
    float max_freeze_ms = (t_low_1bank / expf(-decay_factor * low_wind)) * 1000.0f;

    float percentage_increase = (t_high_6bank - t_high_1bank) / t_high_1bank;
    float load_bank_mult = percentage_increase / 6.0f;

    // DISPLAY COMPREHENSIVE RESULTS
    Serial.println(F("\n============================================="));
    Serial.println(F("         CALIBRATION RESULTS COMPLETED       "));
    Serial.println(F("============================================="));
    Serial.println(F("Copy these values into your Master Code:\n"));

    Serial.print(F("const float MAX_FREEZE_TIME_MS   = ")); 
    Serial.print(max_freeze_ms, 1); 
    Serial.println(F(".0f;"));

    Serial.print(F("const float WIND_DECAY_FACTOR    = ")); 
    Serial.print(decay_factor, 4); 
    Serial.println(F("f;"));

    Serial.print(F("const float LOAD_BANK_MULTIPLIER = ")); 
    Serial.print(load_bank_mult, 4); 
    Serial.println(F("f;"));
    Serial.println(F("============================================="));

    Serial.println(F("\nTo re-run calibration wizard, type 'Y'..."));
    waitUser();
}