%% SYSTEM IDENTIFICATION MATLAB CODE

% Load datasets
servo_data = readmatrix('pitch_servo_data.csv');
turbine_data = readmatrix('turbine_plant_data.csv');

% Extract arrays (Scaling timestamp column to seconds)
t_servo = servo_data(:,1) / 1000;
u_servo = servo_data(:,2); % Motor_Command (-1, 0, 1)
y_servo = servo_data(:,3); % Pitch_Degrees

t_turbine = turbine_data(:,1) / 1000;
u_turbine = turbine_data(:,2); % Pitch_Degrees
y_turbine = turbine_data(:,3); % Pgen_W

%{
=========================================================
How to achieve system identification 
=========================================================

1. In the "Command Window" copy paste the following line of code: systemIdentification

2. Press Enter and the "System Identification" configuration window will appear

3. In the top left of the "System Identification" configuration window, select the "Import data" drop-down arrow and select "Time domain data"

4. For the Pitch Servo transfer function calculation under the "Workspace Variable" header set the "Input" to "u_servo" and "Output" to "y_servo"

5. Under the "Data Information" header change "Data Name" to "servo_id", set the "Start Time" to "0" and "Sample Time" to "0.01"

6. Click "Import" and then click "Close"

7. "servo_id" should show up in the position [1, 1] in the left 4 x 2 matrix

8. Repeat steps 3 - 6 again but change "Input" to "u_turbine", "Output" to "y_turbine", "Data Name" to "turbine_id", "Start Time" to "0" and "Sample Time" to "0.05"

9. "turbine_id" should show up in the position [1, 2] in the left 4 x 2 matrix

10. Under the down arrow in the middle of the window, select the "Estimate -->" drop-down arrow and select "Transfer Function Models..." 

11. In the "Estimate Transfer Functions" window that appears, change "Model name" to "servo_tf", set "Number of poles" to 1 and "Number of zeros" to 0

12. Select "Estimate" and a window titled "Identification Process" will appear

13. In the "Simulated Response Comparison" graph, note the fit percentage shown to the right of the signal "model" in the upper-right corner.

14. If the fit percentage is above 80%, proceed to Step 17

15. If the fit percentage is below 80%, click "Close" under the graph and repeat Steps 10 - 13 with Number of poles" set to 2 and "Number of zeros" set to 0

16. The fit percentage should now improve and ideally exceed 80%

17. Click "Close" under the graph and click "Close" in the bottom right of the "Estimate Transfer Functions" window

18. Double click on the box titled "servo_tf" in the position [1, 1] in the right 4 x 4 matrix 

19. In the "Data/model Info" window that appears, note the transfer function in the top black box then click "Export" at the bottom of the window

20. Copy and paste the following code into MATLAB's command window and press "Enter"

    [num, den] = tfdata(servo_tf,'v');
    num = num(find(num,1):end);

    fprintf('Numerator:   [%g]\n', num);
    fprintf('Denominator: [%g %g]\n', den(1), den(2));

21. Go to the "AEOLUS_Pitch_Control_SIMULATION" Simulink block diagram and double click on the "Pitch Servo" transfer function block

22. Copy what the "Commmand Window" has for "Numerator" into "Numerator coefficients" under the "Parameters" header in the "Block Parameters" window 

23. Copy what the "Commmand Window" has for "Denominator" into "Denominator coefficients" under the "Parameters" header in the "Block Parameters" window

24. Hit "Enter" and resize the "Pitch Servo" transfer function block if desired

25. Drag the "turbine_id" block from the position [1, 2] in the left 4 x 2 matrix into the "Working Data" box where "servo_id" currently is

26. Repeat steps 10 - 25 but change the "Model name" to "turbine_tf" (Step 11), double click on the box titled "turbine_tf" in the position [1, 2] in the 
    right 4 x 4 matrix (Step 18), use the code below for Step 20 and double click on the "Wind Turbine" transfer function block (Step 21)

    [num, den] = tfdata(turbine_tf,'v');
    num = num(find(num,1):end);

    fprintf('Numerator:   [%g]\n', num);
    fprintf('Denominator: [%g %g]\n', den(1), den(2));

27. Copy and paste the following code into the "Command Window" to verify that the selected AEOLUS sample time of 0.02 s is acceptable (Recommended Ts <= 0.02 s)

    % Servo
    [num_s, den_s] = tfdata(servo_tf,'v');
    tau_servo = den_s(1)/den_s(2);
    
    % Turbine
    [num_t, den_t] = tfdata(turbine_tf,'v');
    tau_turbine = den_t(1)/den_t(2);
    
    fprintf('tau_servo   = %.4f s\n', tau_servo);
    fprintf('tau_turbine = %.4f s\n', tau_turbine);

    tau_min = min(tau_servo, tau_turbine);

    % Recommended controller sample time
    Ts = tau_min/10;

    fprintf('Recommended Ts = %.4f s\n', Ts);

28. Proceed to the use these transfer functions in the "AEOLUS_Pitch_Control" control system and "AEOLUS_Pitch_Control_SIMULATION" control system

%}

