/* ============================================================================
   SYSTEM IDENTIFICATION - ISOLATED WIND TURBINE PLANT
   ============================================================================
   OBJECTIVE: Find the transfer function matching: Blade Angle -> Generated Power
   HARDWARE SETUP:
   1. Complete system fully assembled (INA219 power sensor active).
   2. Wind tunnel/fan turned ON and blown at a constant steady-state velocity.
   
   HOW TO RUN THIS EXPERIMENT:
   1. Upload this code to the Arduino and open the Serial Monitor at 250000 baud.

   2. The code will position the blades to pre-programmed angles automatically, 
      holding each stage to let the turbine output power stabilize.

   3. When "EXPERIMENT_COMPLETE" prints, copy all rows between data markers.

   4. Paste into a text file and save it as "turbine_plant_data.csv".
   ============================================================================
   To save the data into a .csv file follow the instructions below:
   1. Copy the data and headers into a notepad file - example below:
      Timestamp_ms,Pitch_Degrees,Pgen_W
      0,0.0000,0.0000
      50,0.0000,0.0120
      ...

   2. Save this file as turbine_plant_data in the same file as the TEST_2_ISOLATED_WIND_TURBINE_PLAN folder

   3. Go into the now shared folder in File Explorer and go under View -> Show -> File name extensions

   4. Right click on your turbine_plant_data.txt and click rename

   5. Delete .txt and replace it with .csv
   ============================================================================ */

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp> // Modern Infineon Library
#include <Adafruit_INA219.h>

using namespace ifx::tlx493d;

#define M1_SLEEP 7
#define M1_EN1 6
#define M1_EN0 5
#define TLV0_PWR 12 // D12 → Power for Wind Vane 3D Sensor
#define TLV1_PWR 10 // D10 → Power for Collective Pitch 3D Sensor

float coll_deg_min = 0.0f;
float coll_deg_max = 0.0f;
float BETA_LPF = 0.12f;
float filtered_beta = 0.0f;
bool betaInitialized = false;

TLx493D_A1B6 mag_collective(Wire, TLx493D_IIC_ADDR_A0_e);
Adafruit_INA219 ina219;

unsigned long experimentStartMs;
const unsigned long STAGE_DURATION = 4000; // Hold each step for 4 seconds
float target_pitch_percent = 0.0f;

void position_blades_to(float target_pct);
float get_collective_percent(TLx493D_A1B6 &);
float getFloatingInput();

void setup() {
    Serial.begin(250000);
    while (!Serial) {
        delay(10);
    }

    pinMode(M1_EN0, OUTPUT);
    pinMode(M1_EN1, OUTPUT);
    pinMode(M1_SLEEP, OUTPUT);
    
    pinMode(SDA, OUTPUT);
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(100);

    // ========================================================================
    // MANDATORY ENTRANCE GATE: REQUIRE PREVIOUS DATA SEEDS BEFORE RUNNING
    // ========================================================================
    Serial.println(F("\n===================================================="));
    Serial.println(F("MANDATORY INPUT REQUIRED FOR TEST PROCEEDING:"));
    
    Serial.println(F("\nEnter your calibrated coll_deg_min (e.g. -5.0):"));
    coll_deg_min = getFloatingInput();
    
    Serial.println(F("Enter your calibrated coll_deg_max (e.g. -33.0):"));
    coll_deg_max = getFloatingInput();
    
    Serial.println(F("\nEnter your tuned BETA_LPF value (e.g. 0.12):"));
    BETA_LPF = getFloatingInput();
        
    Serial.println(F("All calibration tracking constants verified. Test starting..."));
    Serial.println(F("====================================================\n"));

    uint16_t stabilize_ms = 20;

    digitalWrite(SDA, LOW);
    delay(stabilize_ms);
    digitalWrite(TLV0_PWR, HIGH);
    delay(stabilize_ms);

    digitalWrite(SDA, HIGH);
    delay(stabilize_ms);
    digitalWrite(TLV1_PWR, HIGH);
    delay(stabilize_ms);

    Wire.begin();
    Wire.setClock(1000000);

    if (!mag_collective.begin()) {
        Serial.println(F("CRITICAL ERROR: TLV1 Collective Sensor failed to initialize!"));
        while (true);
    }

    if (!ina219.begin()) {
        Serial.println(F("CRITICAL ERROR: INA219 sensor missing!"));
        while (true) { delay(10); }
    }
    
    delay(500);

    Serial.println("--- START OF TURBINE DATA ---");
    Serial.println("Timestamp_ms,Beta_Percent,Pgen_W");
    experimentStartMs = millis();
}

void loop() {
    unsigned long currentMs = millis();
    unsigned long elapsedMs = currentMs - experimentStartMs;

    // AUTOMATED STEP GENERATION FOR APPLIED PITCH PERCENTAGES
    if (elapsedMs < STAGE_DURATION) {
        target_pitch_percent = 0.00f; // Stage 1: Flat pitch (0%)
    } else if (elapsedMs >= STAGE_DURATION && elapsedMs < (STAGE_DURATION * 2)) {
        target_pitch_percent = 0.30f; // Stage 2: Medium Pitch step (30%)
    } else if (elapsedMs >= (STAGE_DURATION * 2) && elapsedMs < (STAGE_DURATION * 3)) {
        target_pitch_percent = 0.60f; // Stage 3: High Pitch step (60%)
    } else {
        digitalWrite(M1_SLEEP, LOW);
        Serial.println("--- EXPERIMENT_COMPLETE ---");
        while (true) {
            delay(1000);
        }
    }

    position_blades_to(target_pitch_percent);
    float actual_pitch = get_collective_percent(mag_collective);

    const int NUM_POWER_SAMPLES = 10;
    float powerSum = 0.0f;

    for (int i = 0; i < NUM_POWER_SAMPLES; i++) {
        float voltage = ina219.getBusVoltage_V();
        float current = ina219.getCurrent_mA() / 1000.0f;
        powerSum += voltage * current;
        delay(5);
    }

    float Pgen = powerSum / NUM_POWER_SAMPLES;

    Serial.print(elapsedMs);
    Serial.print(",");
    Serial.print(actual_pitch, 4);
    Serial.print(",");
    Serial.println(Pgen, 4);
    
    delay(50);
}

float getFloatingInput() {
    while (!Serial.available()) {
        delay(10);
    }
    float val = Serial.parseFloat();
    while (Serial.available()) {
        Serial.read();
    }
    return val;
}

void position_blades_to(float target_pct) {
    float current_pct = get_collective_percent(mag_collective);
    float error = target_pct - current_pct;
    const float tolerance = 0.02f;

    if (abs(error) > tolerance) {
        digitalWrite(M1_SLEEP, HIGH);
        if (error > 0) {
            digitalWrite(M1_EN0, LOW);
            digitalWrite(M1_EN1, HIGH);
        } else {
            digitalWrite(M1_EN0, HIGH);
            digitalWrite(M1_EN1, LOW);
        }
    } else {
        digitalWrite(M1_EN0, LOW);
        digitalWrite(M1_EN1, LOW);
        digitalWrite(M1_SLEEP, LOW);
    }
}

float get_collective_percent(TLx493D_A1B6 &MagSensor) {
    double xmag = 0.0, ymag = 0.0, zmag = 0.0;

    MagSensor.getMagneticField(&xmag, &ymag, &zmag);

    float raw_beta = (float)ymag;

    if (!betaInitialized) {
        filtered_beta = raw_beta;
        betaInitialized = true;
    }

    filtered_beta += BETA_LPF * (raw_beta - filtered_beta);

    float coll_delta = coll_deg_max - coll_deg_min;

    if (fabs(coll_delta) < 0.01f)
        return 0.0f;

    if (coll_delta < 0) {
        if (filtered_beta <= coll_deg_max) return 1.0f;
        if (filtered_beta >= coll_deg_min) return 0.0f;
    } else {
        if (filtered_beta >= coll_deg_max) return 1.0f;
        if (filtered_beta <= coll_deg_min) return 0.0f;
    }

    return constrain(
        (filtered_beta - coll_deg_min) / coll_delta,
        0.0f,
        1.0f
    );
}
