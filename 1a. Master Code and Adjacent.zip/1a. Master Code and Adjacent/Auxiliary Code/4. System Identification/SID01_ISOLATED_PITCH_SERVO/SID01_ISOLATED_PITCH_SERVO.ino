/* ============================================================================
   SYSTEM IDENTIFICATION - ISOLATED PITCH SERVO
   ============================================================================
   OBJECTIVE: Find the transfer function matching: Motor Command -> Blade Angle
   HARDWARE SETUP:
   1. Connect Arduino GND to external power supply GND (Critical common reference!).
   2. Connect external power supply positive terminal to motor driver power input.
   3. Ensure the 3D Magnetic Sensor (TLV493D) for the collective pitch is wired.
   
   HOW TO RUN THIS EXPERIMENT:
   1. Upload this code to the Arduino and open the Serial Monitor at 250000 baud.

   2. The code will pause and wait for your calibration values via the input bar.

   3. Type your raw min/max sensor boundaries to unlock the test loop.
   ============================================================================
   To save the data into a .csv file follow the instructions below:

   1. Copy the data and headers into a notepad file - example below:
      Timestamp_ms,Motor_Command,Pitch_Degrees
      0,0,0.0000
      20,0,0.0000
      ...

   2. Save this file as pitch_servo_data in the same file as the TEST_1_ISOLATED_PITCH_SERVO folder

   3. Go into the now shared folder in File Explorer and go under View -> Show -> File name extensions

   4. Right click on your pitch_servo_data.txt and click rename

   5. Delete .txt and replace it with .csv
   ============================================================================ */

#include <Arduino.h>
#include <Wire.h>
#include <TLx493D_inc.hpp>

using namespace ifx::tlx493d;

#define M1_SLEEP 7
#define M1_EN1   6
#define M1_EN0   5
#define TLV0_PWR 12 // D12 -> Power for Wind Vane 3D Sensor
#define TLV1_PWR 10 // D10 -> Power for Collective Pitch 3D Sensor

// Calibration Parameters (Degree Limits)
float coll_deg_min = 0.0f;  // Minimum pitch bound (degrees / min sensor boundary)
float coll_deg_max = 15.0f; // Maximum pitch bound (degrees / max sensor boundary)
float BETA_LPF     = 0.12f; // Low-pass filter smoothing coefficient
float filtered_beta = 0.0f;
bool betaInitialized = false;

// Sensor at Address A0 (0x1F)
TLx493D_A1B6 mag_collective(Wire, TLx493D_IIC_ADDR_A0_e);

unsigned long experimentStartMs;
const unsigned long TEST_DURATION_MS = 10000; // 10 seconds total duration
int motorCommand = 0;                         // Motor state (-1, 0, 1)

// Function Declarations
void set_motor_command(int cmd);
void stop_motor();
float get_collective_degrees(TLx493D_A1B6 &MagSensor);
float getFloatingInput();

void setup() {
    Serial.begin(250000);
    while (!Serial) delay(10);

    // Motor Control Pins
    pinMode(M1_EN0, OUTPUT);
    pinMode(M1_EN1, OUTPUT);
    pinMode(M1_SLEEP, OUTPUT);
    stop_motor();

    // Sensor Latching & Power Pins
    pinMode(SDA, OUTPUT);
    pinMode(TLV0_PWR, OUTPUT);
    pinMode(TLV1_PWR, OUTPUT);

    digitalWrite(TLV0_PWR, LOW);
    digitalWrite(TLV1_PWR, LOW);
    delay(100);

    // ========================================================================
    // 1) HARDWARE I2C & ADDRESS LATCHING
    // ========================================================================
    digitalWrite(SDA, LOW);
    delay(20);
    digitalWrite(TLV0_PWR, HIGH); // TLV0 Address: A4 (0x1F)
    delay(20);

    pinMode(SDA, INPUT);          // Release SDA back to I2C controller
    delay(20);
    digitalWrite(TLV1_PWR, HIGH); // TLV1 Address: A0 (0x5E)
    delay(20);

    Wire.begin();
    Wire.setClock(400000);           // Fast I2C Mode (400 kHz)
    Wire.setWireTimeout(3000, true); // I2C Bus Timeout Lockup Protection

    if (!mag_collective.begin()) {
        Serial.println(F("CRITICAL ERROR: TLV1 Collective Sensor failed to initialize!"));
        while (true) delay(100);
    }

    // ========================================================================
    // 2) INTERACTIVE CALIBRATION GATE (coll_deg_min / coll_deg_max)
    // ========================================================================
    Serial.println(F("\n===================================================="));
    Serial.println(F("    SYSTEM IDENTIFICATION: ISOLATED PITCH SERVO    "));
    Serial.println(F("===================================================="));

    Serial.println(F("Enter Minimum Blade Pitch Boundary (coll_deg_min, e.g. 0.0):"));
    coll_deg_min = getFloatingInput();
    Serial.print(F("-> coll_deg_min saved at: "));
    Serial.println(coll_deg_min, 2);

    Serial.println(F("\nEnter Maximum Blade Pitch Boundary (coll_deg_max, e.g. 15.0):"));
    coll_deg_max = getFloatingInput();
    Serial.print(F("-> coll_deg_max saved at: "));
    Serial.println(coll_deg_max, 2);

    Serial.println(F("\nEnter tuned BETA_LPF value (e.g. 0.12):"));
    BETA_LPF = getFloatingInput();
    Serial.print(F("-> BETA_LPF seeded at: "));
    Serial.println(BETA_LPF, 3);
    
    Serial.println(F("====================================================\n"));
    Serial.println(F("Parameters saved. Starting step test in 2 seconds..."));
    delay(2000);

    // Warmup Read
    get_collective_degrees(mag_collective);

    // CSV Data Output Header
    Serial.println(F("--- START OF PITCH DATA ---"));
    Serial.println(F("Timestamp_ms,Motor_Command, Pitch_Degrees"));
    experimentStartMs = millis();
}

void loop() {
    unsigned long currentMs = millis();
    unsigned long elapsedMs = currentMs - experimentStartMs;

    // Experiment Duration Cutoff
    if (elapsedMs >= TEST_DURATION_MS) {
        stop_motor();
        Serial.println(F("--- EXPERIMENT_COMPLETE ---"));
        while (true) delay(1000);
    }

    // AUTOMATED STEP INPUT SCHEDULE
    if (elapsedMs < 2000) {
        motorCommand = 0;  // Hold still for 2s baseline
    } else if (elapsedMs >= 2000 && elapsedMs < 4500) {
        motorCommand = 1;  // Step Forward
    } else if (elapsedMs >= 4500 && elapsedMs < 7000) {
        motorCommand = -1; // Step Reverse
    } else {
        motorCommand = 0;  // Final Hold
    }

    // Apply motor drive state (Non-blocking)
    set_motor_command(motorCommand);

    // Read pitch angle response in physical degrees
    float pitch_deg = get_collective_degrees(mag_collective);

    // Telemetry Logging
    Serial.print(elapsedMs);
    Serial.print(F(","));
    Serial.print(motorCommand);
    Serial.print(F(","));
    Serial.println(pitch_deg, 4);

    delay(10); // ~100 Hz fixed sampling frequency
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

float getFloatingInput() {
    while (Serial.available() > 0) Serial.read(); // Flush input buffer
    while (!Serial.available()) delay(10);
    float val = Serial.parseFloat();
    while (Serial.available() > 0) Serial.read(); // Clean trailing bytes
    return val;
}

void set_motor_command(int cmd) {
    if (cmd == 0) {
        stop_motor();
    } else {
        digitalWrite(M1_SLEEP, HIGH);
        if (cmd < 0) { // Reverse
            digitalWrite(M1_EN0, HIGH);
            digitalWrite(M1_EN1, LOW);
        } else {       // Forward
            digitalWrite(M1_EN0, LOW);
            digitalWrite(M1_EN1, HIGH);
        }
    }
}

void stop_motor() {
    digitalWrite(M1_EN0, LOW);
    digitalWrite(M1_EN1, LOW);
    digitalWrite(M1_SLEEP, LOW);
}

float get_collective_degrees(TLx493D_A1B6 &MagSensor) {
    double xmag = 0.0, ymag = 0.0, zmag = 0.0;
    MagSensor.getMagneticField(&xmag, &ymag, &zmag);
    float raw_beta = (float)ymag;

    // Apply Low-Pass Filter
    if (!betaInitialized) {
        filtered_beta = raw_beta;
        betaInitialized = true;
    } else {
        filtered_beta += BETA_LPF * (raw_beta - filtered_beta);
    }

    float coll_delta = coll_deg_max - coll_deg_min;
    if (fabs(coll_delta) < 0.01f) return coll_deg_min;

    // Linear interpolation onto physical degree range [coll_deg_min, coll_deg_max]
    float pct = (filtered_beta - coll_deg_min) / coll_delta;
    pct = constrain(pct, 0.0f, 1.0f);

    return coll_deg_min + (pct * coll_delta);
}