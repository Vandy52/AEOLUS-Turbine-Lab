// AEOLUS_Master_Code
// AEOLUS — Adaptive Energy Optimization and Load Utilization System

// ============================================================
// 0) SYSTEM CONFIGURATION & PIN MAPPING
// ============================================================

// ====================
// SYSTEM CONFIGURATION
//=====================
#include <Arduino.h>             // Core Arduino framework
#include <Wire.h>                // Library for the I2C communication for Hall sensors and INA219
#include <Adafruit_INA219.h>     // Library for the generator voltage/current monitoring sensor
#include <TLx493D_inc.hpp>       // Library for the 3-axis Hall-effect position sensors
#include <PinChangeInterrupt.h>  // Library for handling alternative external interrupt pins

using namespace ifx::tlx493d;  // TLx493D sensor class namespace

//=====================
// PIN MAPPING
//=====================

//*********************
// Load Bank to Arduino
//*********************

// -----------------------------
// 74HC165 (INPUT SHIFT REGISTER)
// -----------------------------
// The 74HC165 reads the six SPDT switches and sends their states to Arduino serially.

#define HC165_LOAD_PIN 15   // D15 → SH/LD
#define HC165_CLOCK_PIN 16  // D16 → CLK
#define HC165_DATA_PIN 17   // D17 ← QH (to Arduino)

// -----------------------------
// 74HC595 (OUTPUT SHIFT REGISTER)
// -----------------------------
// The 74HC595 receives serial data from Arduino and drives the six MOSFET gates.

#define HC595_DATA_PIN 11   // D11 → SER (data)
#define HC595_CLOCK_PIN 13  // D13 → SRCLK (shift clock)
#define HC595_LATCH_PIN 14  // D14 → RCLK (latch)

//*********************
// PCB to Arduino
//*********************

// -----------------------------
// 3D Magnetic Sensor - TLV493D (Yaw and pitch angle)
// -----------------------------
#define TLV1_PWR 10  // D10 → TLV1 power control (Pitch)
#define TLV0_PWR 12  // D12 → TLV0 power control (Yaw)

// -----------------------------
// HALL EFFECT SENSORS (Wind Speed Feedback)
// -----------------------------
#define ANEMOMETER_PIN 8  // D8 → Hall Sensor North (Anemometer Pin)

// -----------------------------
// MOTOR DRIVER CONTROL (PITCH & YAW SYSTEMS)
// -----------------------------
#define M1_SLEEP 7  // D7 → Motor 1 Sleep (Pitch)
#define M1_EN1 6    // D6 → Motor 1 Enable 1
#define M1_EN0 5    // D5 → Motor 1 Enable 0
#define M0_SLEEP 4  // D4 → Motor 0 Sleep (Yaw)
#define M0_EN1 3    // D3 → Motor 0 Enable 1
#define M0_EN0 2    // D2 → Motor 0 Enable 0

// -----------------------------
// INA219 (I2C POWER SENSOR)
// -----------------------------
#define INA219_SDA 18  // D18 (A4) → SDA
#define INA219_SCL 19  // D19 (A5) → SCL

// ============================================================
// 1) USER-TUNABLE CONTROL / SYSTEM SETTINGS
// ============================================================

// -----------------------------
// Tunable Variables
// -----------------------------
float wvane_zeropos = 0.35;                // Calibration offset for vane zero direction
const float ANEMOMETER_SCALE = 4.427f;     // Calibrated factor from scale testing
float coll_deg_min = 55.0f;                // Physical blade minimum measurement (degrees)
float coll_deg_max = 105.0f;               // Physical blade maximum measurement (degrees)
const float Cp = 0.25f;                    // Power coefficient
const float systemEfficiency = 0.70f;      // Mechanical/electrical efficiency
const float MAX_FREEZE_TIME_MS = 3500.0f;  // Longest freeze window at low wind speeds
const float WIND_DECAY_FACTOR = 0.35f;     // Exponential factor scaling duration vs wind
const float LOAD_BANK_MULTIPLIER = 0.15f;  // Scaling multiplier added per individual bank
float wvane_lpf = 2.0;                     // Low-pass filter for wind direction  ==> Maybe start at 0.1
const float YAW_DEADBAND = 0.2;            // Radians, about 11 degrees

// -----------------------------
// Hand-measured variables
// -----------------------------
const float LOAD_RESISTANCE_OHMS[7] = { 999999.0f, 2.5f, 1.25f, 5.0f / 6.0f, 0.625f, 0.5f, 5.0f / 12.0f };  // Dynamic resistance lookup table

const float Blade_angle_min = 55.0f;   // Physical balde minimum measurement
const float Blade_angle_max = 105.0f;  // Physical balde maximum measurement
const float rotorArea = 0.503f;      // Rotor swept area (m^2)

// -----------------------------
// Rules of thumb safety variables & physical constants
// -----------------------------
float PgenSafetyMargin = 0.05f;                   // Noise threshold to prevent erratic shedding
float pmaxSafetyFactor = 0.80f;                   // Derating factor applied to theoretical wind curves
const float READY_PITCH_ERROR_PCT = 1.0f;        // Pitch tracking error threshold required before load changes are permitted
const float READY_WIND_CHANGE_PCT = 0.05f;        // Maximum allowable wind-speed variation before declaring steady-state
const float READY_POWER_CHANGE_PCT = 0.05f;       // Maximum allowable generated-power variation before declaring steady-state
const unsigned long READY_SETTLE_TIME_MS = 5000;  // Required continuous stability duration before load changes are permitted
const unsigned long YAW_COOLDOWN_MS = 2000;       // Delay between yaw corrections
float base_motor_drivetime_ms = 1500;             // How long the yaw motor runs per background pulse
float coll_motor_drivetime_ms = 150;              // How long the pitch motor runs per background nudge
const long MIN_FREEZE_LIMIT_MS = 1000;            // Minimum clamp limit for freeze duration
const long MAX_FREEZE_LIMIT_MS = 4500;            // Maximum clamp limit for freeze duration
const float rho = 1.225f;                         // Air density (kg/m^3)
const float MPS_TO_MPH = 2.23694f;                // Fixed velocity conversion factor (m/s to MPH)

// ============================================================
// 2) GLOBAL TRACKING VARIABLES
// ============================================================

// -----------------------------
// Simulink/Pitch Control Measurements
// -----------------------------
volatile bool simulink_override = false;  // Enables Simulink beta_opt hold mode during load-shedding events when true
volatile float pitch_error = 0.0f;        // From Simulink, beta_opt - beta_act (degrees)
volatile float beta_act_percent = 0.0f;   // Actual blade pitch (normalized 0.0 to 1.0)
volatile float beta_act = 0.0f;           // Actual blade pitch (degrees)
volatile float betaFiltered = 0.0f;       // Filtered blade pitch percentage used by Simulink and controller logic
const float BETA_LPF = 0.20f;             // Low-pass filter coefficient for collective blade pitch measurement
float filtered_beta = 0.0f;               // Filtered (smoothed) collective blade pitch sensor reading
bool betaInitialized = false;             // Ensures the pitch filter starts from the first valid sensor measurement
uint32_t shedLoad = 0;                    // Records which load banks were shed (e.g., 456 = banks 4,5,6 shed)

/// -----------------------------
// Power Management & Load Shedding
// -----------------------------
Adafruit_INA219 ina219;                         // Generator measurement sensor providing voltage/current data for Pgen calculations
byte requestedSwitches = 0;                     // User requested load bank configuration
byte activeSwitches = 0;                        // Post-shedding approved load bank configuration
byte outputState = 0;                           // Active load-bank configuration sent to the 74HC595 shift register
float Pref = 0.0f;                              // Reference power demand (W)
float Pgen = 0.0f;                              // Measured generated power (W)
unsigned long last_pitch_motor_command_ms = 0;  // Last time pitch actuator was commanded
float windSpeedFiltered = 0.0f;                 // LPF reference for wind stability check
float PgenFiltered = 0.0f;                      // Low-pass filtered generated power used for stability and load-shedding logic
const float PGEN_LPF = 0.15f;                   // Low-pass filter coefficient for generated electrical power
float LoadBankChangePermission = 0.0f;          // Signals when it is acceptable to change the state of the switches

// -----------------------------
// Wind Management (Anemometer Measurements)
// -----------------------------
const int ANEMOMETER_PERIOD_COUNT = 5;                         // Number of recent pulse periods used for moving-average speed calculation
volatile unsigned long lastAnemometerPulseUs = 0;              // Timestamp (µs) of the previous Hall-effect pulse
volatile unsigned long periodBuffer[ANEMOMETER_PERIOD_COUNT];  // Circular buffer storing recent anemometer pulse periods (µs)
volatile byte periodIndex = 0;                                 // Current write index into the circular period buffer
volatile byte periodCount = 0;                                 // Number of valid samples currently stored in the period buffer
volatile float anemometer_speed_rps = 0.0f;                    // Rotor speed estimate (RPS)

// -----------------------------
// Lab State Management
// -----------------------------
bool labHold = false;                    // Freezes load-bank changes during stabilization periods
bool labHoldMessagePrinted = false;      // Prevents repeatedly printing the same hold message
unsigned long lastRequestChangeMs = 0;   // Timestamp of last switch change
unsigned long voltageFreezeStartMs = 0;  // Timestamp of last shift register (load bank) change; begins voltage stabilization window
float frozenVoltage = 0.0f;              // Voltage snapshot used during load-change stabilization period

// -----------------------------
// Yaw Motor Control
// -----------------------------
const unsigned long VANE_SAMPLE_INTERVAL_MS = 100;                // Wind vane sampling period (100 ms)
unsigned long lastYawAdjustMs = 0;                                // Timestamp of last yaw correction
unsigned long lastVaneSampleMs = 0;                               // Timestamp of last wind vane sample
unsigned long yawMotorStartMs = 0;                                // Timestamp when current yaw motor pulse began
bool yawMotorActive = false;                                      // True while a yaw motor pulse is in progress; prevents overlapping correction pulses
int yawActivePin0 = 0, yawActivePin1 = 0, yawActiveSleepPin = 0;  // Active motor-driver pins stored for timed shutdown

// -----------------------------
// Pitch Actuation (Pitch Motor Control)
// -----------------------------
unsigned long pitchMotorStartMs = 0;                                    // Timestamp when current pitch motor pulse began
bool pitchMotorActive = false;                                          // True while a pitch motor pulse is in progress; prevents overlapping correction pulses
int pitchActivePin0 = 0, pitchActivePin1 = 0, pitchActiveSleepPin = 0;  // Active driver pins stored for timed shutdown

// -----------------------------
// Magnetic Position Sensors
// -----------------------------
TLx493D_A1B6 mag_wvane(Wire, TLx493D_IIC_ADDR_A4_e);       // TLV0 -> Wind vane position sensor (Address A4, I2C 0x1F)
TLx493D_A1B6 mag_collective(Wire, TLx493D_IIC_ADDR_A0_e);  // TLV1 -> Collective blade pitch sensor (Address A0, I2C 0x5E)

// ============================================================
// 3) FUNCTION DECLARATIONS
// ============================================================

// -----------------------------
// Sensor Processing
// -----------------------------
float get_wind_vel();
float get_wind_dir(TLx493D_A1B6 &);
float get_collective_percent(TLx493D_A1B6 &);
float angleError(float target, float current);

// -----------------------------
// Load Management & Load Shedding
// -----------------------------
byte readSwitches();
bool isBankRequested(byte switchByte, int bankIndex);
void setBankOutput(byte &state, int bankIndex, bool on);
float computePrefFromSwitches(byte switchByte, float currentVoltage);
int countBanks(byte switchByte);
byte shedHighestBank(byte switchByte);
void writeOutputs(byte state);

// -----------------------------
// Motor Control (Pitch/Yaw Actuation)
// -----------------------------
void drive_motor(int, int, int, bool, int, bool);

// -----------------------------
// Power Management
// -----------------------------
float computePmax(float windSpeed);
long computeVoltageFreezeDuration(float windSpeed, int activeBankCount);

// -----------------------------
// Simulink Communication Interface
// -----------------------------
void handleSimulinkSerial();

// -----------------------------
// Wind Management (Anemometer Interrupt)
// -----------------------------
void anemometer_int();

// ============================================================
// 4) SETUP
// ============================================================

void setup() {

  // -----------------------------
  // Serial Communication Interface
  // -----------------------------
  Serial.begin(115200);  // Standard baud rate for Arduino ↔ Simulink communication

  // -----------------------------
  // User Interface & Anemometer Inputs
  // -----------------------------
  pinMode(ANEMOMETER_PIN, INPUT);
  pinMode(9, INPUT);  // Explicitly tie unused HS_S pin HIGH to guard Port B ISR vector against cross-talk
  // -----------------------------
  // Motor Driver I/O Configuration
  // -----------------------------
  pinMode(M0_EN0, OUTPUT);
  pinMode(M0_EN1, OUTPUT);
  pinMode(M0_SLEEP, OUTPUT);
  pinMode(M1_EN0, OUTPUT);
  pinMode(M1_EN1, OUTPUT);
  pinMode(M1_SLEEP, OUTPUT);

  // -----------------------------
  // TLV Sensor Address-Latch Configuration Pins
  // -----------------------------
  pinMode(SDA, OUTPUT);
  pinMode(TLV0_PWR, OUTPUT);
  pinMode(TLV1_PWR, OUTPUT);

  // -----------------------------
  // Initialize Motor Drivers to Safe Disabled State
  // -----------------------------
  digitalWrite(M0_EN0, LOW);
  digitalWrite(M0_EN1, LOW);
  digitalWrite(M0_SLEEP, LOW);
  digitalWrite(M1_EN0, LOW);
  digitalWrite(M1_EN1, LOW);
  digitalWrite(M1_SLEEP, LOW);

  // -----------------------------
  // Load-Bank Shift Register Interface Setup
  // -----------------------------
  pinMode(HC165_LOAD_PIN, OUTPUT);
  pinMode(HC165_CLOCK_PIN, OUTPUT);
  pinMode(HC165_DATA_PIN, INPUT);
  digitalWrite(HC165_LOAD_PIN, HIGH);
  digitalWrite(HC165_CLOCK_PIN, LOW);

  pinMode(HC595_CLOCK_PIN, OUTPUT);
  pinMode(HC595_LATCH_PIN, OUTPUT);
  pinMode(HC595_DATA_PIN, OUTPUT);
  writeOutputs(0);
  delay(100);

  // -----------------------------
  // TLV Sensor Hardware Bus Configuration Setup Sequence
  //
  // TLV0 powers up with SDA LOW  -> Address A4 (0x1F)
  // TLV1 powers up with SDA HIGH -> Address A0 (0x5E)
  // -----------------------------
  digitalWrite(TLV0_PWR, LOW);
  digitalWrite(TLV1_PWR, LOW);

  const uint16_t SENSOR_STARTUP_DELAY_MS = 20;
  digitalWrite(SDA, LOW);
  delay(SENSOR_STARTUP_DELAY_MS);
  digitalWrite(TLV0_PWR, HIGH);
  delay(SENSOR_STARTUP_DELAY_MS);

  digitalWrite(SDA, HIGH);
  delay(SENSOR_STARTUP_DELAY_MS);
  digitalWrite(TLV1_PWR, HIGH);
  delay(SENSOR_STARTUP_DELAY_MS);

  // -----------------------------
  // I2C Bus Initialization
  // -----------------------------
  Wire.begin();
  Wire.setClock(1000000);

  // -----------------------------
  // Sensor Initialization
  // -----------------------------
  if (!mag_collective.begin()) while (true);  // Initialize collective pitch sensor
  if (!mag_wvane.begin()) while (true);       // Initialize wind vane sensor
  if (!ina219.begin()) while (true);          // Initialize generator monitoring sensor

  // -----------------------------
  // Anemometer Interrupt Registration
  // -----------------------------
  attachPCINT(digitalPinToPCINT(ANEMOMETER_PIN), anemometer_int, FALLING);
}

// ============================================================
// 5) MAIN LOOP
// ============================================================
void loop() {

  // -----------------------------
  // Loop timing and persistent wind-state variables
  // -----------------------------
  unsigned long currentMillis = millis();
  static float windvel = 0.0f;
  static float winddir = 0.0f;

  // **********************************************************
  // WIND MANAGEMENT
  // **********************************************************

  // -----------------------------
  // Anemometer Timeout Watchdog
  // -----------------------------

  // Force wind speed to zero if no anemometer pulse has been received (no wind detected)
unsigned long lastPulse;
noInterrupts();
lastPulse = lastAnemometerPulseUs;
interrupts();

if (lastPulse > 0 && (micros() - lastPulse) > 2000000UL) {
    noInterrupts();
    anemometer_speed_rps = 0.0f;
    periodCount = 0;
    interrupts();
}

  // -----------------------------
  // Motor Pulse Completion Checks
  // -----------------------------

  // Disable the yaw motor after the commanded pulse duration expires
  if (yawMotorActive && (currentMillis - yawMotorStartMs >= (unsigned long)base_motor_drivetime_ms)) {
    digitalWrite(yawActivePin0, LOW);
    digitalWrite(yawActivePin1, LOW);
    digitalWrite(yawActiveSleepPin, LOW);
    yawMotorActive = false;
  }

  // Disable the pitch motor after the commanded pulse duration expires
  if (pitchMotorActive && (currentMillis - pitchMotorStartMs >= (unsigned long)coll_motor_drivetime_ms)) {
    digitalWrite(pitchActivePin0, LOW);
    digitalWrite(pitchActivePin1, LOW);
    digitalWrite(pitchActiveSleepPin, LOW);
    pitchMotorActive = false;
  }

  // -----------------------------
  // Wind Vane Sampling & Filtering
  // -----------------------------

  // Sample and low-pass filter wind-vane position at 10 Hz
  if (currentMillis - lastVaneSampleMs >= VANE_SAMPLE_INTERVAL_MS) {
    lastVaneSampleMs = currentMillis;

    float lpf_wvane = min(1.0f, (wvane_lpf * VANE_SAMPLE_INTERVAL_MS) / 1000.0f);
    float raw_vane = get_wind_dir(mag_wvane); 
    winddir += lpf_wvane * angleError(raw_vane, winddir); 
  }

  // Execute yaw corrections when outside the deadband
  if (!yawMotorActive && (currentMillis - lastYawAdjustMs > YAW_COOLDOWN_MS)) {
    if (winddir < -YAW_DEADBAND) {
      drive_motor(M0_EN0, M0_EN1, M0_SLEEP, true, base_motor_drivetime_ms, true);
      lastYawAdjustMs = currentMillis;
    } else if (winddir > YAW_DEADBAND) {
      drive_motor(M0_EN0, M0_EN1, M0_SLEEP, false, base_motor_drivetime_ms, true);
      lastYawAdjustMs = currentMillis;
    }
  }

  windvel = get_wind_vel();      // Measure current wind speed

  // **********************************************************
  // POWER MANAGEMENT & LOAD SHEDDING
  // **********************************************************

  // Step 1: Read user load-bank requests from the 74HC165 shift register (Read switches)
  byte newRequested = readSwitches();
  if (newRequested != requestedSwitches) {
    requestedSwitches = newRequested;
    lastRequestChangeMs = millis();
  }

  // Step 2: Measure generator voltage, current, and calculate power from the INA219 chip
  float liveVoltage = ina219.getBusVoltage_V();
  float liveCurrent = ina219.getCurrent_mA() / 1000.0f;
  Pgen = liveVoltage * liveCurrent;
  PgenFiltered += PGEN_LPF * (Pgen - PgenFiltered); 

  // Step 3: Apply the Voltage Freeze filter to stabilize power calculations after load-bank changes
  long freezeDurationMs = computeVoltageFreezeDuration(windvel, countBanks(outputState));
  float voltageForMath;
  if ((millis() - voltageFreezeStartMs) < (unsigned long)freezeDurationMs) {
    voltageForMath = frozenVoltage;  // Use frozen voltage during stabilization period
  } else {
    voltageForMath = liveVoltage;  // Use live voltage after stabilization period
  }

  // Step 4: Measure actual blade pitch
  beta_act_percent = get_collective_percent(mag_collective);
  beta_act = Blade_angle_min + (beta_act_percent * (Blade_angle_max - Blade_angle_min));
  betaFiltered = beta_act_percent;

  // Step 5: Estimate available wind power
  float Pmax_est = computePmax(windvel);
  float Pmax_safe = Pmax_est * pmaxSafetyFactor;

  // Step 6: Initialize requested load-bank configuration
  shedLoad = 0;
  activeSwitches = requestedSwitches;
  Pref = computePrefFromSwitches(activeSwitches, voltageForMath);

  // Step 7: Perform proactive load shedding until demand is feasible
  while ((Pmax_safe < Pref) && (countBanks(activeSwitches) > 0)) {
    activeSwitches = shedHighestBank(activeSwitches);
    Pref = computePrefFromSwitches(activeSwitches, voltageForMath);
  }

  // Step 8: Enable Simulink beta_opt hold mode during load-shedding events
  if (Pmax_safe < computePrefFromSwitches(requestedSwitches, voltageForMath)) {
    simulink_override = true;
  } else {
    simulink_override = false;
  }

  // Step 9: Apply pitch corrections using Simulink pitch_error feedback
  const float PITCH_TOLERANCE = 1.0f;  // Ignore pitch errors smaller than +/- 1 degree

  // Apply a new pitch correction only after the previous pitch pulse has completed
  if (!pitchMotorActive) {
    if (pitch_error > PITCH_TOLERANCE) {
      drive_motor(M1_EN0, M1_EN1, M1_SLEEP, false, coll_motor_drivetime_ms, false);
    } else if (pitch_error < -PITCH_TOLERANCE) {
      drive_motor(M1_EN0, M1_EN1, M1_SLEEP, true, coll_motor_drivetime_ms, false);
    }
  }

  // Step 10: Perform secondary load shedding using measured generator power
  if ((Pref > 0.0f) && (Pref > (PgenFiltered + PgenSafetyMargin))) { 
    activeSwitches = shedHighestBank(activeSwitches);
    Pref = computePrefFromSwitches(activeSwitches, liveVoltage);
  }

  // Step 11: Update lab-hold status
  labHold = (requestedSwitches != activeSwitches);
  if (!labHold) {
    labHoldMessagePrinted = false;
  }

  // Step 12: Generate and apply the approved load-bank configuration
  byte newOutputState = 0;
  for (int bank = 0; bank < 6; bank++) {
    if (isBankRequested(activeSwitches, bank)) {
      setBankOutput(newOutputState, bank, true);
    }
  }

  // Capture a voltage snapshot whenever the active load-bank configuration changes
  if (newOutputState != outputState) {
    frozenVoltage = liveVoltage;
    voltageFreezeStartMs = millis();
  }
  outputState = newOutputState;
  writeOutputs(outputState);

  // Step 13: Exchange data with Simulink
  handleSimulinkSerial();

  // **********************************************************
  // LOAD BANK CHANGE PERMISSION LOGIC
  // **********************************************************

  // 0 = Wait to change load bank configuration
  // 1 = Safe to change load bank configuration
  // PgenFiltered provides the filtered steady-state power reference used for stability detection

  windSpeedFiltered += 0.1f * (windvel - windSpeedFiltered);

  bool pitchStable =
      fabs(pitch_error) < READY_PITCH_ERROR_PCT;

  bool motorInactive =
      (millis() - last_pitch_motor_command_ms) >
      READY_SETTLE_TIME_MS;

  bool windStable =
      fabs(windvel - windSpeedFiltered) <
      (READY_WIND_CHANGE_PCT * max(windSpeedFiltered, 0.1f));

  bool powerStable = 
      fabs(Pgen - PgenFiltered) <
      READY_POWER_CHANGE_PCT * max(PgenFiltered, 0.1f); 

  if (pitchStable && motorInactive && windStable && powerStable) {
    LoadBankChangePermission = 1.0f;
  } else {
    LoadBankChangePermission = 0.0f;
  }
}

// ============================================================
// 6) LOAD MANAGEMENT & LOAD-SHEDDING FUNCTIONS
// ============================================================

// -----------------------------
// Load-bank utilities
// -----------------------------

// Determines whether a specific load bank is active
bool isBankRequested(byte switchByte, int bankIndex) {
  return bitRead(switchByte, bankIndex);
}

// Updates the ON/OFF status of a specific load bank
void setBankOutput(byte &state, int bankIndex, bool on) {
  int outputBit = bankIndex + 1;  // Align arrays to match physical register mapping bits
  if (on) {
    bitSet(state, outputBit);
  } else {
    bitClear(state, outputBit);
  }
}

// Counts the number of active load banks
int countBanks(byte switchByte) {
  int n = 0;
  for (int bank = 0; bank < 6; bank++) {
    if (isBankRequested(switchByte, bank)) {
      n++;
    }
  }
  return n;
}

// -----------------------------
// Power-demand calculations
// -----------------------------

// Calculates the requested electrical power (Pref) from the active load-bank configuration
float computePrefFromSwitches(byte switchByte, float currentVoltage) {
  int activeCount = countBanks(switchByte);
  if (activeCount <= 0) return 0.0f;
  float total_R = LOAD_RESISTANCE_OHMS[activeCount];
  return (currentVoltage * currentVoltage) / total_R;
}

// -----------------------------
// Load-shedding tracking
// -----------------------------

// Determines the numerical position where a newly shed load-bank number should be placed in shedLoad
uint32_t decimalMultiplier(uint32_t value) {
  uint32_t mult = 1;

  while (value >= mult) {
    mult *= 10;
  }

  return mult;
}

// Records a newly shed load-bank number to shedLoad
void recordShedBank(int bankNumber) {
  shedLoad = bankNumber * decimalMultiplier(shedLoad) + shedLoad;
}

// Sheds the highest-numbered active load bank and records the event
byte shedHighestBank(byte switchByte) {
  for (int bank = 5; bank >= 0; bank--) {
    if (isBankRequested(switchByte, bank)) {
      recordShedBank(bank + 1);
      bitClear(switchByte, bank);
      break;
    }
  }

  return switchByte;
}

// -----------------------------
// Wind-power calculations
// -----------------------------

// Estimates the maximum available wind power using the turbine power equation
float computePmax(float windSpeed) {
  return 0.5f * rho * rotorArea * Cp * systemEfficiency * windSpeed * windSpeed * windSpeed;
}

// -----------------------------
// Voltage Freeze calculations
// -----------------------------

// Calculates the Voltage Freeze duration based on wind speed and active load count
long computeVoltageFreezeDuration(float windSpeed, int activeBankCount) {
  long duration = (MAX_FREEZE_TIME_MS * expf(-WIND_DECAY_FACTOR * windSpeed)) * (1.0f + (activeBankCount * LOAD_BANK_MULTIPLIER));
  return constrain(duration, MIN_FREEZE_LIMIT_MS, MAX_FREEZE_LIMIT_MS);
}

// ============================================================
// 7) SENSOR & HARDWARE INTERFACE FUNCTIONS
// ============================================================

// -----------------------------
// Shift Register Interface
// -----------------------------

// Reads the 74HC165 input shift register and returns the current load-bank switch configuration
byte readSwitches() {
  byte raw = 0;
  digitalWrite(HC165_LOAD_PIN, LOW);
  delayMicroseconds(5);
  digitalWrite(HC165_LOAD_PIN, HIGH);
  delayMicroseconds(5);
  for (int i = 0; i < 8; i++) {
    raw <<= 1;
    if (digitalRead(HC165_DATA_PIN)) {
      raw |= 1;
    }
    digitalWrite(HC165_CLOCK_PIN, HIGH);
    delayMicroseconds(5);
    digitalWrite(HC165_CLOCK_PIN, LOW);
    delayMicroseconds(5);
  }
  byte switches = 0;
  for (int bank = 0; bank < 6; bank++) {
    if (bitRead(raw, bank)) {
      bitSet(switches, bank);
    }
  }
  return switches;
}

// Sends the approved load-bank configuration to the 74HC595 output shift register
void writeOutputs(byte state) {
  digitalWrite(HC595_LATCH_PIN, LOW);
  shiftOut(HC595_DATA_PIN, HC595_CLOCK_PIN, MSBFIRST, state);
  digitalWrite(HC595_LATCH_PIN, HIGH);
}

// -----------------------------
// Sensor & Actuator Interface
// -----------------------------

// Commands a timed yaw or pitch motor pulse
// and records the information needed by the main loop to turn the motor off after the pulse duration expires
void drive_motor(int pin_en0, int pin_en1, int pin_sleep, bool reverse, int time_ms, bool isYawMotor) {
  digitalWrite(pin_sleep, HIGH);
  if (reverse) {
    digitalWrite(pin_en0, LOW);  //here
    digitalWrite(pin_en1, HIGH);   //here
  } else {
    digitalWrite(pin_en0, HIGH);   //here
    digitalWrite(pin_en1, LOW);  //here
  }

  if (isYawMotor) {
    yawMotorStartMs = millis();
    yawMotorActive = true;
    yawActivePin0 = pin_en0;
    yawActivePin1 = pin_en1;
    yawActiveSleepPin = pin_sleep;
  } else {
    pitchMotorStartMs = millis();
    last_pitch_motor_command_ms = millis();
    pitchMotorActive = true;
    pitchActivePin0 = pin_en0;
    pitchActivePin1 = pin_en1;
    pitchActiveSleepPin = pin_sleep;
  }
}

// Converts filtered anemometer speed into wind speed
float get_wind_vel() {
  float current_speed_rps; 
  noInterrupts(); 
  current_speed_rps = anemometer_speed_rps; 
  interrupts(); 
  return current_speed_rps * ANEMOMETER_SCALE; 
}

// Calculates wind-vane direction from the magnetic position sensor
float get_wind_dir(TLx493D_A1B6 &MagSensor) {
  double xmag = 0.0, ymag = 0.0, zmag = 0.0;
  MagSensor.getMagneticField(&xmag, &ymag, &zmag);

  float w_dir = atan2((float)xmag, (float)ymag) - wvane_zeropos;
  w_dir = w_dir < -3.14f ? w_dir + 6.28f : w_dir;
  w_dir = w_dir > 3.14f ? w_dir - 6.28f : w_dir;
  return w_dir;
}

// Wrap-around error processing for the yaw position//here
float angleError(float target, float current) { 
  float error = target - current; 
  while (error > 3.14159265f)  error -= 2.0f * 3.14159265f; 
  while (error < -3.14159265f) error += 2.0f * 3.14159265f; 
  return error; 
} 

// Converts the collective pitch sensor reading into a normalized blade-pitch position (0.0 to 1.0)
float get_collective_percent(TLx493D_A1B6 &MagSensor) {
    double xmag = 0.0, ymag = 0.0, zmag = 0.0;
    MagSensor.getMagneticField(&xmag, &ymag, &zmag);

    // Compute continuous 2D magnetic angle in degrees (0° to 360°)
    float rad = atan2((float)ymag, (float)xmag);
    float raw_angle_deg = rad * (180.0f / 3.14159265f);
    if (raw_angle_deg < 0.0f) raw_angle_deg += 360.0f;

    if (!betaInitialized) {
        filtered_beta = raw_angle_deg;
        betaInitialized = true;
    }

    // Low-pass filter raw 2D magnetic angle
    filtered_beta += BETA_LPF * (raw_angle_deg - filtered_beta);

    // Calculate sensor span between calibrated magnetic endpoints
    float sensor_span = coll_deg_max - coll_deg_min;
    if (fabs(sensor_span) < 0.01f) {
        return 0.0f;
    }

    // Return normalized percentage (0.0 to 1.0) across sensor travel
    return constrain((filtered_beta - coll_deg_min) / sensor_span, 0.0f, 1.0f);
}

// Interrupt service routine (ISR) that updates the filtered anemometer speed estimate from incoming Hall-sensor pulses // here
//
// Executes whenever the anemometer Hall-effect sensor detects a passing rotor magnet.
// Measures the time between consecutive pulses, stores the most recent pulse
// periods in a moving-average buffer, and converts the averaged pulse period
// into rotor speed (revolutions per second).
void anemometer_int() {
  unsigned long now = micros();

  if (lastAnemometerPulseUs != 0) { 
    unsigned long dt = now - lastAnemometerPulseUs;

    periodBuffer[periodIndex] = dt; 
    periodIndex = (periodIndex + 1) % ANEMOMETER_PERIOD_COUNT; 

    if (periodCount < ANEMOMETER_PERIOD_COUNT) { 
      periodCount++; 
    }

    unsigned long sum = 0; 
    for (byte i = 0; i < periodCount; i++) { 
      sum += periodBuffer[i]; 
    } 

    anemometer_speed_rps = 1000000.0f / ((float)sum / periodCount); 
  } 
  lastAnemometerPulseUs = now; 
}

// ============================================================
// 8) SIMULINK COMMUNICATION INTERFACE FUNCTION
// ============================================================

// Exchanges control and measurement data between Arduino and Simulink
void handleSimulinkSerial() {

  // Rate-limit serial execution to 50 Hz (20 ms) to prevent TX buffer blocking
  static unsigned long lastSerialExecutionMs = 0;
  unsigned long currentMs = millis();
  if (currentMs - lastSerialExecutionMs < 20) {
    return;
  }
  lastSerialExecutionMs = currentMs;


  // Receive the latest pitch_error command from Simulink
  while (Serial.available() >= 6) {
    if (Serial.read() == 'S') {
      float incoming_pitch_error = 0.0f;

      Serial.readBytes((char *)&incoming_pitch_error,
                       sizeof(incoming_pitch_error));

      if (Serial.read() == 'E') {
        // Accept only physically reasonable pitch-error values
        if (incoming_pitch_error >= -60.0f && incoming_pitch_error <= 60.0f) {
          pitch_error = incoming_pitch_error;
        }
        } else {
            while (Serial.available() > 0) Serial.read(); // Clear misaligned buffer
        }
      }
    }
  }

  // Convert controller state variables into Simulink-compatible float values
  float simulink_override_float = simulink_override ? 1.0f : 0.0f;
  float shedLoad_float = (float)shedLoad;
  float loadBankPermission_float = LoadBankChangePermission;
  float activeBetaTx = betaFiltered; 

  // Transmit controller status and turbine measurements to Simulink
  Serial.write('S');

  Serial.write((uint8_t *)&Pref, sizeof(Pref));
  Serial.write((uint8_t *)&simulink_override_float, sizeof(simulink_override_float));
  Serial.write((uint8_t *)&activeBetaTx, sizeof(activeBetaTx)); 
  Serial.write((uint8_t *)&Pgen, sizeof(Pgen));
  Serial.write((uint8_t *)&shedLoad_float, sizeof(shedLoad_float));
  Serial.write((uint8_t *)&loadBankPermission_float, sizeof(loadBankPermission_float));

  Serial.write('E');
}