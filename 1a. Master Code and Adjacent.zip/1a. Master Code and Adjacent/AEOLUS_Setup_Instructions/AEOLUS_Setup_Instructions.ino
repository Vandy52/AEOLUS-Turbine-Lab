/*
=========================================================
AEOLUS Setup Instructions
=========================================================

1. Connect the Arduino Nano to your computer using a USB A to Mini USB cable 

2. Select the drop-down menu that says "Select Board" and then select "Select other board and port..."

3. Under "Boards" type Nano into the search bar and select "Arduino Nano"

4. Under "Ports" select the port that corresponds to the port that the Arduino Nano is plugged into and then click "OK"

5. Upload the AEOLUS code to the Arduino Nano using the arrow bottom in the top right of the screen

6. Open the AEOLUS_Pitch_Control.slx file

7. Navigate to the "Apps" tab and click the down arrow at the far right of the ribbon

8. Scroll down to the app category titled SETUP TO "RUN ON HARDWARE"

9. Select the app titled "Run on Hardware Board"

10. On the "Run on Hardware Board" configuration window in the "Hardware Board" drop-down menu select "Arduino Nano 3.0"

11. Click "Finish"

12. Now under the "HARDWARE" tab and under the "PREPARE" heading, click on "Hardware Settings"

13. In the lefthand selection tree select "Hardware Implementation" and expand the "Target hardware resources" menu 

14. Select "Host-board connect" and set "Host COM port" to the same port chosen in step 4
 
15. Double check that the all four of the Baud rate settings are set to 115200 

16. Now select "Solver" under the selection tree

17. Under "Solver Selection" set "Type" to "Fixed-Step" and "Solver" to "discrete (no continuous states)"

18. Set the "Stop time" to inf to run the Wind Turbine continuously until the stop button is manually selected

19. Expand the "Solver details" menu and change "Fixed-step size (fundamental sample time)" to 0.02

20. Select "Apply" in the bottom right hand corner of the "Configuration Parameters Window"

21. Click "OK" to the left off the "Apply" button

22. Under the "MODE" heading, select the drop-down arrow and select "Run on board" if it isn't already selected

23. Under the "RUN ON HARDWARE" heading, select the drop-down arrow and select "Monitor & Tune" if it isn't already selected

24. Under the "DEPLOY" heading, select the drop-down arrow and select "Build, Deploy & Start" if it isn't already selected

25. Double click on the "Scope" block on the far right of the AEOLUS_Pitch_Control block diagram 

26. Click the "Monitor & Tune" start button to start the experiment 

27. Once the bottom status bar of Simulink has compiled, it will say "Running" in the bottom right-hand corner of the window

28. To stop the experiment select the stop button (square with circle around it)

29. This can be found either in the "Scope" window in line with the "Scope" tab on the far right

30. Or this can be found in the exact same location the "Monitor & Tune" start button was

31. To see entire trial on the graph, go to the upper right of the graph in the "Scope" Window

32. Hover over the box with two vertical arrows in pointing in opposite directions

33. Select the box with four arrows (the bottom of three boxes) 


=========================================================
How to save data from the scope block
=========================================================

1. Double click on the Scope block labeled "Pgen, Pref under controller" if the Scope block is not already open

2. Click on the "Scope" tab 

3. Under the "Settings" header, select the "Settings" button

4. In the Scope "Settings" popup window select the "Global Properties" drop-down arrow and then the "Logging" drop-down arrow

5. Select the "Log data to workspace" check box and change the "Variable name" to a name of your choosing

6. Go to the main MATLAB Command Window

7. In the "Command Window" copy paste the following line of code but be sure to switch out "ScopeData" with the new "Variable name" you chose

      a. The name "ScopeData" will need to be changed five times in the following locations: t_data, d1, d2, d3, f_name 

t_data = out.ScopeData{1}.Values.Time; d1 = out.ScopeData{1}.Values.Data(:,1); d2 = out.ScopeData{1}.Values.Data(:,2); d3 = out.ScopeData{2}.Values.Data; m_dir = fileparts(which(bdroot)); f_name = [out.ScopeData.Name, '.xlsx']; f_path = fullfile(m_dir, f_name); writetable(table(t_data, d1, d2, d3, 'VariableNames', {'Time_s', 'Pref', 'Pgen', 'beta_act'}), f_path); if ispc; cmd = 'winopen'; else; cmd = 'open'; end; disp(['---> Success! Click here to open your file: <a href="matlab: ', cmd, '(''', f_path, ''')">', f_name, '</a> <---'])

// 9. Hit "Enter" on the computer

// 10. Click the link that appears in the "Command Window" to go to the Excel file where the data is stored. It will be after the words "Success! Click here to open your file" 
// =========================================================
// */
